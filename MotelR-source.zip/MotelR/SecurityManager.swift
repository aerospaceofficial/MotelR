//
//  SecurityManager.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/13/24.
//

import Foundation
import CryptoKit
import Security
import SwiftUI

class SecurityManager {
    static let shared = SecurityManager()
    private let service = "com.motelr.app"
    private let pinKey = "motelr_security_pin"
    private let backupKeyAccount = "motelr_backup_encryption_key"

    private init() {}

    // MARK: - Backup Encryption Key
    /// Returns the persistent 256-bit backup key from Keychain,
    /// generating and storing a new one on first use.
    func getOrCreateBackupKey() -> SymmetricKey {
        // Try to load existing key
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: backupKeyAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var ref: AnyObject?
        if SecItemCopyMatching(query as CFDictionary, &ref) == errSecSuccess,
           let keyData = ref as? Data, keyData.count == 32 {
            return SymmetricKey(data: keyData)
        }
        // Generate a new random 256-bit key and save it
        let newKey = SymmetricKey(size: .bits256)
        let keyData = newKey.withUnsafeBytes { Data($0) }
        let deleteQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: backupKeyAccount
        ]
        SecItemDelete(deleteQuery as CFDictionary)
        let addQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: backupKeyAccount,
            kSecValueData as String: keyData,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
        ]
        SecItemAdd(addQuery as CFDictionary, nil)
        return newKey
    }
    
    // MARK: - Password-Derived Keys (for portable backups)

    /// Number of PBKDF2 rounds used to turn a user password into an encryption key.
    static let keyDerivationRounds = 210_000

    /// Derives a 256-bit key from a user-supplied password. Used to wrap the backup
    /// key inside an exported archive so the export is useless without the password.
    static func derivedKey(fromPassword password: String, salt: Data) -> SymmetricKey {
        SymmetricKey(data: pbkdf2SHA256(
            password: password,
            salt: salt,
            rounds: keyDerivationRounds,
            byteCount: 32
        ))
    }

    /// PBKDF2-HMAC-SHA256, implemented over CryptoKit's HMAC so no CommonCrypto import is needed.
    static func pbkdf2SHA256(password: String, salt: Data, rounds: Int, byteCount: Int) -> Data {
        let passwordKey = SymmetricKey(data: Data(password.utf8))
        var output = Data()
        var block: UInt32 = 1

        while output.count < byteCount {
            var salted = salt
            salted.append(contentsOf: [
                UInt8(truncatingIfNeeded: block >> 24),
                UInt8(truncatingIfNeeded: block >> 16),
                UInt8(truncatingIfNeeded: block >> 8),
                UInt8(truncatingIfNeeded: block)
            ])

            var u = Data(HMAC<SHA256>.authenticationCode(for: salted, using: passwordKey))
            var result = u
            for _ in 1..<rounds {
                u = Data(HMAC<SHA256>.authenticationCode(for: u, using: passwordKey))
                for i in 0..<result.count { result[i] ^= u[i] }
            }

            output.append(result)
            block += 1
        }
        return output.prefix(byteCount)
    }

    // MARK: - PIN Management

    /// Stored PIN format is `pbkdf2$<rounds>$<saltHex>$<hashHex>`. Older builds stored a
    /// bare unsalted SHA-256 hex string; those are still accepted and upgraded in place
    /// the next time the PIN is entered correctly.
    private static let pinRounds = 210_000

    func setPin(_ pin: String) throws {
        try saveToKeychain(Self.makePinRecord(pin))
    }

    /// Checks the PIN off the main thread. Hashing a PIN takes 210,000 rounds on
    /// purpose (to resist guessing), which froze the keypad when done on the main thread.
    func verifyPinAsync(_ pin: String, completion: @escaping (Bool) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = self.verifyPin(pin)
            DispatchQueue.main.async { completion(ok) }
        }
    }

    func verifyPin(_ pin: String) -> Bool {
        guard let stored = (try? loadFromKeychain()) ?? nil else { return false }

        if stored.hasPrefix("pbkdf2$") {
            return Self.verifyPinRecord(pin, record: stored)
        }

        // Legacy unsalted SHA-256 record — verify, then transparently upgrade.
        guard constantTimeEquals(stored, hashPin(pin)) else { return false }
        try? saveToKeychain(Self.makePinRecord(pin))
        return true
    }

    private static func makePinRecord(_ pin: String) -> String {
        var salt = Data(count: 16)
        _ = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        let hash = pbkdf2SHA256(password: pin, salt: salt, rounds: pinRounds, byteCount: 32)
        return "pbkdf2$\(pinRounds)$\(salt.hexString)$\(hash.hexString)"
    }

    private static func verifyPinRecord(_ pin: String, record: String) -> Bool {
        let parts = record.split(separator: "$", omittingEmptySubsequences: false)
        guard parts.count == 4,
              let rounds = Int(parts[1]),
              let salt = Data(hexString: String(parts[2]))
        else { return false }
        let expected = pbkdf2SHA256(password: pin, salt: salt, rounds: rounds, byteCount: 32)
        return expected.hexString.constantTimeEquals(String(parts[3]))
    }

    private func constantTimeEquals(_ a: String, _ b: String) -> Bool {
        a.constantTimeEquals(b)
    }

    // MARK: - Brute Force Protection (stored in Keychain, not UserDefaults)
    private let failedAttemptsAccount = "motelr_failed_pin_attempts"
    private let lockoutUntilAccount = "motelr_lockout_until"

    var failedAttempts: Int {
        guard let data = keychainData(forAccount: failedAttemptsAccount),
              let string = String(data: data, encoding: .utf8),
              let value = Int(string) else { return 0 }
        return value
    }

    func recordFailedAttempt() {
        guard pinExists() else { return }

        let attempts = failedAttempts + 1
        saveKeychainString(String(attempts), forAccount: failedAttemptsAccount)

        // Escalating lockout: 5 fails = 1 min, 10 fails = 5 min, 15+ fails = 30 min
        guard attempts % 5 == 0 else { return }
        let duration: TimeInterval
        switch attempts {
        case 5..<10:  duration = 60
        case 10..<15: duration = 300
        default:      duration = 1800
        }
        let lockoutDate = Date().addingTimeInterval(duration)
        let timestamp = String(lockoutDate.timeIntervalSince1970)
        saveKeychainString(timestamp, forAccount: lockoutUntilAccount)
    }

    func isLockedOut() -> Bool {
        guard let data = keychainData(forAccount: lockoutUntilAccount),
              let str = String(data: data, encoding: .utf8),
              let ts = Double(str) else { return false }
        return Date() < Date(timeIntervalSince1970: ts)
    }

    func lockoutSecondsRemaining() -> Int {
        guard let data = keychainData(forAccount: lockoutUntilAccount),
              let str = String(data: data, encoding: .utf8),
              let ts = Double(str) else { return 0 }
        return max(0, Int(Date(timeIntervalSince1970: ts).timeIntervalSinceNow))
    }

    func resetFailedAttempts() {
        deleteKeychainItem(forAccount: failedAttemptsAccount)
        deleteKeychainItem(forAccount: lockoutUntilAccount)
    }

    // MARK: - Keychain Helpers for lockout data
    private func keychainData(forAccount account: String) -> Data? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var ref: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &ref) == errSecSuccess else { return nil }
        return ref as? Data
    }

    private func saveKeychainString(_ value: String, forAccount account: String) {
        guard let data = value.data(using: .utf8) else { return }
        let deleteQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(deleteQuery as CFDictionary)
        let addQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlock
        ]
        SecItemAdd(addQuery as CFDictionary, nil)
    }

    private func deleteKeychainItem(forAccount account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
    
    func pinExists() -> Bool {
        return (try? loadFromKeychain()) != nil
    }
    
    func getStoredPinHash() -> String? {
            return try? loadFromKeychain()
        }
        
    func restorePin(hash: String) throws {
            try saveToKeychain(hash)
        }

        // Add this function to help with restoration
    func verifyPinAgainstHash(_ pin: String, hash: String) -> Bool {
            return hashPin(pin) == hash
        }
    
    // MARK: - Backup Integration
    func getEncryptedBackupKey() -> String? {
        return try? loadFromKeychain()
    }
    
    func validateBackupKey(_ key: String) -> Bool {
        guard let storedKey = try? loadFromKeychain() else {
            return false
        }
        return key == storedKey
    }
    
    // MARK: - Helper Functions
    private func hashPin(_ pin: String) -> String {
        let inputData = Data(pin.utf8)
        let hashed = SHA256.hash(data: inputData)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }
    
    // MARK: - Keychain Operations
    private func saveToKeychain(_ value: String) throws {
        guard let data = value.data(using: .utf8) else {
            throw KeychainError.unhandledError(status: errSecParam)
        }
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: pinKey,
            kSecValueData as String: data
        ]
        
        // First try to delete any existing keychain item
        SecItemDelete(query as CFDictionary)
        
        // Add the new keychain item
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw KeychainError.unhandledError(status: status)
        }
    }
    
    private func loadFromKeychain() throws -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: pinKey,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var dataTypeRef: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &dataTypeRef)
        
        if status == errSecSuccess {
            if let data = dataTypeRef as? Data,
               let string = String(data: data, encoding: .utf8) {
                return string
            }
        }
        return nil
    }
    
    // MARK: - Reset
    func resetPin() throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: pinKey
        ]
        
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw KeychainError.unhandledError(status: status)
        }
    }
    
    enum KeychainError: Error {
        case unhandledError(status: OSStatus)
    }
}

struct PINField: View {
    let title: String
    @Binding var pin: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            SecureField("", text: $pin)
                .keyboardType(.numberPad)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .overlay(
                    HStack {
                        ForEach(0..<6) { index in
                            Circle()
                                .fill(index < pin.count ?
                                      Color.blue : Color.gray.opacity(0.3))
                                .frame(width: 12, height: 12)
                        }
                    }
                    .padding()
                )
                .onChange(of: pin) { oldValue, newValue in
                    if newValue.count > 6 {
                        pin = String(newValue.prefix(6))
                    }
                    pin = newValue.filter { "0123456789".contains($0) }
                }
        }
    }
}

struct RequirementRow: View {
    let text: String
    let isMet: Bool
    
    var body: some View {
        HStack {
            Image(systemName: isMet ? "checkmark.circle.fill" : "circle")
                .foregroundColor(isMet ? .green : .gray)
            Text(text)
                .font(.caption)
                .foregroundColor(isMet ? .primary : .secondary)
        }
    }
}

// MARK: - Hex / constant-time helpers

extension Data {
    var hexString: String {
        map { String(format: "%02x", $0) }.joined()
    }

    init?(hexString: String) {
        guard hexString.count % 2 == 0 else { return nil }
        var bytes = [UInt8]()
        bytes.reserveCapacity(hexString.count / 2)
        var index = hexString.startIndex
        while index < hexString.endIndex {
            let next = hexString.index(index, offsetBy: 2)
            guard let byte = UInt8(hexString[index..<next], radix: 16) else { return nil }
            bytes.append(byte)
            index = next
        }
        self.init(bytes)
    }
}

extension String {
    /// Compares two hex digests without leaking how many leading characters matched.
    func constantTimeEquals(_ other: String) -> Bool {
        let a = Array(utf8), b = Array(other.utf8)
        guard a.count == b.count else { return false }
        var difference: UInt8 = 0
        for i in 0..<a.count { difference |= a[i] ^ b[i] }
        return difference == 0
    }
}
