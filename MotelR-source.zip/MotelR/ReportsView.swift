//  ReportsView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Design Tokens
private let rvPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let rvGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let rvGold  = Color(red: 0.96, green: 0.65, blue: 0.14)
private let rvGreen = Color(red: 0.20, green: 0.78, blue: 0.35)

// MARK: - Report Types
private enum ReportType: String, CaseIterable, Identifiable {
    case daily      = "Daily Summary"
    case monthly    = "Monthly Report"
    case occupancy  = "Occupancy Report"
    case customer   = "Customer Report"
    var id: String { rawValue }

    var icon: String {
        switch self {
        case .daily:     return "sun.max.fill"
        case .monthly:   return "calendar"
        case .occupancy: return "bed.double.fill"
        case .customer:  return "person.3.fill"
        }
    }

    var description: String {
        switch self {
        case .daily:     return "Today's check-ins, check-outs, and revenue."
        case .monthly:   return "Full month breakdown by payment method."
        case .occupancy: return "Room-by-room occupancy rates."
        case .customer:  return "Guest list with contact information."
        }
    }

    var gradient: LinearGradient {
        switch self {
        case .daily:
            return LinearGradient(colors: [rvGold, Color(red: 0.85, green: 0.50, blue: 0.05)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .monthly:
            return rvGradient
        case .occupancy:
            return LinearGradient(colors: [rvGreen, Color(red: 0.10, green: 0.60, blue: 0.25)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .customer:
            return LinearGradient(colors: [Color(red: 0.50, green: 0.20, blue: 0.90), Color(red: 0.30, green: 0.10, blue: 0.65)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }
}

// MARK: - ReportsView
struct ReportsView: View {
    @EnvironmentObject var motelData: MotelData
    @State private var selectedReport: ReportType = .daily
    @State private var startDate = Calendar.current.date(byAdding: .month, value: -1, to: Date()) ?? Date()
    @State private var endDate = Date()
    @State private var previewText = ""
    @State private var shareItems: [Any] = []
    @State private var showingShare = false
    @State private var isGenerating = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    reportTypeGrid
                    dateRangeCard
                    generateButton
                    if !previewText.isEmpty {
                        previewCard
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Reports")
            .navigationBarTitleDisplayMode(.large)
            .sheet(isPresented: $showingShare) {
                SharedActivityView(activityItems: shareItems)
            }
        }
    }

    // MARK: Report Type Grid
    private var reportTypeGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(ReportType.allCases) { type in
                ReportTypeCard(
                    type: type,
                    isSelected: selectedReport == type
                ) {
                    selectedReport = type
                    previewText = ""
                }
            }
        }
    }

    // MARK: Date Range Card
    private var dateRangeCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("Date Range", systemImage: "calendar.badge.clock")
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(rvPrimary)

            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("From")
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                    DatePicker("", selection: $startDate, displayedComponents: .date)
                        .labelsHidden()
                        .accentColor(rvPrimary)
                }
                Divider().frame(height: 40)
                VStack(alignment: .leading, spacing: 4) {
                    Text("To")
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                    DatePicker("", selection: $endDate, in: startDate..., displayedComponents: .date)
                        .labelsHidden()
                        .accentColor(rvPrimary)
                }
                Spacer()
            }
        }
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }

    // MARK: Generate Button
    private var generateButton: some View {
        Button {
            generateReport()
        } label: {
            HStack(spacing: 10) {
                if isGenerating {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(.white)
                        .scaleEffect(0.85)
                } else {
                    Image(systemName: "doc.badge.gearshape.fill")
                        .font(.system(size: 17, weight: .semibold))
                }
                Text(isGenerating ? "Generating…" : "Generate & Share")
                    .font(.system(.headline, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(rvGradient)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: rvPrimary.opacity(0.35), radius: 10, y: 4)
        }
        .buttonStyle(.plain)
        .disabled(isGenerating)
    }

    // MARK: Preview Card
    private var previewCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Preview", systemImage: "eye.fill")
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    .foregroundStyle(rvPrimary)
                Spacer()
                Button {
                    shareItems = [previewText]
                    showingShare = true
                } label: {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(rvPrimary)
                }
                .buttonStyle(.plain)
            }
            Divider()
            ScrollView {
                Text(previewText)
                    .font(.system(.caption, design: .monospaced))
                    .foregroundStyle(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxHeight: 320)
        }
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }

    // MARK: Generate Logic
    private func generateReport() {
        // Built on the main queue: the bookings belong to the view context, and
        // reading them from a background thread can crash Core Data.
        isGenerating = true
        let text = buildReport()
        previewText = text
        isGenerating = false
        shareItems = [text]
        showingShare = true
    }

    private func buildReport() -> String {
        let cal = Calendar.current
        let allBookings = (motelData.bookings + motelData.history).filter {
            $0.checkInDate >= startDate && $0.checkInDate <= endDate
        }
        let header = """
        \(motelData.businessName)
        \(selectedReport.rawValue.uppercased())
        Period: \(fmtDate(startDate)) – \(fmtDate(endDate))
        Generated: \(fmtDateTime(Date()))
        ════════════════════════════════════════
        """

        switch selectedReport {
        case .daily:
            return buildDailyReport(header: header, cal: cal)
        case .monthly:
            return buildMonthlyReport(header: header, bookings: allBookings)
        case .occupancy:
            return buildOccupancyReport(header: header, bookings: allBookings, cal: cal)
        case .customer:
            return buildCustomerReport(header: header, bookings: allBookings)
        }
    }

    private func buildDailyReport(header: String, cal: Calendar) -> String {
        let today = Calendar.current.startOfDay(for: Date())
        let tomorrow = cal.date(byAdding: .day, value: 1, to: today) ?? Date()

        let checkIns = motelData.bookings.filter {
            $0.checkInDate >= today && $0.checkInDate < tomorrow
        }
        let checkOuts = motelData.history.filter {
            $0.checkOutDate >= today && $0.checkOutDate < tomorrow
        }
        let revenue = (checkIns + checkOuts).filter { $0.paymentStatusEnum == .paid }
            .reduce(0.0) { $0 + $1.prizeAmount }

        var lines = [header]
        lines.append("\nDATE: \(fmtDate(Date()))\n")
        lines.append("CHECK-INS (\(checkIns.count))")
        lines.append(String(repeating: "─", count: 40))
        for b in checkIns {
            lines.append("  \(b.customerName)  Room \(b.room.number)  \(b.prize)")
        }
        if checkIns.isEmpty { lines.append("  (none)") }

        lines.append("\nCHECK-OUTS (\(checkOuts.count))")
        lines.append(String(repeating: "─", count: 40))
        for b in checkOuts {
            lines.append("  \(b.customerName)  Room \(b.room.number)  \(b.prize)")
        }
        if checkOuts.isEmpty { lines.append("  (none)") }

        lines.append("\n════════════════════════════════════════")
        lines.append(String(format: "REVENUE TODAY:  $%.2f", revenue))
        return lines.joined(separator: "\n")
    }

    private func buildMonthlyReport(header: String, bookings: [CDBooking]) -> String {
        let byMethod = Dictionary(grouping: bookings) { $0.paymentMethodEnum }
        var lines = [header]
        lines.append(String(format: "\nTOTAL BOOKINGS: %d", bookings.count))
        let totalRevenue = bookings.filter { $0.paymentStatusEnum == .paid }.reduce(0.0) { $0 + $1.prizeAmount }
        lines.append(String(format: "TOTAL REVENUE:  $%.2f\n", totalRevenue))
        lines.append("BREAKDOWN BY PAYMENT METHOD")
        lines.append(String(repeating: "─", count: 40))
        for method in PaymentMethod.allCases {
            let group = byMethod[method] ?? []
            let amt = group.filter { $0.paymentStatusEnum == .paid }.reduce(0.0) { $0 + $1.prizeAmount }
            lines.append("  " + padded(method.rawValue, 14) + String(format: "  %2d bookings  $%.2f", group.count, amt))
        }
        lines.append("\nPENDING PAYMENTS")
        lines.append(String(repeating: "─", count: 40))
        let pending = bookings.filter { $0.paymentStatusEnum == .pending }
        for b in pending {
            lines.append("  \(b.customerName)  \(b.organizationName ?? "")  \(b.prize)")
        }
        if pending.isEmpty { lines.append("  (none)") }
        return lines.joined(separator: "\n")
    }

    private func buildOccupancyReport(header: String, bookings: [CDBooking], cal: Calendar) -> String {
        let days = max(1, cal.dateComponents([.day], from: startDate, to: endDate).day ?? 1)
        var lines = [header]
        lines.append(String(format: "\nPERIOD: %d days\n", days))
        lines.append("ROOM-BY-ROOM OCCUPANCY")
        lines.append(String(repeating: "─", count: 40))
        for room in motelData.rooms.sorted(by: { $0.number < $1.number }) {
            let roomBookings = bookings.filter { $0.room.number == room.number }
            let occupiedDays = roomBookings.reduce(0) { $0 + Int($1.numberOfDays) }
            let rate = Double(min(occupiedDays, days)) / Double(days) * 100
            let revenue = roomBookings.filter { $0.paymentStatusEnum == .paid }.reduce(0.0) { $0 + $1.prizeAmount }
            // Swift Strings must not be passed to %s (it expects a C string and printed
            // garbage or crashed), so the room name is padded by hand.
            lines.append(String(format: "  Room %3d  ", Int(room.number))
                + padded(room.name, 12)
                + String(format: "  %2d days  %5.1f%%  $%.2f", occupiedDays, rate, revenue))
        }
        let totalDays = motelData.rooms.count * days
        let totalOccupied = bookings.reduce(0) { $0 + Int($1.numberOfDays) }
        let overallRate = totalDays > 0 ? Double(min(totalOccupied, totalDays)) / Double(totalDays) * 100 : 0
        lines.append(String(repeating: "─", count: 40))
        lines.append(String(format: "  OVERALL OCCUPANCY RATE: %.1f%%", overallRate))
        return lines.joined(separator: "\n")
    }

    private func buildCustomerReport(header: String, bookings: [CDBooking]) -> String {
        var lines = [header]
        lines.append(String(format: "\nTOTAL GUESTS: %d\n", bookings.count))
        lines.append("GUEST LIST")
        lines.append(String(repeating: "─", count: 40))
        let sorted = bookings.sorted { $0.customerName < $1.customerName }
        for b in sorted {
            lines.append("  \(b.customerName)")
            lines.append("    Phone: \(b.phoneNumber)")
            lines.append("    Room \(b.room.number)  |  \(fmtDate(b.checkInDate)) – \(fmtDate(b.checkOutDate))")
            lines.append("    Payment: \(b.paymentMethodEnum.rawValue)  \(b.prize)  [\(b.paymentStatusEnum.rawValue)]")
            if let org = b.organizationName, !org.isEmpty {
                lines.append("    Organization: \(org)")
            }
            lines.append("")
        }
        return lines.joined(separator: "\n")
    }

    // MARK: Helpers
    /// Left-aligns `text` in a column `width` characters wide (like %-Ns, but safe for Swift Strings).
    private func padded(_ text: String, _ width: Int) -> String {
        text.count >= width ? text : text + String(repeating: " ", count: width - text.count)
    }

    private func fmtDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateStyle = .medium
        return f.string(from: date)
    }

    private func fmtDateTime(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return f.string(from: date)
    }
}

// MARK: - Report Type Card
private struct ReportTypeCard: View {
    let type: ReportType
    let isSelected: Bool
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: type.icon)
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(isSelected ? .white : rvPrimary)
                Spacer()
                Text(type.rawValue)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    .foregroundStyle(isSelected ? .white : .primary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                Text(type.description)
                    .font(.system(.caption2, design: .rounded))
                    .foregroundStyle(isSelected ? .white.opacity(0.85) : .secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 120, alignment: .leading)
            .background(isSelected ? type.gradient : LinearGradient(colors: [Color(.systemBackground), Color(.systemBackground)], startPoint: .topLeading, endPoint: .bottomTrailing))
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: isSelected ? rvPrimary.opacity(0.30) : .black.opacity(0.07), radius: 8, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .strokeBorder(isSelected ? Color.clear : rvPrimary.opacity(0.15), lineWidth: 1.5)
            )
        }
        .buttonStyle(.plain)
    }
}
