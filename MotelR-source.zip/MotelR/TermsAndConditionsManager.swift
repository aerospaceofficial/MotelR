//
//  TermsAndConditionsManager.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 6/20/25.
//

import Foundation

class TermsAndConditionsManager: ObservableObject {
    static let shared = TermsAndConditionsManager()
    
    @Published var currentTerms: String = ""
    @Published var termsVersion: String = "1.0"
    
    private let termsKey = "motel_terms_and_conditions"
    private let versionKey = "motel_terms_version"
    
    private init() {
        loadTerms()
        // Terms edited on another of the owner's devices.
        NotificationCenter.default.addObserver(
            forName: SettingsSync.didChangeExternally,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.loadTerms()
        }
    }
    
    func loadTerms() {
        currentTerms = UserDefaults.standard.string(forKey: termsKey) ?? defaultTerms
        termsVersion = UserDefaults.standard.string(forKey: versionKey) ?? "1.0"
    }
    
    func saveTerms(_ terms: String) {
        currentTerms = terms
        SettingsSync.shared.set(terms, forKey: termsKey)
        // Update version when terms are modified
        let newVersion = incrementVersion(termsVersion)
        termsVersion = newVersion
        SettingsSync.shared.set(newVersion, forKey: versionKey)
    }

    /// Puts back terms from a backup exactly as they were, without bumping the version.
    func restoreTerms(_ terms: String, version: String?) {
        currentTerms = terms
        SettingsSync.shared.set(terms, forKey: termsKey)
        if let version {
            termsVersion = version
            SettingsSync.shared.set(version, forKey: versionKey)
        }
    }
    
    private func incrementVersion(_ version: String) -> String {
        let components = version.split(separator: ".")
        if components.count >= 2,
           let major = Int(components[0]),
           let minor = Int(components[1]) {
            return "\(major).\(minor + 1)"
        }
        return "1.1"
    }
    
    private var defaultTerms: String {
        return """
TERMS AND CONDITIONS OF STAY

1. CHECK-IN AND CHECK-OUT
• Check-in time: 3:00 PM
• Check-out time: 11:00 AM
• Early check-in or late check-out may be available for an additional fee

2. PAYMENT TERMS
• Payment is due at time of check-in
• We accept cash, credit cards, checks, and organizational billing
• All rates are subject to applicable taxes
• Additional charges may apply for extra services

3. GUEST RESPONSIBILITIES
• Maximum occupancy must not be exceeded
• Guests are responsible for any damage to the room or property
• Smoking is prohibited in all rooms
• Pets may be allowed with prior approval and additional deposit

4. CANCELLATION POLICY
• Cancellations must be made 24 hours prior to arrival
• No-shows will be charged for one night
• Early departure does not guarantee refund

5. LIABILITY
• The motel is not responsible for lost, stolen, or damaged personal items
• Guests use facilities at their own risk
• The motel reserves the right to refuse service

6. HOUSE RULES
• Quiet hours: 10:00 PM - 8:00 AM
• No parties or large gatherings in rooms
• Identification required for all guests
• Management reserves the right to enter rooms for safety or maintenance

7. AGREEMENT
By signing below, guest acknowledges reading and agreeing to these terms and conditions.

Guest Signature: _________________________ Date: _____________

For questions or concerns, please contact the front desk.
"""
    }
}
