//
//  BackupManager.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/12/24.
//

import Foundation
import CryptoKit
import CoreData


struct BackupRoom: Codable {
    let id: UUID
    let number: Int16
    let name: String
    let members: String
    
    init(from cdRoom: CDRoom) {
        self.id = cdRoom.id
        self.number = cdRoom.number
        self.name = cdRoom.name
        self.members = cdRoom.members
    }
}

struct BackupIncident: Codable {
    let id: UUID
    let customerName: String
    let customerID: String
    let incidentDate: Date
    let incidentDescription: String
    let severity: String
    let isResolved: Bool
    let resolutionNotes: String?
    let reportedBy: String
    let createdAt: Date
    let updatedAt: Date
    
    init(from cdIncident: CDIncidentReport) {
        self.id = cdIncident.id
        self.customerName = cdIncident.customerName
        self.customerID = cdIncident.customerID
        self.incidentDate = cdIncident.incidentDate
        self.incidentDescription = cdIncident.incidentDescription
        self.severity = cdIncident.severity
        self.isResolved = cdIncident.isResolved
        self.resolutionNotes = cdIncident.resolutionNotes
        self.reportedBy = cdIncident.reportedBy
        self.createdAt = cdIncident.createdAt
        self.updatedAt = cdIncident.updatedAt
    }
}
// Update the BackupBooking struct in BackupManager.swift to include signature fields
struct BackupBooking: Codable {
    let id: UUID
    let roomId: UUID
    let customerName: String
    let phoneNumber: String
    let drivingLicenseNumber: String
    let address: String
    let city: String
    let state: String
    let zipCode: String
    let licenseImageData: Data?  // nil for bookings where the photo is missing
    let paymentMethod: String
    let cardType: String?
    let checkNumber: String?
    let organizationName: String?
    let prize: String
    let numberOfDays: Int16
    let checkInDate: Date
    let checkOutDate: Date
    let isTaxed: Bool
    let isHistory: Bool
    let paymentStatus: String
    
    // NEW: Signature fields
    let signatureImageData: Data?
    let signatureDate: Date?
    let termsVersion: String?
    
    init(from cdBooking: CDBooking) {
        self.id = cdBooking.id
        self.roomId = cdBooking.room.id
        self.customerName = cdBooking.customerName
        self.phoneNumber = cdBooking.phoneNumber
        self.drivingLicenseNumber = cdBooking.drivingLicenseNumber
        self.address = cdBooking.address
        self.city = cdBooking.city
        self.state = cdBooking.state
        self.zipCode = cdBooking.zipCode
        // Inside the booking for current builds, or a legacy file on disk.
        self.licenseImageData = cdBooking.licensePhotoData
        self.paymentMethod = cdBooking.paymentMethodEnum.rawValue
        self.cardType = cdBooking.cardType
        self.checkNumber = cdBooking.checkNumber
        self.organizationName = cdBooking.organizationName
        self.prize = cdBooking.prize
        self.numberOfDays = cdBooking.numberOfDays
        self.checkInDate = cdBooking.checkInDate
        self.checkOutDate = cdBooking.checkOutDate
        self.isTaxed = cdBooking.isTaxed
        self.isHistory = cdBooking.isHistory
        self.paymentStatus = cdBooking.paymentStatus
        
        // NEW: Include signature data
        self.signatureImageData = cdBooking.signatureImageData
        self.signatureDate = cdBooking.signatureDate
        self.termsVersion = cdBooking.termsVersion
    }
}
class BackupManager {
    static let shared = BackupManager()
    private let fileManager = FileManager.default
    
    // Persistent 256-bit key stored in Keychain — survives reinstalls
    private var encryptionKey: SymmetricKey {
        SecurityManager.shared.getOrCreateBackupKey()
    }
    
    /// Local backups live in Application Support, not Documents: the app turns on
    /// iTunes/Files file sharing, and this folder holds guest PII.
    func getBackupURL() -> URL? {
        guard let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return nil
        }
        let url = appSupport.appendingPathComponent("MotelRBackup")
        try? fileManager.createDirectory(
            at: appSupport,
            withIntermediateDirectories: true,
            attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication]
        )
        migrateLegacyBackupIfNeeded(to: url)
        return url
    }

    /// Earlier builds kept the backup in Documents. Move it once, then clean up.
    private static var didMigrateBackup = false
    private func migrateLegacyBackupIfNeeded(to newURL: URL) {
        guard !Self.didMigrateBackup else { return }
        Self.didMigrateBackup = true

        guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let legacy = documents.appendingPathComponent("MotelRBackup")
        guard fileManager.fileExists(atPath: legacy.path) else { return }

        if !fileManager.fileExists(atPath: newURL.path) {
            try? fileManager.moveItem(at: legacy, to: newURL)
        } else {
            try? fileManager.removeItem(at: legacy)
        }
        // Older backups shipped the raw data key beside the ciphertext. Remove it —
        // the key belongs in the Keychain, never on disk in the clear.
        try? fileManager.removeItem(at: newURL.appendingPathComponent("key.dat"))
    }
    
    func encrypt(_ data: Data) throws -> Data {
        let sealedBox = try AES.GCM.seal(data, using: encryptionKey)
        guard let combined = sealedBox.combined else {
            throw BackupError.restoreFailed
        }
        return combined
    }
    
    func decrypt(_ data: Data) throws -> Data {
        let sealedBox = try AES.GCM.SealedBox(combined: data)
        return try AES.GCM.open(sealedBox, using: encryptionKey)
    }
    
    func createBackup(motelData: MotelData) throws {
        try CoreDataManager.shared.context.save()
        
        print("Creating backup with \(motelData.history.count) historical bookings")

        guard let backupURL = getBackupURL(),
              let documentsDir = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {
            throw BackupError.invalidDirectory
        }

        // Write everything to a temp folder first. Only swap it in once all
        // files are written successfully — so the previous backup is never
        // touched until we know the new one is complete.
        let tempURL = documentsDir.appendingPathComponent("MotelRBackup_tmp_\(UUID().uuidString)")
        try fileManager.createDirectory(at: tempURL, withIntermediateDirectories: true)

        do {
            let encoder = JSONEncoder()

            // NOTE: the data key is deliberately NOT written here. Portability across
            // devices is handled by Export Backup, which wraps the key with a password
            // the user chooses. Writing it in the clear would make the backup readable
            // by anyone who obtained the file.

            // Rooms
            let encryptedRoomsData = try encrypt(try encoder.encode(motelData.rooms.map { BackupRoom(from: $0) }))
            try encryptedRoomsData.write(to: tempURL.appendingPathComponent("rooms.encrypted"))

            // Bookings
            let encryptedBookingsData = try encrypt(try encoder.encode(motelData.bookings.map { BackupBooking(from: $0) }))
            try encryptedBookingsData.write(to: tempURL.appendingPathComponent("bookings.encrypted"))

            // History
            let backupHistory = motelData.history.map { BackupBooking(from: $0) }
            print("Backing up \(backupHistory.count) historical bookings")
            let encryptedHistoryData = try encrypt(try encoder.encode(backupHistory))
            try encryptedHistoryData.write(to: tempURL.appendingPathComponent("history.encrypted"))

            // Incidents
            let encryptedIncidentsData = try encrypt(try encoder.encode(motelData.incidents.map { BackupIncident(from: $0) }))
            try encryptedIncidentsData.write(to: tempURL.appendingPathComponent("incidents.encrypted"))

            // Settings
            let settings: [String: Any] = [
                "taxRate": motelData.taxRate,
                "businessName": motelData.businessName,
                "pinHash": SecurityManager.shared.getStoredPinHash() ?? "",
                "termsAndConditions": TermsAndConditionsManager.shared.currentTerms,
                "termsVersion": TermsAndConditionsManager.shared.termsVersion,
                "roomStatuses": RoomHousekeeping.allStatuses(),
                "checkOutTime": (UserDefaults.standard.object(forKey: "checkOutTime") as? Date)?.timeIntervalSince1970 ?? 0
            ]
            let encryptedSettingsData = try encrypt(try JSONSerialization.data(withJSONObject: settings))
            try encryptedSettingsData.write(to: tempURL.appendingPathComponent("settings.encrypted"))

        } catch {
            // Something went wrong — clean up temp folder and leave existing backup intact
            try? fileManager.removeItem(at: tempURL)
            throw error
        }

        // All files written successfully — atomically replace the old backup
        if fileManager.fileExists(atPath: backupURL.path) {
            try fileManager.removeItem(at: backupURL)
        }
        try fileManager.moveItem(at: tempURL, to: backupURL)
    }
    
    func restoreFromBackup() throws -> MotelData {
        guard let backupURL = getBackupURL() else {
            throw BackupError.invalidDirectory
        }

        let decoder = JSONDecoder()

        // Resolve which key to use: prefer key.dat bundled in the backup (cross-device),
        // fall back to the device Keychain key for old backups that predate key.dat.
        let keyFileURL = backupURL.appendingPathComponent("key.dat")
        let restoreKey: SymmetricKey
        if let keyData = try? Data(contentsOf: keyFileURL), keyData.count == 32 {
            restoreKey = SymmetricKey(data: keyData)
        } else {
            restoreKey = encryptionKey
        }

        func decryptWithRestoreKey(_ data: Data) throws -> Data {
            let sealedBox = try AES.GCM.SealedBox(combined: data)
            return try AES.GCM.open(sealedBox, using: restoreKey)
        }

        // --- STEP 1: Decrypt and validate ALL backup files BEFORE touching existing data.
        // If any file is corrupted or the key is wrong, we throw here and the live data is untouched.
        let backupRooms: [BackupRoom]
        let backupBookings: [BackupBooking]
        let backupHistory: [BackupBooking]
        let backupIncidents: [BackupIncident]

        let encryptedRoomsData = try Data(contentsOf: backupURL.appendingPathComponent("rooms.encrypted"))
        backupRooms = try decoder.decode([BackupRoom].self, from: try decryptWithRestoreKey(encryptedRoomsData))

        let encryptedBookingsData = try Data(contentsOf: backupURL.appendingPathComponent("bookings.encrypted"))
        backupBookings = try decoder.decode([BackupBooking].self, from: try decryptWithRestoreKey(encryptedBookingsData))

        let encryptedHistoryData = try Data(contentsOf: backupURL.appendingPathComponent("history.encrypted"))
        backupHistory = try decoder.decode([BackupBooking].self, from: try decryptWithRestoreKey(encryptedHistoryData))

        let encryptedIncidentsData = try Data(contentsOf: backupURL.appendingPathComponent("incidents.encrypted"))
        backupIncidents = try decoder.decode([BackupIncident].self, from: try decryptWithRestoreKey(encryptedIncidentsData))

        // --- STEP 2: All data validated — now safe to wipe existing data and restore.
        // Object-by-object deletes rather than NSBatchDeleteRequest: batch deletes are
        // not supported by NSPersistentCloudKitContainer (they never sync to other
        // devices and leave the view context holding objects that no longer exist).
        let context = CoreDataManager.shared.context
        try CoreDataManager.shared.deleteAllObjects(in: context)

        let motelData = MotelData()

        // --- STEP 3: Insert rooms (use pre-decoded arrays from Step 1).
        var roomsDict: [UUID: CDRoom] = [:]
        for backupRoom in backupRooms.sorted(by: { $0.number < $1.number }) {
            let room = CDRoom(context: context)
            room.id = backupRoom.id
            room.number = backupRoom.number
            room.name = backupRoom.name
            room.members = backupRoom.members
            roomsDict[room.id] = room
        }

        func insertBooking(from backup: BackupBooking, isHistory: Bool) {
            guard let room = roomsDict[backup.roomId] else { return }
            let booking = CDBooking(context: context)
            booking.id = backup.id
            booking.room = room
            booking.customerName = backup.customerName
            booking.phoneNumber = backup.phoneNumber
            booking.drivingLicenseNumber = backup.drivingLicenseNumber
            booking.address = backup.address
            booking.city = backup.city
            booking.state = backup.state
            booking.zipCode = backup.zipCode
            if let imageData = backup.licenseImageData, !imageData.isEmpty {
                // Stored in the booking so it syncs, like a fresh check-in.
                booking.licenseImageData = LicenseImageManager.prepareForStorage(imageData)
                booking.licenseImageFileName = nil
            }
            booking.paymentMethod = backup.paymentMethod
            booking.cardType = backup.cardType
            booking.checkNumber = backup.checkNumber
            booking.organizationName = backup.organizationName
            booking.prize = backup.prize
            booking.numberOfDays = backup.numberOfDays
            booking.checkInDate = backup.checkInDate
            booking.checkOutDate = backup.checkOutDate
            booking.isTaxed = backup.isTaxed
            booking.isHistory = isHistory
            booking.paymentStatus = backup.paymentStatus
            booking.signatureImageData = backup.signatureImageData
            booking.signatureDate = backup.signatureDate
            booking.termsVersion = backup.termsVersion
        }

        for booking in backupBookings { insertBooking(from: booking, isHistory: false) }
        print("Restoring \(backupHistory.count) historical bookings")
        for booking in backupHistory  { insertBooking(from: booking, isHistory: true) }

        for backupIncident in backupIncidents {
            let incident = CDIncidentReport(context: context)
            incident.id = backupIncident.id
            incident.customerName = backupIncident.customerName
            incident.customerID = backupIncident.customerID
            incident.incidentDate = backupIncident.incidentDate
            incident.incidentDescription = backupIncident.incidentDescription
            incident.severity = backupIncident.severity
            incident.isResolved = backupIncident.isResolved
            incident.resolutionNotes = backupIncident.resolutionNotes
            incident.reportedBy = backupIncident.reportedBy
            incident.createdAt = backupIncident.createdAt
            incident.updatedAt = backupIncident.updatedAt
        }

        try context.save()

        // Restore settings
        if let encryptedSettingsData = try? Data(contentsOf: backupURL.appendingPathComponent("settings.encrypted")) {
            let decryptedSettingsData = try decryptWithRestoreKey(encryptedSettingsData)
            if let settings = try? JSONSerialization.jsonObject(with: decryptedSettingsData) as? [String: Any] {
                motelData.taxRate = settings["taxRate"] as? Double ?? 0.0
                motelData.businessName = settings["businessName"] as? String ?? "Motel R"
                if let terms = settings["termsAndConditions"] as? String {
                    TermsAndConditionsManager.shared.restoreTerms(terms, version: settings["termsVersion"] as? String)
                }
                if let statuses = settings["roomStatuses"] as? [String: String] {
                    for (key, raw) in statuses where key.hasPrefix(SettingsSync.roomStatusPrefix) {
                        SettingsSync.shared.set(raw, forKey: key)
                    }
                }
                if let seconds = settings["checkOutTime"] as? Double, seconds > 0 {
                    SettingsSync.shared.set(Date(timeIntervalSince1970: seconds), forKey: "checkOutTime")
                }
            }
        }

        // Refresh motelData arrays
        let roomsFetch: NSFetchRequest<CDRoom> = CDRoom.fetchRequest()
        roomsFetch.sortDescriptors = [NSSortDescriptor(key: "number", ascending: true)]

        let bookingsFetch: NSFetchRequest<CDBooking> = CDBooking.fetchRequest()
        bookingsFetch.predicate = NSPredicate(format: "isHistory == NO")
        bookingsFetch.sortDescriptors = [NSSortDescriptor(key: "checkInDate", ascending: true)]

        let historyFetch: NSFetchRequest<CDBooking> = CDBooking.fetchRequest()
        historyFetch.predicate = NSPredicate(format: "isHistory == YES")
        historyFetch.sortDescriptors = [NSSortDescriptor(key: "checkOutDate", ascending: false)]

        let incidentsFetch: NSFetchRequest<CDIncidentReport> = CDIncidentReport.fetchRequest()
        incidentsFetch.sortDescriptors = [NSSortDescriptor(key: "incidentDate", ascending: false)]

        motelData.rooms     = try context.fetch(roomsFetch)
        motelData.bookings  = try context.fetch(bookingsFetch)
        motelData.history   = try context.fetch(historyFetch)
        motelData.incidents = try context.fetch(incidentsFetch)

        print("Restored \(motelData.history.count) historical bookings, \(motelData.incidents.count) incidents")
        return motelData
    }
    
    func backupExists() -> Bool {
        guard let backupURL = getBackupURL() else {
            print("BackupManager: No backup URL found")
            return false
        }
        
        // First check if directory exists
        var isDirectory: ObjCBool = false
        let directoryExists = FileManager.default.fileExists(atPath: backupURL.path, isDirectory: &isDirectory)
        print("BackupManager: Backup directory exists: \(directoryExists), isDirectory: \(isDirectory.boolValue)")
        
        if !directoryExists || !isDirectory.boolValue {
            print("BackupManager: Backup directory not found or is not a directory")
            return false
        }
        
        let requiredFiles = ["rooms.encrypted", "bookings.encrypted", "history.encrypted", "incidents.encrypted", "settings.encrypted"]
        
        print("BackupManager: Checking files in \(backupURL.path)")
        
        let allExist = requiredFiles.allSatisfy { filename in
            let filePath = backupURL.appendingPathComponent(filename).path
            let exists = FileManager.default.fileExists(atPath: filePath)
            print("BackupManager: Checking \(filename): \(exists)")
            
            if exists {
                // Get file size for additional verification
                if let attributes = try? FileManager.default.attributesOfItem(atPath: filePath) {
                    let fileSize = attributes[.size] as? UInt64 ?? 0
                    print("BackupManager: \(filename) size: \(fileSize) bytes")
                }
            }
            
            return exists
        }
        
        print("BackupManager: All required files exist: \(allExist)")
        return allExist
    }
    
    enum BackupError: Error {
        case invalidDirectory
        case backupNotFound
        case restoreFailed
    }
}


