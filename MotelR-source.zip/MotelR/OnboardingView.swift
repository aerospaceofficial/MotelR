//
//  OnboardingView.swift
//  MotelR 2.0 — by New Journey
//
//  First-run walkthrough. This is the only explanation most people will ever get,
//  so it stays short, shows what the app actually looks like, and hands over to a
//  real first action rather than dumping the user on an empty dashboard.
//

import SwiftUI

// MARK: - Design Tokens

private let onbPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let onbDeep    = Color(red: 0.05, green: 0.12, blue: 0.65)
private let onbGold    = Color(red: 0.96, green: 0.65, blue: 0.14)
private let onbGreen   = Color(red: 0.36, green: 0.90, blue: 0.52)
/// Accents sit on the blue gradient, so they have to be lighter than the brand blue
/// to stay legible — the brand blue itself disappears against the background.
private let onbSky     = Color(red: 0.58, green: 0.82, blue: 1.00)

private let onbGradient = LinearGradient(
    colors: [onbPrimary, onbDeep],
    startPoint: .topLeading,
    endPoint: .bottomTrailing
)

// MARK: - Page Model

private struct OnboardingPage: Identifiable {
    let id = UUID()
    let icon: String
    let accent: Color
    let title: String
    let body: String
    /// Small feature bullets shown under the description.
    let highlights: [String]
}

private let onboardingPages: [OnboardingPage] = [
    OnboardingPage(
        icon: "building.2.fill",
        accent: onbSky,
        title: "Your front desk,\non one screen",
        body: "MotelR replaces the paper register. Every room, guest and payment lives in one place — and it works even when the internet doesn't.",
        highlights: [
            "Works completely offline",
            "Syncs across your iPhone and iPad",
            "No monthly hardware, no server"
        ]
    ),
    OnboardingPage(
        icon: "bed.double.fill",
        accent: onbGreen,
        title: "See every room\nat a glance",
        body: "A colour-coded grid shows what's occupied, what's free and what's being cleaned — so you can answer \"any vacancy?\" in a second.",
        highlights: [
            "Occupied, available and cleaning status",
            "Guest name shown on each room",
            "Tap a room to check out or edit it"
        ]
    ),
    OnboardingPage(
        icon: "person.badge.plus.fill",
        accent: onbGold,
        title: "Check a guest in\nin under a minute",
        body: "Guided check-in captures the details you need, takes a photo of the licence, and collects a signature on the terms.",
        highlights: [
            "Photo of driver's licence",
            "On-screen signature capture",
            "Printable PDF receipt"
        ]
    ),
    OnboardingPage(
        icon: "chart.bar.fill",
        accent: onbSky,
        title: "Know what you\nactually earned",
        body: "Revenue, occupancy rate and your best-performing rooms — calculated automatically from your bookings.",
        highlights: [
            "Daily, weekly, monthly and yearly views",
            "Revenue split by payment method",
            "Track unpaid company invoices"
        ]
    ),
    OnboardingPage(
        icon: "lock.shield.fill",
        accent: onbGreen,
        title: "Your guests' data\nstays yours",
        body: "Everything is stored on your own device and your private iCloud. Lock the app with a PIN and export encrypted backups whenever you like.",
        highlights: [
            "PIN lock for shared front-desk devices",
            "Password-protected backup files",
            "Nothing is ever sold or shared"
        ]
    )
]

// MARK: - OnboardingView

struct OnboardingView: View {

    /// Called when the walkthrough is finished or skipped.
    let onFinish: () -> Void

    @State private var page = 0
    @State private var appeared = false

    private var isLastPage: Bool { page == onboardingPages.count - 1 }

    var body: some View {
        ZStack {
            onbGradient.ignoresSafeArea()

            // Soft background bloom, echoing the dashboard header.
            GeometryReader { geo in
                Circle()
                    .fill(Color.white.opacity(0.06))
                    .frame(width: geo.size.width * 0.9)
                    .offset(x: geo.size.width * 0.35, y: -geo.size.width * 0.25)
            }
            .ignoresSafeArea()

            VStack(spacing: 0) {
                header
                pager
                footer
            }
            .frame(maxWidth: 640)
            .frame(maxWidth: .infinity)
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 16)
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.45)) { appeared = true }
        }
    }

    // MARK: Header

    private var header: some View {
        HStack {
            HStack(alignment: .top, spacing: 0) {
                Text("Motel")
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text("R")
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .foregroundStyle(Color(red: 0.55, green: 0.80, blue: 1.00))
                Text("2.0")
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .foregroundStyle(onbGold)
                    .offset(y: -6)
                    .padding(.leading, 2)
            }

            Spacer()

            if !isLastPage {
                Button("Skip") { finish() }
                    .font(.system(size: 16, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.75))
            }
        }
        .padding(.horizontal, 28)
        .padding(.top, 12)
        .frame(height: 44)
    }

    // MARK: Pager

    private var pager: some View {
        TabView(selection: $page) {
            ForEach(Array(onboardingPages.enumerated()), id: \.element.id) { index, item in
                pageContent(item)
                    .tag(index)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .animation(.easeInOut(duration: 0.25), value: page)
    }

    private func pageContent(_ item: OnboardingPage) -> some View {
        VStack(spacing: 0) {
            Spacer(minLength: 12)

            // Icon badge
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.12))
                    .frame(width: 132, height: 132)
                Circle()
                    .stroke(item.accent.opacity(0.55), lineWidth: 1.5)
                    .frame(width: 132, height: 132)
                Image(systemName: item.icon)
                    .font(.system(size: 54, weight: .medium))
                    .foregroundStyle(.white)
            }
            .padding(.bottom, 32)

            Text(item.title)
                .font(.system(size: 30, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 24)

            Text(item.body)
                .font(.system(size: 16, design: .rounded))
                .foregroundStyle(.white.opacity(0.78))
                .multilineTextAlignment(.center)
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.horizontal, 32)
                .padding(.top, 14)

            VStack(alignment: .leading, spacing: 12) {
                ForEach(item.highlights, id: \.self) { line in
                    HStack(alignment: .firstTextBaseline, spacing: 12) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(item.accent)
                        Text(line)
                            .font(.system(size: 15, design: .rounded))
                            .foregroundStyle(.white.opacity(0.92))
                            .fixedSize(horizontal: false, vertical: true)
                        Spacer(minLength: 0)
                    }
                }
            }
            .padding(18)
            .frame(maxWidth: 420)
            .background(Color.white.opacity(0.10))
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(
                RoundedRectangle(cornerRadius: 18)
                    .strokeBorder(Color.white.opacity(0.14), lineWidth: 1)
            )
            .padding(.horizontal, 28)
            .padding(.top, 28)

            Spacer(minLength: 12)
        }
    }

    // MARK: Footer

    private var footer: some View {
        VStack(spacing: 20) {
            // Page dots
            HStack(spacing: 8) {
                ForEach(0..<onboardingPages.count, id: \.self) { index in
                    Capsule()
                        .fill(index == page ? Color.white : Color.white.opacity(0.32))
                        .frame(width: index == page ? 22 : 8, height: 8)
                        .animation(.spring(response: 0.3, dampingFraction: 0.7), value: page)
                }
            }

            Button {
                if isLastPage {
                    finish()
                } else {
                    withAnimation(.easeInOut(duration: 0.25)) { page += 1 }
                }
            } label: {
                Text(isLastPage ? "Get Started" : "Continue")
                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                    .foregroundStyle(onbDeep)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 17)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(color: .black.opacity(0.18), radius: 10, y: 4)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 28)
        }
        .padding(.bottom, 28)
    }

    private func finish() {
        withAnimation(.easeInOut(duration: 0.3)) { appeared = false }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.28) { onFinish() }
    }
}

#Preview {
    OnboardingView(onFinish: {})
}
