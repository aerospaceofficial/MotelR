//
//  LaunchScreenView.swift
//  MotelR 2.0 — by New Journey
//

import SwiftUI

struct LaunchScreenView: View {

    var onDismiss: (() -> Void)? = nil

    // MARK: - Animation states
    @State private var logoScale: CGFloat       = 0.35
    @State private var logoOpacity: Double      = 0
    @State private var glowPulse: Bool          = false
    @State private var glowRingScale: CGFloat   = 0.6
    @State private var glowRingOpacity: Double  = 0

    @State private var titleOpacity: Double     = 0
    @State private var titleOffset: CGFloat     = 24
    @State private var subtitleOpacity: Double  = 0
    @State private var bylineOpacity: Double    = 0

    @State private var loadingProgress: CGFloat = 0
    @State private var dot1Scale: CGFloat       = 0.6
    @State private var dot2Scale: CGFloat       = 0.6
    @State private var dot3Scale: CGFloat       = 0.6
    @State private var shimmerOffset: CGFloat   = -180

    // MARK: - Body

    var body: some View {
        ZStack {

            // ── Deep navy-to-indigo background ───────────────────────────
            LinearGradient(
                colors: [
                    Color(red: 0.04, green: 0.08, blue: 0.20),
                    Color(red: 0.07, green: 0.14, blue: 0.35),
                    Color(red: 0.10, green: 0.22, blue: 0.52),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            // Ambient radial glow
            RadialGradient(
                colors: [
                    Color(red: 0.25, green: 0.50, blue: 1.00)
                        .opacity(glowPulse ? 0.28 : 0.10),
                    Color.clear
                ],
                center: .center,
                startRadius: 0,
                endRadius: 340
            )
            .ignoresSafeArea()
            .animation(
                .easeInOut(duration: 2.4).repeatForever(autoreverses: true),
                value: glowPulse
            )

            // ── Content column ────────────────────────────────────────────
            VStack(spacing: 0) {

                Spacer()

                // ── NJ Monogram + glow ring ───────────────────────────────
                ZStack {

                    // Outer pulsing glow ring
                    Circle()
                        .stroke(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.55),
                                    Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.08),
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 2
                        )
                        .frame(width: 156, height: 156)
                        .scaleEffect(glowRingScale)
                        .opacity(glowRingOpacity)
                        .scaleEffect(glowPulse ? 1.06 : 1.0)
                        .animation(
                            .easeInOut(duration: 2.4).repeatForever(autoreverses: true),
                            value: glowPulse
                        )

                    // Inner glow halo
                    Circle()
                        .fill(
                            RadialGradient(
                                colors: [
                                    Color(red: 0.20, green: 0.45, blue: 0.95)
                                        .opacity(glowPulse ? 0.38 : 0.18),
                                    Color.clear
                                ],
                                center: .center,
                                startRadius: 0,
                                endRadius: 76
                            )
                        )
                        .frame(width: 152, height: 152)
                        .animation(
                            .easeInOut(duration: 2.4).repeatForever(autoreverses: true),
                            value: glowPulse
                        )

                    // Filled circle (logo background)
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.18, green: 0.27, blue: 0.90),
                                    Color(red: 0.05, green: 0.12, blue: 0.65),
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 116, height: 116)
                        .shadow(
                            color: Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.65),
                            radius: 28, x: 0, y: 10
                        )

                    // Shimmer sweep across the circle
                    RoundedRectangle(cornerRadius: 58)
                        .fill(
                            LinearGradient(
                                colors: [.clear, .white.opacity(0.30), .clear],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: 70, height: 116)
                        .offset(x: shimmerOffset)
                        .clipShape(Circle())

                    // NJ Monogram text
                    HStack(spacing: 1) {
                        Text("N")
                            .font(.system(size: 42, weight: .black, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.white, Color(white: 0.90)],
                                    startPoint: .top, endPoint: .bottom
                                )
                            )
                        Text("J")
                            .font(.system(size: 42, weight: .black, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [
                                        Color(red: 0.96, green: 0.65, blue: 0.14),
                                        Color(red: 0.88, green: 0.48, blue: 0.08),
                                    ],
                                    startPoint: .top, endPoint: .bottom
                                )
                            )
                    }
                }
                .scaleEffect(logoScale)
                .opacity(logoOpacity)
                .padding(.bottom, 36)

                // ── MotelR 2.0 title ──────────────────────────────────────
                HStack(alignment: .top, spacing: 0) {
                    Text("Motel")
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Text("R")
                        .font(.system(size: 48, weight: .black, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.55, green: 0.80, blue: 1.00),
                                    Color(red: 0.30, green: 0.62, blue: 1.00),
                                ],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                    // "2.0" superscript in gold
                    Text("2.0")
                        .font(.system(size: 18, weight: .heavy, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.96, green: 0.65, blue: 0.14),
                                    Color(red: 0.88, green: 0.48, blue: 0.08),
                                ],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                        .offset(y: -14)
                        .padding(.leading, 3)
                }
                .offset(y: titleOffset)
                .opacity(titleOpacity)

                // ── "by New Journey" byline ───────────────────────────────
                Text("by New Journey")
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.55))
                    .tracking(2.8)
                    .padding(.top, 8)
                    .opacity(bylineOpacity)

                Spacer()

                // ── Animated loading dots ─────────────────────────────────
                HStack(spacing: 10) {
                    ForEach(0..<3, id: \.self) { index in
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [
                                        Color(red: 0.96, green: 0.65, blue: 0.14),
                                        Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.5),
                                    ],
                                    startPoint: .top, endPoint: .bottom
                                )
                            )
                            .frame(width: 8, height: 8)
                            .scaleEffect(index == 0 ? dot1Scale : index == 1 ? dot2Scale : dot3Scale)
                    }
                }
                .padding(.bottom, 56)
                .opacity(subtitleOpacity)
            }
        }
        .onAppear { runAnimations() }
    }

    // MARK: - Animation sequence

    private func runAnimations() {
        // 1. Logo pops in with spring
        withAnimation(.spring(response: 0.70, dampingFraction: 0.58)) {
            logoScale   = 1.0
            logoOpacity = 1.0
        }

        // 2. Glow ring expands
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            withAnimation(.spring(response: 0.65, dampingFraction: 0.55)) {
                glowRingScale   = 1.0
                glowRingOpacity = 1.0
            }
        }

        // 3. Shimmer sweep
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.40) {
            withAnimation(.easeInOut(duration: 0.75)) {
                shimmerOffset = 180
            }
        }

        // 4. Glow pulse starts repeating
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.50) {
            glowPulse = true
        }

        // 5. Title slides up
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.65) {
            withAnimation(.spring(response: 0.60, dampingFraction: 0.72)) {
                titleOpacity = 1.0
                titleOffset  = 0
            }
        }

        // 6. Byline fades in
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.00) {
            withAnimation(.easeIn(duration: 0.45)) {
                bylineOpacity = 1.0
            }
        }

        // 7. Loading dots fade in
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.30) {
            withAnimation(.easeIn(duration: 0.35)) {
                subtitleOpacity = 1.0
            }
            startDotBounce()
        }

        // 8. Auto-dismiss after 3 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            onDismiss?()
        }
    }

    // Staggered dot bounce loop
    private func startDotBounce() {
        let bounce: (inout CGFloat) -> Void = { scale in
            scale = 1.45
        }
        let restore: (inout CGFloat) -> Void = { scale in
            scale = 0.6
        }

        func cycle(offset: Double) {
            DispatchQueue.main.asyncAfter(deadline: .now() + offset) {
                withAnimation(.spring(response: 0.28, dampingFraction: 0.45)) {
                    dot1Scale = 1.45
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + offset + 0.16) {
                withAnimation(.spring(response: 0.28, dampingFraction: 0.55)) {
                    dot1Scale = 0.6
                    dot2Scale = 1.45
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + offset + 0.32) {
                withAnimation(.spring(response: 0.28, dampingFraction: 0.55)) {
                    dot2Scale = 0.6
                    dot3Scale = 1.45
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + offset + 0.48) {
                withAnimation(.spring(response: 0.28, dampingFraction: 0.55)) {
                    dot3Scale = 0.6
                }
            }
        }

        // Run enough cycles to cover the 3-second window
        for i in 0..<4 {
            cycle(offset: Double(i) * 0.80)
        }

        _ = bounce
        _ = restore
    }
}

#Preview {
    LaunchScreenView()
}
