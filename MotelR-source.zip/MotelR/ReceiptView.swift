//  ReceiptView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import UIKit

// MARK: - Design Tokens
private let recPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let recGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let recGold  = Color(red: 0.96, green: 0.65, blue: 0.14)
private let recGreen = Color(red: 0.20, green: 0.78, blue: 0.35)

// MARK: - ReceiptView
struct ReceiptView: View {
    let booking: CDBooking
    @EnvironmentObject var motelData: MotelData
    @State private var shareItems: [Any] = []
    @State private var showingShare = false
    @State private var showingPrintError = false

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .long
        return f
    }()

    private static let shortDateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .medium
        return f
    }()

    private var receiptNumber: String {
        "RCP-\(String(booking.id.uuidString.prefix(8)).uppercased())"
    }

    private var subtotal: Double {
        booking.prizeAmount / (booking.isTaxed ? (1.0 + motelData.taxRate) : 1.0)
    }

    private var taxAmount: Double {
        booking.isTaxed ? subtotal * motelData.taxRate : 0.0
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                receiptCard
                    .padding(.horizontal, 20)
                    .padding(.vertical, 24)

                actionButtons
                    .padding(.horizontal, 20)
                    .padding(.bottom, 32)
            }
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Receipt")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showingShare) {
            SharedActivityView(activityItems: shareItems)
        }
        .alert("Print Unavailable", isPresented: $showingPrintError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("No printers are available on this device.")
        }
    }

    // MARK: - Receipt Card
    private var receiptCard: some View {
        VStack(spacing: 0) {
            // Header band
            VStack(spacing: 6) {
                ZStack {
                    Circle()
                        .fill(recGradient)
                        .frame(width: 56, height: 56)
                    Image(systemName: "building.fill")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(.white)
                }
                Text("MotelR 2.0")
                    .font(.system(.title3, design: .rounded).weight(.bold))
                    .foregroundStyle(.white)
                Text("by New Journey")
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.white.opacity(0.85))
                if !motelData.businessName.isEmpty {
                    Text(motelData.businessName)
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white.opacity(0.90))
                        .padding(.top, 2)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 24)
            .background(recGradient)

            // Receipt body
            VStack(spacing: 0) {
                receiptMetaSection
                dashedDivider
                guestSection
                dashedDivider
                staySection
                dashedDivider
                paymentSection
                dashedDivider
                totalSection
                dashedDivider
                footerSection
            }
            .background(Color(.systemBackground))
        }
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.10), radius: 16, y: 6)
    }

    // MARK: Receipt Meta
    private var receiptMetaSection: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                receiptMetaRow(label: "Receipt #", value: receiptNumber)
                receiptMetaRow(label: "Date", value: Self.shortDateFormatter.string(from: Date()))
                receiptMetaRow(label: "Status", value: booking.paymentStatusEnum.rawValue,
                               valueColor: booking.paymentStatusEnum == .paid ? recGreen : recGold)
            }
            Spacer()
        }
        .padding(16)
    }

    private func receiptMetaRow(label: String, value: String, valueColor: Color = .primary) -> some View {
        HStack(spacing: 6) {
            Text(label + ":")
                .font(.system(.caption, design: .rounded))
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(.caption, design: .rounded).weight(.semibold))
                .foregroundStyle(valueColor)
        }
    }

    // MARK: Guest Section
    private var guestSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionHeader("GUEST INFORMATION")
            infoRow(label: "Name", value: booking.customerName)
            infoRow(label: "Phone", value: booking.phoneNumber)
            if !booking.drivingLicenseNumber.isEmpty {
                infoRow(label: "ID", value: booking.drivingLicenseNumber)
            }
            if !booking.address.isEmpty {
                infoRow(label: "Address", value: "\(booking.address), \(booking.city), \(booking.state) \(booking.zipCode)")
            }
            if let org = booking.organizationName, !org.isEmpty {
                infoRow(label: "Organization", value: org)
            }
        }
        .padding(16)
    }

    // MARK: Stay Section
    private var staySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionHeader("STAY DETAILS")
            infoRow(label: "Room", value: "Room \(booking.room.number) – \(booking.room.name)")
            infoRow(label: "Check-in", value: Self.dateFormatter.string(from: booking.checkInDate))
            infoRow(label: "Check-out", value: Self.dateFormatter.string(from: booking.checkOutDate))
            infoRow(label: "Duration", value: "\(booking.numberOfDays) night\(booking.numberOfDays == 1 ? "" : "s")")
        }
        .padding(16)
    }

    // MARK: Payment Section
    private var paymentSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionHeader("PAYMENT METHOD")
            infoRow(label: "Method", value: booking.paymentMethodEnum.rawValue)
            if let cardType = booking.cardType, !cardType.isEmpty {
                infoRow(label: "Card Type", value: cardType)
            }
            if let checkNum = booking.checkNumber, !checkNum.isEmpty {
                infoRow(label: "Check #", value: checkNum)
            }
        }
        .padding(16)
    }

    // MARK: Total Section
    private var totalSection: some View {
        VStack(spacing: 8) {
            sectionHeader("AMOUNT")
                .frame(maxWidth: .infinity, alignment: .leading)
            HStack {
                Text("Subtotal")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
                Spacer()
                Text(String(format: "$%.2f", subtotal))
                    .font(.system(.subheadline, design: .rounded))
            }
            if booking.isTaxed && motelData.taxRate > 0 {
                HStack {
                    Text("Tax (\(Int(motelData.taxRate * 100))%)")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(String(format: "$%.2f", taxAmount))
                        .font(.system(.subheadline, design: .rounded))
                }
            }
            HStack {
                Text("TOTAL")
                    .font(.system(.headline, design: .rounded).weight(.bold))
                Spacer()
                Text(booking.prize)
                    .font(.system(.title3, design: .rounded).weight(.bold))
                    .foregroundStyle(recPrimary)
            }
        }
        .padding(16)
    }

    // MARK: Footer
    private var footerSection: some View {
        VStack(spacing: 6) {
            Image(systemName: "heart.fill")
                .font(.system(size: 16))
                .foregroundStyle(recPrimary.opacity(0.6))
            Text("Thank you for your stay!")
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(.primary)
            Text("We hope to see you again.")
                .font(.system(.caption, design: .rounded))
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
    }

    // MARK: Action Buttons
    private var actionButtons: some View {
        VStack(spacing: 12) {
            Button {
                sharePDF()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "square.and.arrow.up.fill")
                        .font(.system(size: 16, weight: .semibold))
                    Text("Share PDF")
                        .font(.system(.headline, design: .rounded))
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(recGradient)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: recPrimary.opacity(0.35), radius: 10, y: 4)
            }
            .buttonStyle(.plain)

            Button {
                printReceipt()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "printer.fill")
                        .font(.system(size: 16, weight: .semibold))
                    Text("Print")
                        .font(.system(.headline, design: .rounded))
                }
                .foregroundStyle(recPrimary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(recPrimary.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: Helpers
    private func sectionHeader(_ title: String) -> some View {
        Text(title)
            .font(.system(.caption, design: .rounded).weight(.bold))
            .foregroundStyle(recPrimary.opacity(0.8))
            .tracking(0.5)
    }

    private func infoRow(label: String, value: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text(label + ":")
                .font(.system(.subheadline, design: .rounded))
                .foregroundStyle(.secondary)
                .frame(minWidth: 80, alignment: .leading)
            Text(value)
                .font(.system(.subheadline, design: .rounded).weight(.medium))
                .foregroundStyle(.primary)
                .fixedSize(horizontal: false, vertical: true)
            Spacer()
        }
    }

    private var dashedDivider: some View {
        Rectangle()
            .fill(Color(.separator).opacity(0.4))
            .frame(height: 1)
            .padding(.horizontal, 16)
    }

    private func sharePDF() {
        let data = EnhancedPDFReceiptGenerator.generateProfessionalReceipt(
            booking: booking,
            businessName: motelData.businessName,
            taxRate: motelData.taxRate
        )
        let name = booking.customerName.replacingOccurrences(of: " ", with: "_")
        let tempURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("Receipt_\(name).pdf")
        try? data.write(to: tempURL)
        shareItems = [tempURL]
        showingShare = true
    }

    private func printReceipt() {
        let data = EnhancedPDFReceiptGenerator.generateProfessionalReceipt(
            booking: booking,
            businessName: motelData.businessName,
            taxRate: motelData.taxRate
        )

        let printInfo = UIPrintInfo(dictionary: nil)
        printInfo.jobName = "Receipt – \(booking.customerName)"
        printInfo.outputType = .general

        let controller = UIPrintInteractionController.shared
        controller.printInfo = printInfo
        controller.printingItem = data

        if UIPrintInteractionController.isPrintingAvailable {
            controller.present(animated: true, completionHandler: nil)
        } else {
            showingPrintError = true
        }
    }
}
