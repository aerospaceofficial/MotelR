//  CheckInOutView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

struct CheckInOutView: View {
    @EnvironmentObject var motelData: MotelData
    @State private var selectedTab: CheckInOutTab = .checkedIn
    @State private var searchText: String = ""
    @State private var showCheckInSheet = false

    enum CheckInOutTab: String, CaseIterable {
        case checkedIn = "Checked In"
        case checkIn  = "Check In"
        case checkOut = "Check Out"
    }

    // MARK: - Design tokens
    private let primaryGradient = LinearGradient(
        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                 Color(red: 0.05, green: 0.12, blue: 0.65)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    private let primaryColor  = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let goldColor     = Color(red: 0.96, green: 0.65, blue: 0.14)
    private let greenColor    = Color(red: 0.20, green: 0.78, blue: 0.35)
    private let redColor      = Color(red: 1.0,  green: 0.23, blue: 0.19)

    // MARK: - Filtered bookings
    private var filteredBookings: [CDBooking] {
        let base = motelData.bookings
        guard !searchText.trimmingCharacters(in: .whitespaces).isEmpty else { return base }
        let q = searchText.lowercased()
        return base.filter {
            $0.customerName.lowercased().contains(q) ||
            String($0.room.number).contains(q)
        }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                // Background
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()

                VStack(spacing: 0) {
                    // Header bar with gradient
                    headerView
                    // Segmented tab bar
                    tabBar
                    // Content
                    tabContent
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showCheckInSheet) {
                CheckInView()
                    .environmentObject(motelData)
            }
        }
    }

    // MARK: - Header
    private var headerView: some View {
        VStack(spacing: 0) {
            VStack(spacing: 4) {
                Text(motelData.businessName)
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text("Bookings Hub")
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.80))
                // Quick stats pill
                HStack(spacing: 20) {
                    quickStatPill(
                        label: "Occupied",
                        value: motelData.occupiedRoomCount,
                        icon: "bed.double.fill",
                        color: goldColor
                    )
                    quickStatPill(
                        label: "Available",
                        value: max(0, motelData.rooms.count - motelData.occupiedRoomCount),
                        icon: "door.left.hand.open",
                        color: greenColor
                    )
                }
                .padding(.top, 6)
            }
            .padding(.top, 12)
            .padding(.bottom, 18)
        }
        .frame(maxWidth: .infinity)
        .background(primaryGradient.ignoresSafeArea(edges: .top))
    }

    private func quickStatPill(label: String, value: Int, icon: String, color: Color) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
            Text("\(value) \(label)")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
        }
        .foregroundColor(color)
        .padding(.horizontal, 14)
        .padding(.vertical, 6)
        .background(.white.opacity(0.15))
        .clipShape(Capsule())
    }

    // MARK: - Tab bar
    private var tabBar: some View {
        HStack(spacing: 0) {
            ForEach(CheckInOutTab.allCases, id: \.self) { tab in
                Button {
                    withAnimation(.easeInOut(duration: 0.25)) { selectedTab = tab }
                } label: {
                    VStack(spacing: 4) {
                        Text(tab.rawValue)
                            .font(.system(size: 13, weight: selectedTab == tab ? .bold : .regular, design: .rounded))
                            .foregroundColor(selectedTab == tab ? primaryColor : .secondary)
                        Rectangle()
                            .fill(selectedTab == tab ? primaryColor : Color.clear)
                            .frame(height: 3)
                            .clipShape(Capsule())
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                }
            }
        }
        .background(Color(UIColor.systemBackground))
        .shadow(color: .black.opacity(0.06), radius: 4, y: 2)
    }

    // MARK: - Tab content
    @ViewBuilder
    private var tabContent: some View {
        switch selectedTab {
        case .checkedIn: checkedInTab
        case .checkIn:   checkInTab
        case .checkOut:  checkOutTab
        }
    }

    // ── Checked-In Tab ──────────────────────────────────────────────────────
    private var checkedInTab: some View {
        VStack(spacing: 0) {
            // Search bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)
                TextField("Search by name or room…", text: $searchText)
                    .font(.system(size: 15, design: .rounded))
                if !searchText.isEmpty {
                    Button { searchText = "" } label: {
                        Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
                    }
                }
            }
            .padding(12)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(12)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)

            if filteredBookings.isEmpty {
                emptyCheckedInState
            } else {
                ScrollView {
                    LazyVStack(spacing: 12) {
                        ForEach(filteredBookings, id: \.id) { booking in
                            NavigationLink(destination:
                                CustomerDetailsView(booking: booking)
                                    .environmentObject(motelData)
                            ) {
                                checkedInCard(booking: booking)
                            }
                            .buttonStyle(.plain)
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    withAnimation { motelData.checkOut(booking) }
                                } label: {
                                    Label("Check Out", systemImage: "arrow.right.circle.fill")
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 30)
                }
            }
        }
    }

    private func checkedInCard(booking: CDBooking) -> some View {
        HStack(spacing: 14) {
            // Room badge
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(primaryGradient)
                    .frame(width: 52, height: 52)
                VStack(spacing: 1) {
                    Text("Rm")
                        .font(.system(size: 9, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.85))
                    Text("\(booking.room.number)")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(booking.customerName)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundColor(.primary)
                HStack(spacing: 6) {
                    Image(systemName: "arrow.right.circle")
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                    Text(DateFormatter.shortDate.string(from: booking.checkInDate))
                        .font(.system(size: 12, design: .rounded))
                        .foregroundColor(.secondary)
                    Text("→")
                        .foregroundColor(.secondary)
                        .font(.system(size: 11))
                    Text(DateFormatter.shortDate.string(from: booking.checkOutDate))
                        .font(.system(size: 12, design: .rounded))
                        .foregroundColor(.secondary)
                }
                HStack(spacing: 6) {
                    Text("\(booking.numberOfDays) night\(booking.numberOfDays == 1 ? "" : "s")")
                        .font(.system(size: 11, design: .rounded))
                        .foregroundColor(.secondary)
                    if booking.isReservation {
                        Label("Reserved", systemImage: "calendar.badge.clock")
                            .font(.system(size: 10, weight: .semibold, design: .rounded))
                            .foregroundColor(primaryColor)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(primaryColor.opacity(0.12))
                            .clipShape(Capsule())
                    }
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                Text(booking.prize)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(primaryColor)
                paymentBadge(booking: booking)
            }
        }
        .padding(14)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }

    private func paymentBadge(booking: CDBooking) -> some View {
        let isPaid   = booking.paymentStatusEnum == .paid
        let label    = isPaid ? "Paid" : "Pending"
        let bgColor  = isPaid ? greenColor.opacity(0.15) : goldColor.opacity(0.18)
        let fgColor  = isPaid ? greenColor : goldColor
        let icon     = isPaid ? "checkmark.circle.fill" : "clock.fill"
        return Label(label, systemImage: icon)
            .font(.system(size: 10, weight: .semibold, design: .rounded))
            .foregroundColor(fgColor)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(bgColor)
            .clipShape(Capsule())
    }

    private var emptyCheckedInState: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "moon.zzz.fill")
                .font(.system(size: 56))
                .foregroundStyle(primaryGradient)
            Text("No Active Bookings")
                .font(.system(size: 22, weight: .bold, design: .rounded))
            Text(searchText.isEmpty
                 ? "All rooms are currently vacant.\nTap Check In to add a guest."
                 : "No bookings match \"\(searchText)\".")
                .font(.system(size: 15, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            if searchText.isEmpty {
                Button {
                    withAnimation { selectedTab = .checkIn }
                } label: {
                    Label("Check In a Guest", systemImage: "person.badge.plus")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .foregroundColor(.white)
                        .padding(.horizontal, 28)
                        .padding(.vertical, 14)
                        .background(primaryGradient)
                        .clipShape(Capsule())
                        .shadow(color: primaryColor.opacity(0.35), radius: 8, y: 4)
                }
            }
            Spacer()
        }
        .padding(.horizontal, 30)
    }

    // ── Check-In Tab ────────────────────────────────────────────────────────
    private var checkInTab: some View {
        VStack(spacing: 0) {
            // Availability summary strip
            availabilityStrip
            ScrollView {
                CheckInView()
                    .environmentObject(motelData)
            }
        }
    }

    private var availabilityStrip: some View {
        let available = max(0, motelData.rooms.count - motelData.bookings.count)
        return HStack {
            Image(systemName: "door.left.hand.open")
                .foregroundColor(greenColor)
            Text("\(available) of \(motelData.rooms.count) room\(motelData.rooms.count == 1 ? "" : "s") available")
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundColor(.secondary)
            Spacer()
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 8)
        .background(Color(UIColor.secondarySystemGroupedBackground))
    }

    // ── Check-Out Tab ────────────────────────────────────────────────────────
    private var checkOutTab: some View {
        CheckOutView()
            .environmentObject(motelData)
    }
}

// MARK: - Preview
struct CheckInOutView_Previews: PreviewProvider {
    static var previews: some View {
        CheckInOutView()
            .environmentObject(MotelData())
    }
}
