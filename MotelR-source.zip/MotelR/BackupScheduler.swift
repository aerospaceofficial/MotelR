//
//  BackupScheduler.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/20/24.
//

import Foundation
import UserNotifications
import BackgroundTasks
import UIKit

@MainActor
class BackupScheduler {
    static let shared = BackupScheduler()
    private let backupTaskIdentifier = "com.motelr.autobackup"
    
    private init() {}
    
    func registerBackgroundTasks() {
        print("Registering background task with identifier: \(backupTaskIdentifier)")
        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: backupTaskIdentifier,
            using: .main
        ) { [weak self] task in
            guard let refreshTask = task as? BGAppRefreshTask else {
                task.setTaskCompleted(success: false)
                return
            }
            self?.handleBackup(task: refreshTask)
        }
    }
    
    func scheduleBackup() {
        let request = BGAppRefreshTaskRequest(identifier: backupTaskIdentifier)
        
        // Get the next backup time
        let backupTime = UserDefaults.standard.object(forKey: "autoBackupTime") as? Date ?? Date()
        let calendar = Calendar.current
        let components = calendar.dateComponents([.hour, .minute], from: backupTime)
        var nextBackup = calendar.date(bySettingHour: components.hour ?? 0, minute: components.minute ?? 0, second: 0, of: Date()) ?? Date()
        
        // If the time has passed today, schedule for tomorrow
        if nextBackup < Date() {
            nextBackup = calendar.date(byAdding: .day, value: 1, to: nextBackup) ?? Date()
        }
        
        request.earliestBeginDate = nextBackup
        
        do {
            try BGTaskScheduler.shared.submit(request)
            print("Successfully scheduled next backup for: \(nextBackup)")
        } catch {
            print("Could not schedule backup: \(error)")
        }
    }
    
    func cancelBackup() {
        BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: backupTaskIdentifier)
    }
    
    private func handleBackup(task: BGAppRefreshTask) {
        // Ensure we're scheduling the next backup first
        scheduleBackup()
        
        // Create a task to track background time remaining
        let backgroundTask = UIApplication.shared.beginBackgroundTask {
            task.setTaskCompleted(success: false)
        }
        
        // MotelData reads the view context, which may only be used on the main thread.
        Task { @MainActor in
            do {
                let motelData = MotelData()
                try await performBackup(motelData: motelData)
                self.sendBackupNotification(success: true)
                task.setTaskCompleted(success: true)
            } catch {
                print("Backup failed: \(error)")
                self.sendBackupNotification(success: false)
                task.setTaskCompleted(success: false)
            }

            if backgroundTask != .invalid {
                UIApplication.shared.endBackgroundTask(backgroundTask)
            }
        }
    }
    
    private func performBackup(motelData: MotelData) async throws {
        try BackupManager.shared.createBackup(motelData: motelData)
    }
    
    private func sendBackupNotification(success: Bool) {
        let content = UNMutableNotificationContent()
        content.title = success ? "Backup Successful" : "Backup Failed"
        content.body = success ? "Your motel data has been backed up successfully." : "There was an error backing up your data."
        content.sound = .default
        
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        )
        
        UNUserNotificationCenter.current().add(request)
    }
}
