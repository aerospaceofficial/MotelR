//
//  AssistantCommands.swift
//  MotelR 2.0 — by New Journey
//
//  Everything the assistant can do besides taking a booking:
//
//    Questions   "who's in room 12?"  "who checks out today?"  "any rooms free tonight?"
//                "how full are we?"  "how much did we make this week?"  "who owes us money?"
//                "has John Smith stayed before?"  "any incidents for John Smith?"
//    Actions     "check out room 12"  "check out Jane"  "mark Acme as paid"
//                "room 4 is clean"  "room 7 needs cleaning"
//    Navigation  "open analytics"  "show me the history"  "go to settings"
//
//  As with bookings, plain rules read the message first and the AI model is only
//  asked when the rules can't tell what the manager wants. Answers always come
//  from the app's own data — the model never makes up numbers or names.
//  Anything that changes data (check-out, mark paid) waits for a "yes".
//

#if canImport(FoundationModels)
import SwiftUI
import FoundationModels

// MARK: - Time limit for the AI

/// Runs `work`, but gives up after `seconds` and returns nil. The on-device model
/// can occasionally take a long time; the assistant should never sit on "Thinking…".
@MainActor
private final class AssistantOnce {
    var done = false
}

@MainActor
func assistantWithTimeout<T>(_ seconds: Double, _ work: @escaping @MainActor () async -> T?) async -> T? {
    let once = AssistantOnce()
    return await withCheckedContinuation { (continuation: CheckedContinuation<T?, Never>) in
        Task { @MainActor in
            let result = await work()
            guard !once.done else { return }
            once.done = true
            continuation.resume(returning: result)
        }
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            guard !once.done else { return }
            once.done = true
            continuation.resume(returning: nil)
        }
    }
}

// MARK: - Screens the assistant can open

enum AssistantScreen: String, Identifiable, CaseIterable {
    case rooms, bookings, customers, history, analytics, reports, organizations, incidents, settings, terms

    var id: String { rawValue }

    var title: String {
        switch self {
        case .rooms:         return "Rooms"
        case .bookings:      return "Bookings"
        case .customers:     return "Customers"
        case .history:       return "History"
        case .analytics:     return "Analytics"
        case .reports:       return "Reports"
        case .organizations: return "Organizations"
        case .incidents:     return "Incidents"
        case .settings:      return "Settings"
        case .terms:         return "Terms & Conditions"
        }
    }

    /// Words the manager might use for this screen.
    var pattern: String {
        switch self {
        case .rooms:         return #"rooms? (screen|tab|page|list)|room management|manage rooms|rooms$"#
        case .bookings:      return #"bookings?|reservations? (screen|tab|page|list)"#
        case .customers:     return #"customers?|guest list|guests (screen|tab|page)"#
        case .history:       return #"history|past bookings|past stays"#
        case .analytics:     return #"analytics|stats|statistics|dashboard numbers"#
        case .reports:       return #"reports?"#
        case .organizations: return #"organi[sz]ations?|companies|company accounts|invoices"#
        case .incidents:     return #"incidents?( list| reports?)?"#
        case .settings:      return #"settings|preferences"#
        case .terms:         return #"terms( and conditions| & conditions)?"#
        }
    }
}

// MARK: - Time periods for money questions

enum AssistantPeriod: String, CaseIterable {
    case today, yesterday, thisWeek, lastWeek, thisMonth, lastMonth, thisYear

    var label: String {
        switch self {
        case .today:     return "today"
        case .yesterday: return "yesterday"
        case .thisWeek:  return "this week"
        case .lastWeek:  return "last week"
        case .thisMonth: return "this month"
        case .lastMonth: return "last month"
        case .thisYear:  return "this year"
        }
    }

    func interval(now: Date = Date()) -> DateInterval {
        let cal = Calendar.current
        let today = cal.startOfDay(for: now)
        func interval(of unit: Calendar.Component, offset: Int) -> DateInterval {
            let base = cal.date(byAdding: unit, value: offset, to: now) ?? now
            return cal.dateInterval(of: unit, for: base) ?? DateInterval(start: today, duration: 86_400)
        }
        switch self {
        case .today:     return DateInterval(start: today, duration: 86_400)
        case .yesterday: return DateInterval(start: cal.date(byAdding: .day, value: -1, to: today) ?? today, duration: 86_400)
        case .thisWeek:  return interval(of: .weekOfYear, offset: 0)
        case .lastWeek:  return interval(of: .weekOfYear, offset: -1)
        case .thisMonth: return interval(of: .month, offset: 0)
        case .lastMonth: return interval(of: .month, offset: -1)
        case .thisYear:  return interval(of: .year, offset: 0)
        }
    }

    static func find(in text: String) -> AssistantPeriod? {
        if text.contains("yesterday") { return .yesterday }
        if text.contains("last week") { return .lastWeek }
        if text.contains("last month") { return .lastMonth }
        if text.contains("this year") || text.contains("year") { return .thisYear }
        if text.contains("this month") || text.contains("month") { return .thisMonth }
        if text.contains("this week") || text.contains("week") { return .thisWeek }
        if text.contains("today") || text.contains("tonight") { return .today }
        return nil
    }
}

// MARK: - What the manager asked for

enum AssistantCommand {
    case help
    case smallTalk(String)
    case openScreen(AssistantScreen)
    case roomInfo(Int)
    case departures(Date)
    case arrivals(Date)
    case freeRooms(Date, Int)
    case occupancy
    case revenue(AssistantPeriod)
    case unpaid
    case guestHistory(String)
    case incidents(String)
    case checkOut([CDBooking], asked: String)
    case markPaid([CDBooking], asked: String)
    case housekeeping(Int, HousekeepingStatus)
    case startBooking
    case addRooms([Int])
}

/// A change waiting for the manager's "yes".
struct AssistantPendingAction {
    enum Kind {
        case checkOut(CDBooking)
        case markPaid([CDBooking])
        case addRooms([Int])
    }
    let kind: Kind
    let summary: String
}

// MARK: - Reading commands with rules

enum AssistantCommandReader {

    /// Reads a command from the message, or nil if it isn't one the rules recognise.
    /// `bookingActive` makes the rules more careful, so booking answers aren't taken
    /// as commands ("checking out Sunday" is a departure date there).
    @MainActor
    static func read(_ p: BookingMessageParser, motelData: MotelData, bookingActive: Bool) -> AssistantCommand? {
        let t = p.normalized
        let today = Calendar.current.startOfDay(for: Date())
        let isQuestion = p.isQuestion

        // Help and small talk
        if has(#"^(help|what can you do|what do you do|how does this work|how do i use (this|you))\b"#, t) { return .help }
        if has(#"^(hi|hello|hey|good (morning|afternoon|evening))[!. ]*$"#, t) { return .smallTalk("hello") }
        if has(#"^(thanks|thank you|thank u|thx|ty|cheers|great,? thanks|perfect,? thanks|appreciate it)\b"#, t) && !p.hasAnyDetail { return .smallTalk("thanks") }
        if has(#"^(ok|okay|cool|great|perfect|nice|awesome|got it|alright|all good)[!. ]*$"#, t) { return .smallTalk("ok") }
        if has(#"^(bye|goodbye|that'?s all|that is all|nothing else|no thanks|done)[!. ]*$"#, t) { return .smallTalk("bye") }

        // Open a screen
        if has(#"^(open|show( me)?|go to|take me to|bring up|switch to)\b"#, t) {
            for screen in AssistantScreen.allCases where has(#"\b("# + screen.pattern + #")"#, t) && !p.wantsFreeRooms {
                return .openScreen(screen)
            }
        }

        // Set up rooms: "add rooms 101 to 120", "add 10 rooms", "add room 7", "we have 20 rooms"
        if has(#"^(please )?(add|create|set ?up|make|we have|there are)\b.*\brooms?\b"#, t) && !isQuestion {
            let existing = Set(motelData.rooms.map { Int($0.number) })
            var numbers: [Int] = []
            if let m = match(#"\b(\d{1,4})\s*(?:to|through|thru|-|until)\s*(\d{1,4})\b"#, t),
               let a = Int(m[1]), let b = Int(m[2]), a <= b, b - a < 200 {
                numbers = Array(a...b)
            } else if let m = match(#"\b(\d{1,3})\s+(?:more\s+|new\s+)?rooms\b"#, t), let count = Int(m[1]), (1...200).contains(count) {
                let start = (existing.max() ?? 0) + 1
                numbers = Array(start..<(start + count))
            } else {
                numbers = AssistantCommandReader.matches(#"\d{1,4}"#, t).compactMap { Int($0) }
            }
            return .addRooms(Array(Set(numbers.filter { !existing.contains($0) && $0 > 0 && $0 < 10_000 })).sorted())
        }

        // Start a booking
        if has(#"\b(book (a |the )?room|new booking|make a booking|walk ?in|check (someone|a guest|somebody) in|new guest)\b"#, t)
            && !bookingActive {
            return .startBooking
        }

        // Housekeeping: "room 4 is clean", "mark room 7 as dirty", "room 3 needs cleaning"
        if let m = match(#"\broom (\d{1,4}) (?:is |as )?(clean(?:ed)?|ready|done|dirty|needs cleaning|being cleaned)\b"#, t)
            ?? match(#"\bmark (?:room )?(\d{1,4}) (?:as )?(clean(?:ed)?|ready|done|dirty|needs cleaning|being cleaned)\b"#, t),
           let room = Int(m[1]) {
            let word = m[2]
            let status: HousekeepingStatus = (word.hasPrefix("clean") || word == "ready" || word == "done") ? .available : .cleaning
            return .housekeeping(room, status)
        }

        // Mark paid: "mark Acme as paid", "Acme paid", "Jane Smith has paid"
        if has(#"\bpaid\b"#, t) && !has(#"\b(unpaid|who (has |hasn'?t )?paid|has .* paid\?)\b"#, t) && !isQuestion
            && (!bookingActive || has(#"\bmark\b"#, t)) {
            let pending = motelData.pendingBookings
            let byOrg = pending.filter { b in
                guard let org = b.organizationName, !org.isEmpty else { return false }
                return mentions(org, in: t)
            }
            let byGuest = matchGuests(in: t, from: pending)
            let found = byOrg.isEmpty ? byGuest : byOrg
            return .markPaid(found, asked: t)
        }

        // Check out: "check out room 12", "check out Jane", "room 12 is leaving"
        let checkoutWords = has(#"\b(check(?:s|ing|ed)? ?out|checkout)\b"#, t) || has(#"\broom \d{1,4} (?:is )?(?:leaving|left|gone)\b"#, t)
        if checkoutWords && !isQuestion && !(bookingActive && p.departure != nil) {
            if let room = p.room, let booking = motelData.currentBooking(forRoomNumber: room) {
                return .checkOut([booking], asked: t)
            }
            if p.room != nil { return .checkOut([], asked: t) }
            // "check out 105" — a bare number right after the verb is a room.
            if let m = t.range(of: #"\b(?:check(?:s|ing|ed)? ?out|checkout)\s+#?(\d{1,4})\b"#, options: .regularExpression),
               let num = Int(t[m].filter(\.isNumber)) {
                if let booking = motelData.currentBooking(forRoomNumber: num) { return .checkOut([booking], asked: t) }
                return .checkOut([], asked: t)
            }
            let guests = matchGuests(in: t, from: motelData.bookings)
            if !guests.isEmpty || !bookingActive { return .checkOut(guests, asked: t) }
        }

        // Questions about the motel
        guard isQuestion || !bookingActive else { return nil }

        if let room = p.room, has(#"\b(who|whos|who's|occupied|free|empty|available|taken|status|in room|staying)\b"#, t) {
            return .roomInfo(room)
        }
        if has(#"\b(check(?:s|ing|ed)? ?out|checkouts?|leaving|departures?|due out)\b"#, t) && isQuestion {
            return .departures(p.checkIn ?? p.departure ?? today)
        }
        if has(#"\b(check(?:s|ing)? ?in|arrivals?|arriving|coming in|reservations?|expected)\b"#, t) && isQuestion {
            return .arrivals(p.checkIn ?? today)
        }
        if has(#"\b(free|available|open|empty|vacant) rooms?\b|\b(what|which|any) rooms?\b|\bvacanc(y|ies)\b|\bwhat'?s free\b"#, t) {
            return .freeRooms(p.checkIn ?? today, p.nights ?? 1)
        }
        if has(#"\b(how full|occupancy|how many (rooms|guests)|how busy|occupied)\b"#, t) {
            return .occupancy
        }
        if has(#"\b(revenue|earn|earned|earnings|made|make|income|sales|takings|money)\b|\bhow'?s business\b|\bhow is business\b"#, t)
            && !has(#"\b(owe|owes|owed|unpaid)\b"#, t) {
            return .revenue(AssistantPeriod.find(in: t) ?? .today)
        }
        if has(#"\b(unpaid|owe|owes|owed|outstanding|pending|invoices?|who hasn'?t paid)\b"#, t) {
            return .unpaid
        }
        if has(#"\bincidents?\b|\bbanned\b|\bproblems? with\b|\btrouble\b"#, t) {
            if let name = guestNameMentioned(in: t, motelData: motelData) { return .incidents(name) }
            return .openScreen(.incidents)
        }
        if has(#"\b(stayed|stay(ed)? (here|with us)|been here|visited|history for|look ?up|find)\b"#, t),
           let name = guestNameMentioned(in: t, motelData: motelData) {
            return .guestHistory(name)
        }
        return nil
    }

    // MARK: Matching guests by name

    /// Bookings whose guest is named in the text. A full name beats a surname alone.
    static func matchGuests(in text: String, from bookings: [CDBooking]) -> [CDBooking] {
        var full: [CDBooking] = []
        var partial: [CDBooking] = []
        for b in bookings {
            let parts = b.customerName.lowercased().split(separator: " ").map(String.init).filter { $0.count >= 2 }
            guard !parts.isEmpty else { continue }
            let hits = parts.filter { has(#"\b"# + NSRegularExpression.escapedPattern(for: $0) + #"\b"#, text) }
            if hits.count == parts.count {
                full.append(b)
            } else if let last = parts.last, last.count >= 3, hits.contains(last) {
                partial.append(b)
            } else if parts.count >= 1, parts[0].count >= 3, hits.contains(parts[0]) {
                partial.append(b)
            }
        }
        return full.isEmpty ? partial : full
    }

    /// The name of a known guest that appears in the text (from all past and current stays).
    @MainActor
    static func guestNameMentioned(in text: String, motelData: MotelData) -> String? {
        let all = motelData.bookings + motelData.history
        let matches = matchGuests(in: text, from: all)
        guard let best = matches.max(by: { $0.checkInDate < $1.checkInDate }) else { return nil }
        return best.customerName
    }

    static func mentions(_ phrase: String, in text: String) -> Bool {
        let words = phrase.lowercased().split(separator: " ").map(String.init).filter { $0.count >= 3 }
        guard let first = words.first else { return false }
        return has(#"\b"# + NSRegularExpression.escapedPattern(for: first) + #"\b"#, text)
    }

    // MARK: Regex helpers

    static func has(_ pattern: String, _ text: String) -> Bool {
        match(pattern, text) != nil
    }

    static func matches(_ pattern: String, _ text: String) -> [String] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return [] }
        return re.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap {
            Range($0.range, in: text).map { String(text[$0]) }
        }
    }

    static func match(_ pattern: String, _ text: String) -> [String]? {
        guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) else { return nil }
        return (0..<m.numberOfRanges).map { i in
            guard let r = Range(m.range(at: i), in: text) else { return "" }
            return String(text[r])
        }
    }
}

// MARK: - When the rules can't tell: ask the AI what kind of request it is

@available(iOS 26.0, *)
@Generable
struct AssistantIntentGuess {
    @Guide(description: "What the manager wants", .anyOf([
        "book a room", "who is in a room", "check a guest out", "who checks out", "who checks in",
        "free rooms", "how full", "revenue", "unpaid invoices", "guest history", "incidents",
        "mark paid", "open a screen", "help", "something else"
    ]))
    var kind: String
    @Guide(description: "Room number, only if the message says one")
    var roomNumber: Int?
    @Guide(description: "Guest or company name, only if the message says one")
    var name: String?
    @Guide(description: "Time period if mentioned: today, yesterday, this week, last week, this month, last month, this year")
    var period: String?
    @Guide(description: "Screen to open if asked: rooms, bookings, customers, history, analytics, reports, organizations, incidents, settings")
    var screen: String?
}

@available(iOS 26.0, *)
enum AssistantIntentModel {
    /// Asks the on-device model to classify the message, then checks its answer
    /// against the manager's words and the app's data before trusting it.
    @MainActor
    static func guess(_ text: String, parser p: BookingMessageParser, motelData: MotelData) async -> AssistantCommand? {
        let instructions = """
        You sort one message from a motel manager into the kind of request it is. \
        Only fill the other fields if the message clearly says them. Never guess.
        """
        guard let result = await assistantWithTimeout(6, {
            try? await LanguageModelSession(instructions: instructions)
                .respond(to: "Message: \"\(text)\"", generating: AssistantIntentGuess.self).content
        }) else { return nil }

        let t = p.normalized
        let today = Calendar.current.startOfDay(for: Date())
        let room = result.roomNumber.flatMap { p.mentionsNumber($0) ? $0 : nil } ?? p.room
        let name: String? = {
            if let n = AssistantCommandReader.guestNameMentioned(in: t, motelData: motelData) { return n }
            if let n = result.name, p.mentionsName(n) { return n }
            return nil
        }()

        switch result.kind {
        case "book a room":
            return .startBooking
        case "who is in a room":
            return room.map { .roomInfo($0) }
        case "check a guest out":
            if let room, let b = motelData.currentBooking(forRoomNumber: room) { return .checkOut([b], asked: t) }
            if let name { return .checkOut(AssistantCommandReader.matchGuests(in: name.lowercased(), from: motelData.bookings), asked: t) }
            return .checkOut([], asked: t)
        case "who checks out":
            return .departures(p.checkIn ?? today)
        case "who checks in":
            return .arrivals(p.checkIn ?? today)
        case "free rooms":
            return .freeRooms(p.checkIn ?? today, p.nights ?? 1)
        case "how full":
            return .occupancy
        case "revenue":
            let period = AssistantPeriod.find(in: t) ?? result.period.flatMap { AssistantPeriod.find(in: $0.lowercased()) }
            return .revenue(period ?? .today)
        case "unpaid invoices":
            return .unpaid
        case "guest history":
            return name.map { .guestHistory($0) }
        case "incidents":
            return name.map { .incidents($0) } ?? .openScreen(.incidents)
        case "mark paid":
            let pending = motelData.pendingBookings
            let byOrg = pending.filter { ($0.organizationName ?? "").isEmpty == false && AssistantCommandReader.mentions($0.organizationName ?? "", in: t) }
            return .markPaid(byOrg.isEmpty ? AssistantCommandReader.matchGuests(in: t, from: pending) : byOrg, asked: t)
        case "open a screen":
            let wanted = (result.screen ?? "").lowercased()
            if let screen = AssistantScreen.allCases.first(where: { wanted.contains($0.rawValue) }),
               AssistantCommandReader.has(#"\b("# + screen.pattern + "|" + screen.rawValue + #")\b"#, t) {
                return .openScreen(screen)
            }
            return nil
        case "help":
            return .help
        default:
            return nil
        }
    }
}

// MARK: - Answering

@available(iOS 26.0, *)
extension BookingAssistant {

    /// Answers a question or prepares an action. Returns the reply to show.
    func run(_ command: AssistantCommand) -> String {
        let cal = Calendar.current
        let today = cal.startOfDay(for: Date())

        switch command {
        case .help:
            return "I can add rooms, book guests, check guests out, mark invoices paid, mark rooms clean, and answer questions like “who checks out today?”, “is room 12 free?”, “how much did we make this week?” or “who owes us money?”. I can also open any screen — just say “open analytics”."

        case .smallTalk(let kind):
            switch kind {
            case "thanks": return "You're welcome! Anything else?"
            case "ok":     return "👍 Anything else I can do?"
            case "bye":    return "Okay — I'm here whenever you need me."
            default:       return "Hi! What can I do for you?"
            }

        case .openScreen(let screen):
            openScreen = screen
            return "Opening \(screen.title)."

        case .addRooms(let numbers):
            guard !numbers.isEmpty else {
                return "Those rooms already exist — or tell me the numbers, like “add rooms 101 to 120”."
            }
            let label = numbers.count == 1 ? "Room \(numbers[0])"
                : (numbers == Array(numbers[0]...numbers[numbers.count - 1])
                    ? "\(numbers.count) rooms (\(numbers[0])–\(numbers[numbers.count - 1]))"
                    : "\(numbers.count) rooms (\(numbers.map(String.init).joined(separator: ", ")))")
            pendingAction = AssistantPendingAction(kind: .addRooms(numbers), summary: "Add \(label)")
            return "Add \(label)? You can name them and set guests per room later in the Rooms tab. Say yes to confirm."

        case .startBooking:
            if motelData.rooms.isEmpty {
                return "Let's add your rooms first — say something like “add rooms 101 to 120”."
            }
            bookingActive = true
            return "Sure — who's checking in? Say their name or tap Scan ID."

        case .roomInfo(let number):
            guard let room = motelData.rooms.first(where: { Int($0.number) == number }) else {
                return "There's no Room \(number)."
            }
            if let b = motelData.currentBooking(for: room) {
                let status = b.paymentStatusEnum == .paid ? "paid" : "payment pending"
                return "Room \(number): \(b.customerName), checked in \(Self.shortDate(b.checkInDate)), checking out \(Self.shortDate(b.checkOutDate)) — \(b.prize), \(status)."
            }
            var text = "Room \(number) is free"
            text += RoomHousekeeping.status(for: room) == .cleaning ? " but still needs cleaning." : " and ready."
            if let next = motelData.nextReservation(for: room) {
                text += " Next booking: \(next.customerName) on \(Self.shortDate(next.checkInDate))."
            }
            return text

        case .departures(let day):
            let isToday = cal.isDate(day, inSameDayAs: today)
            let leaving = motelData.inHouseBookings.filter {
                cal.isDate($0.checkOutDate, inSameDayAs: day) || (isToday && $0.checkOutDate < today)
            }.sorted { $0.room.number < $1.room.number }
            let when = isToday ? "today" : "on \(Self.shortDate(day))"
            guard !leaving.isEmpty else { return "Nobody is checking out \(when)." }
            let list = leaving.map { b -> String in
                let overdue = b.checkOutDate < today ? " (overdue)" : ""
                return "Room \(b.room.number) — \(b.customerName)\(overdue)"
            }
            return "\(leaving.count) checking out \(when): \(list.joined(separator: "; "))."

        case .arrivals(let day):
            let arriving = motelData.bookings.filter { cal.isDate($0.checkInDate, inSameDayAs: day) }
                .sorted { $0.room.number < $1.room.number }
            let when = cal.isDate(day, inSameDayAs: today) ? "today" : "on \(Self.shortDate(day))"
            guard !arriving.isEmpty else { return "No check-ins booked \(when)." }
            let list = arriving.map { "Room \($0.room.number) — \($0.customerName)" }
            return "\(arriving.count) checking in \(when): \(list.joined(separator: "; "))."

        case .freeRooms(let day, let nights):
            let end = cal.date(byAdding: .day, value: max(nights, 1), to: day) ?? day
            let free = motelData.rooms.filter { room in
                !motelData.bookings.contains { $0.room.id == room.id && $0.checkInDate < end && day < $0.checkOutDate }
            }.sorted { $0.number < $1.number }
            let when = cal.isDate(day, inSameDayAs: today) ? "tonight" : "on \(Self.shortDate(day))"
            guard !free.isEmpty else { return "No rooms are free \(when)." }
            let cleaning = free.filter { RoomHousekeeping.status(for: $0) == .cleaning }.map { "\($0.number)" }
            var text = "\(free.count) room\(free.count == 1 ? "" : "s") free \(when): \(free.map { "\($0.number)" }.joined(separator: ", "))."
            if !cleaning.isEmpty { text += " Still to clean: \(cleaning.joined(separator: ", "))." }
            return text

        case .occupancy:
            let total = motelData.rooms.count
            guard total > 0 else { return "You haven't added any rooms yet. Say something like “add rooms 101 to 120” and I'll set them up." }
            let occupied = motelData.occupiedRoomCount
            let percent = Int((Double(occupied) / Double(total) * 100).rounded())
            let cleaning = motelData.rooms.filter { motelData.currentBooking(for: $0) == nil && RoomHousekeeping.status(for: $0) == .cleaning }.count
            let percentText = occupied > 0 && percent == 0 ? "under 1%" : "\(percent)%"
            var text = "\(occupied) of \(total) room\(total == 1 ? "" : "s") \(occupied == 1 ? "is" : "are") occupied (\(percentText))."
            text += " \(total - occupied) free"
            text += cleaning > 0 ? ", \(cleaning) still to clean." : "."
            if !motelData.reservedBookings.isEmpty { text += " \(motelData.reservedBookings.count) upcoming reservation\(motelData.reservedBookings.count == 1 ? "" : "s")." }
            return text

        case .revenue(let period):
            let range = period.interval()
            let inPeriod = (motelData.bookings + motelData.history).filter { range.contains($0.checkInDate) }
            let paid = inPeriod.filter { $0.paymentStatusEnum == .paid }
            let pending = inPeriod.filter { $0.paymentStatusEnum == .pending }
            let paidTotal = paid.reduce(0) { $0 + $1.prizeAmount }
            let pendingTotal = pending.reduce(0) { $0 + $1.prizeAmount }
            var text = String(format: "You took $%.2f %@ from %d booking%@.", paidTotal, period.label, paid.count, paid.count == 1 ? "" : "s")
            if pendingTotal > 0 {
                text += String(format: " Another $%.2f is still owed by companies.", pendingTotal)
            }
            return text

        case .unpaid:
            let pending = motelData.pendingBookings
            guard !pending.isEmpty else { return "Nothing is owed — every invoice is paid." }
            let grouped = Dictionary(grouping: pending) { $0.organizationName ?? "Unknown" }
            let lines = grouped.map { org, list -> (String, Double) in (org, list.reduce(0) { $0 + $1.prizeAmount }) }
                .sorted { $0.1 > $1.1 }
                .map { String(format: "%@ $%.2f", $0.0, $0.1) }
            let total = pending.reduce(0) { $0 + $1.prizeAmount }
            return String(format: "$%.2f is owed: ", total) + lines.joined(separator: "; ") + ". Say “mark … as paid” when one comes in."

        case .guestHistory(let name):
            let stays = (motelData.bookings + motelData.history)
                .filter { $0.customerName.caseInsensitiveCompare(name) == .orderedSame }
                .sorted { $0.checkInDate > $1.checkInDate }
            guard let last = stays.first else { return "\(name) hasn't stayed here before." }
            let spent = stays.reduce(0) { $0 + $1.prizeAmount }
            let incidents = motelData.incidents.filter {
                MotelData.normalizedLicense($0.customerID) == MotelData.normalizedLicense(last.drivingLicenseNumber)
            }.count
            var text = String(format: "%@ has stayed %d time%@, most recently %@ in Room %d. Total spent $%.2f.",
                              name, stays.count, stays.count == 1 ? "" : "s", Self.shortDate(last.checkInDate), Int(last.room.number), spent)
            if incidents > 0 { text += " ⚠️ \(incidents) incident\(incidents == 1 ? "" : "s") on record." }
            return text

        case .incidents(let name):
            let licences = Set((motelData.bookings + motelData.history)
                .filter { $0.customerName.caseInsensitiveCompare(name) == .orderedSame }
                .map { MotelData.normalizedLicense($0.drivingLicenseNumber) })
            let found = motelData.incidents.filter {
                licences.contains(MotelData.normalizedLicense($0.customerID)) || $0.customerName.caseInsensitiveCompare(name) == .orderedSame
            }
            guard !found.isEmpty else { return "No incidents on record for \(name)." }
            let open = found.filter { !$0.isResolved }.count
            let latest = found.max { $0.incidentDate < $1.incidentDate }
            var text = "\(name) has \(found.count) incident\(found.count == 1 ? "" : "s") (\(open) unresolved)."
            if let latest { text += " Most recent, \(Self.shortDate(latest.incidentDate)): \(latest.incidentDescription)" }
            return text

        case .checkOut(let matches, let asked):
            guard !matches.isEmpty else {
                if let r = asked.range(of: #"\d{1,4}"#, options: .regularExpression) {
                    return "No one is checked in to room \(asked[r]) right now."
                }
                return "I couldn't find that guest among the people staying now. Say the room number, like “check out room 12”."
            }
            guard matches.count == 1, let b = matches.first else {
                let options = matches.prefix(4).map { "\($0.customerName) in Room \($0.room.number)" }.joined(separator: ", ")
                return "Which one — \(options)? Say the room number."
            }
            pendingAction = AssistantPendingAction(kind: .checkOut(b), summary: "Check out \(b.customerName) from Room \(b.room.number)")
            var text = "Check out \(b.customerName) from Room \(b.room.number)?"
            if b.paymentStatusEnum == .pending { text += " Their \(b.prize) bill is still pending." }
            return text + " Say yes to confirm."

        case .markPaid(let matches, _):
            guard !matches.isEmpty else {
                return "I couldn't find an unpaid invoice for that. Ask “who owes us money?” to see them."
            }
            let total = matches.reduce(0) { $0 + $1.prizeAmount }
            let who = matches.first?.organizationName ?? matches.first?.customerName ?? "them"
            pendingAction = AssistantPendingAction(kind: .markPaid(matches), summary: "Mark \(who) as paid")
            return String(format: "Mark %d booking%@ for %@ as paid ($%.2f)? Say yes to confirm.",
                          matches.count, matches.count == 1 ? "" : "s", who, total)

        case .housekeeping(let number, let status):
            guard let room = motelData.rooms.first(where: { Int($0.number) == number }) else {
                return "There's no Room \(number)."
            }
            if motelData.currentBooking(for: room) != nil {
                return "Room \(number) has a guest in it right now, so its status stays Occupied."
            }
            RoomHousekeeping.set(status, for: room)
            return status == .available ? "Room \(number) is marked clean and ready." : "Room \(number) is marked as needing cleaning."
        }
    }

    /// Carries out the action the manager just said yes to.
    func performPendingAction() -> String {
        guard let action = pendingAction else { return "There's nothing waiting to be confirmed." }
        pendingAction = nil
        switch action.kind {
        case .checkOut(let booking):
            let name = booking.customerName
            let room = booking.room.number
            motelData.checkOut(booking)
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            return "Done — \(name) is checked out of Room \(room). The room is marked for cleaning."
        case .addRooms(let numbers):
            for number in numbers where !motelData.rooms.contains(where: { Int($0.number) == number }) {
                motelData.addRoom(number, name: "Standard", members: "2")
            }
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            return "Done — added \(numbers.count) room\(numbers.count == 1 ? "" : "s"). You now have \(motelData.rooms.count). Ready to book a guest?"
        case .markPaid(let bookings):
            bookings.forEach { motelData.markBookingAsPaid($0) }
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            return "Done — marked \(bookings.count) booking\(bookings.count == 1 ? "" : "s") as paid."
        }
    }
}

#endif
