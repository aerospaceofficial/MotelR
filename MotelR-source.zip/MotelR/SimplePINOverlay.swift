//  SimplePINOverlay.swift
//  MotelR 2.0 — by New Journey
//
//  The old SimplePINOverlay screen was never shown anywhere (Settings uses
//  SetPINView / ChangePINView), so it was removed. The file keeps the shake
//  effect the PIN screens share.

import SwiftUI

// MARK: - Shake Effect Modifier (shared across app)
struct ShakeEffect: GeometryEffect {
    var animatableData: CGFloat
    var amount: CGFloat = 8
    var shakes = 4

    func effectValue(size: CGSize) -> ProjectionTransform {
        let translation = amount * sin(animatableData * .pi * CGFloat(shakes))
        return ProjectionTransform(CGAffineTransform(translationX: translation, y: 0))
    }
}

extension ShakeEffect {
    init(trigger: Bool) {
        self.animatableData = trigger ? 1 : 0
    }
}
