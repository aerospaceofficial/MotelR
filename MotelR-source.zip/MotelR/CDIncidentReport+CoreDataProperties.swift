//
//  CDIncidentReport+CoreDataProperties.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/14/24.
//
//

import Foundation
import CoreData
import SwiftUI

extension CDIncidentReport: Identifiable {
    @nonobjc class func fetchRequest() -> NSFetchRequest<CDIncidentReport> {
        return NSFetchRequest<CDIncidentReport>(entityName: "IncidentReport")
    }

    @NSManaged public var id: UUID
    @NSManaged var customerName: String
    @NSManaged var customerID: String
    @NSManaged var incidentDate: Date
    @NSManaged var incidentDescription: String
    @NSManaged var severity: String
    @NSManaged var isResolved: Bool
    @NSManaged var resolutionNotes: String?
    @NSManaged var reportedBy: String
    @NSManaged var createdAt: Date
    @NSManaged var updatedAt: Date
}

extension CDIncidentReport {
    var severityLevel: IncidentSeverity {
        get {
            return IncidentSeverity(rawValue: severity) ?? .low
        }
        set {
            severity = newValue.rawValue
        }
    }
}

enum IncidentSeverity: String, CaseIterable {
    case low = "Low"
    case medium = "Medium"
    case high = "High"
    
    var color: Color {
        switch self {
        case .low: return .blue
        case .medium: return .orange
        case .high: return .red
        }
    }
    
    var icon: String {
        switch self {
        case .low: return "exclamationmark.circle"
        case .medium: return "exclamationmark.triangle"
        case .high: return "exclamationmark.octagon"
        }
    }
}

extension CDIncidentReport {
    convenience init(context: NSManagedObjectContext,
                    customerName: String,
                    customerID: String,
                    incidentDate: Date,
                    description: String,
                    severity: IncidentSeverity,
                    reportedBy: String,
                    booking: CDBooking? = nil) {
        self.init(context: context)
        self.id = UUID()
        self.customerName = customerName
        self.customerID = customerID
        self.incidentDate = incidentDate
        self.incidentDescription = description
        self.severity = severity.rawValue
        self.isResolved = false
        self.reportedBy = reportedBy
        self.createdAt = Date()
        self.updatedAt = Date()
    }
}
