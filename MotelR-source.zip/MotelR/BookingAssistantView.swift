//
//  BookingAssistantView.swift
//  MotelR 2.0 — by New Journey
//
//  Chat screen for the on-device booking assistant: conversation, quick-reply
//  buttons, voice input and spoken replies, licence scanner, confirmation card
//  and signature step.
//  See BookingAssistant.swift for how the assistant works.
//

#if canImport(FoundationModels)
import SwiftUI

private let baPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let baPrimaryDark = Color(red: 0.05, green: 0.12, blue: 0.65)
private let baGreen = Color(red: 0.20, green: 0.78, blue: 0.35)
private let baGold = Color(red: 0.96, green: 0.65, blue: 0.14)

@available(iOS 26.0, *)
struct BookingAssistantView: View {
    @StateObject private var assistant: BookingAssistant
    @Environment(\.dismiss) private var dismiss

    @State private var input = ""
    @State private var showSignature = false
    @State private var signatureImage: UIImage?
    @State private var hasSignature = false
    @FocusState private var inputFocused: Bool

    // Voice
    @StateObject private var voice = AssistantVoiceInput()
    @StateObject private var speaker = AssistantSpeaker()
    /// Full-screen, hands-free voice conversation (like ChatGPT's voice mode).
    @State private var voiceMode = false
    @State private var voicePaused = false
    /// Read replies aloud after the manager speaks (hands-free). Remembered between visits.
    @AppStorage("assistantReadsRepliesAloud") private var readAloud = true
    /// The voice picked in the Voice menu (empty = automatic).
    @AppStorage(AssistantSpeaker.voiceKey) private var voiceID = ""
    /// Replies are only read aloud when the manager's last message was spoken.
    @State private var lastInputWasVoice = false

    init(motelData: MotelData) {
        _assistant = StateObject(wrappedValue: BookingAssistant(motelData: motelData))
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                conversation
                Divider()
                quickReplies
                inputBar
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("MotelR Assistant")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
                ToolbarItemGroup(placement: .primaryAction) {
                    voiceMenu
                    Button {
                        voice.stop(send: false)
                        speaker.stop()
                        assistant.reset()
                        input = ""
                        lastInputWasVoice = false
                    } label: {
                        Label("New Guest", systemImage: "arrow.counterclockwise")
                    }
                    .disabled(assistant.isThinking)
                }
            }
            .modifier(VoiceBehaviour(apply: voiceBehaviour))
            .alert("Voice", isPresented: Binding(
                get: { voice.errorMessage != nil },
                set: { if !$0 { voice.errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(voice.errorMessage ?? "")
            }
            .fullScreenCover(isPresented: $assistant.showScanner, onDismiss: { assistant.scannerClosed() }) {
                LicenseScannerView { license in
                    assistant.scannerRead(license)
                }
            }
            .sheet(isPresented: $showSignature) {
                signatureSheet
            }
            // "Open analytics", "show me the history"…
            .sheet(item: $assistant.openScreen) { screen in
                screenView(screen)
                    .environmentObject(assistant.motelData)
            }
            .alert("Previous Incidents Found", isPresented: Binding(
                get: { assistant.incidentWarning != nil },
                set: { if !$0 { assistant.incidentWarning = nil } }
            )) {
                Button("Continue Anyway", role: .cancel) {}
            } message: {
                Text(assistant.incidentWarning ?? "")
            }
        }
        .overlay {
            if voiceMode {
                AssistantVoiceModeView(
                    assistant: assistant,
                    voice: voice,
                    speaker: speaker,
                    isPaused: voicePaused,
                    onToggleMic: toggleVoiceMic,
                    onTapOrb: tapOrb,
                    onClose: exitVoiceMode
                )
                .transition(.opacity.combined(with: .scale(scale: 1.03)))
            }
        }
        .animation(.easeInOut(duration: 0.3), value: voiceMode)
    }

    /// Voice wiring, kept apart from `body` so the compiler can check it quickly.
    private func voiceBehaviour(_ content: AnyView) -> AnyView {
        AnyView(content
            .onAppear {
                voice.onFinished = { text in
                    lastInputWasVoice = true
                    send(text)
                }
                voice.onEmpty = { resumeListeningIfNeeded() }
                speaker.onFinished = { resumeListeningIfNeeded() }
            }
            .onDisappear {
                voiceMode = false
                voice.stop(send: false)
                speaker.stop()
            }
            // Hands-free: read each new reply aloud after the manager spoke.
            .onChange(of: assistant.messages.count) { _, _ in
                guard let last = assistant.messages.last, last.sender != .manager else { return }
                if voiceMode {
                    voice.stop(send: false)
                    speaker.speak(last.text)
                } else if readAloud, lastInputWasVoice, !voice.isListening {
                    speaker.speak(last.text)
                }
            }
            // Voice mode: pick the conversation back up after a screen closes.
            .onChange(of: assistant.isThinking) { _, thinking in
                if !thinking { resumeListeningIfNeeded() }
            }
            .onChange(of: showSignature) { _, open in
                if !open { resumeListeningIfNeeded() }
            }
            .onChange(of: assistant.openScreen == nil) { _, closed in
                if closed { resumeListeningIfNeeded() } else { voice.stop(send: false) }
            }
            .onChange(of: voice.errorMessage) { _, error in
                if error != nil { exitVoiceMode() }
            }
            // The manager said "confirm": open the signature step.
            .onChange(of: assistant.wantsSignature) { _, wants in
                guard wants else { return }
                assistant.wantsSignature = false
                openSignature()
            }
            // Never listen while the camera is open.
            .onChange(of: assistant.showScanner) { _, isOpen in
                if isOpen { voice.stop(send: false) } else { resumeListeningIfNeeded() }
            }
        )
    }

    // MARK: Conversation

    private var conversation: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(assistant.messages) { message in
                        bubble(message)
                            .id(message.id)
                    }
                    if assistant.isThinking {
                        thinkingBubble
                            .id("thinking")
                    }
                    if assistant.showConfirmation {
                        confirmationCard
                            .id("confirmation")
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .readableWidth()
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: assistant.messages.count) { _, _ in scrollToEnd(proxy) }
            .onChange(of: assistant.isThinking) { _, _ in scrollToEnd(proxy) }
            .onChange(of: assistant.showConfirmation) { _, _ in scrollToEnd(proxy) }
        }
    }

    private func scrollToEnd(_ proxy: ScrollViewProxy) {
        withAnimation(.easeOut(duration: 0.25)) {
            if assistant.showConfirmation {
                proxy.scrollTo("confirmation", anchor: .bottom)
            } else if assistant.isThinking {
                proxy.scrollTo("thinking", anchor: .bottom)
            } else if let last = assistant.messages.last {
                proxy.scrollTo(last.id, anchor: .bottom)
            }
        }
    }

    @ViewBuilder
    private func bubble(_ message: AssistantMessage) -> some View {
        switch message.sender {
        case .manager:
            HStack {
                Spacer(minLength: 48)
                Text(message.text)
                    .font(.system(size: 16, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(
                        LinearGradient(colors: [baPrimary, baPrimaryDark], startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: RoundedRectangle(cornerRadius: 18)
                    )
            }
        case .assistant:
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "sparkles")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(baPrimary)
                    .frame(width: 28, height: 28)
                    .background(baPrimary.opacity(0.12), in: Circle())
                Text(message.text)
                    .font(.system(size: 16, design: .rounded))
                    .foregroundColor(.primary)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color(UIColor.systemBackground), in: RoundedRectangle(cornerRadius: 18))
                Spacer(minLength: 32)
            }
        case .app:
            Label(message.text, systemImage: "checkmark.circle.fill")
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundColor(baGreen)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(baGreen.opacity(0.12), in: Capsule())
                .frame(maxWidth: .infinity)
        }
    }

    private var thinkingBubble: some View {
        HStack(spacing: 8) {
            Image(systemName: "sparkles")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(baPrimary)
                .frame(width: 28, height: 28)
                .background(baPrimary.opacity(0.12), in: Circle())
            HStack(spacing: 6) {
                ProgressView()
                Text("Thinking…")
                    .font(.system(size: 14, design: .rounded))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(Color(UIColor.systemBackground), in: RoundedRectangle(cornerRadius: 18))
            Spacer()
        }
    }

    // MARK: Confirmation card

    private var confirmationCard: some View {
        let d = assistant.draft
        let taxRate = assistant.motelData.taxRate
        let taxPart = d.taxIncluded && taxRate > 0 ? d.total - d.total / (1 + taxRate) : 0
        let nights = d.nights ?? 0

        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "checklist")
                    .foregroundColor(baPrimary)
                Text("Check the booking")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                Spacer()
                if d.checkIn > Calendar.current.startOfDay(for: Date()) {
                    Text("Reservation")
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                        .foregroundColor(baPrimary)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(baPrimary.opacity(0.12), in: Capsule())
                }
            }

            Group {
                cardRow("Guest", d.guestName)
                cardRow("Licence", d.licenseNumber)
                cardRow("Phone", d.phone)
                cardRow("Address", "\(d.street), \(d.city), \(d.state) \(d.zipCode)")
                cardRow("Room", d.roomNumber.map { "Room \($0)" } ?? "—")
                cardRow("Dates", "\(BookingAssistant.shortDate(d.checkIn)) → \(BookingAssistant.shortDate(d.checkOut))")
                cardRow("Rate", String(format: "%d night%@ × $%.2f", nights, nights == 1 ? "" : "s", d.nightlyRate ?? 0))
                cardRow("Payment", paymentText(d))
            }

            Divider()

            HStack(alignment: .firstTextBaseline) {
                Text("Total")
                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(String(format: "$%.2f", d.total))
                        .font(.system(size: 24, weight: .black, design: .rounded))
                        .foregroundColor(baPrimary)
                    if taxPart > 0 {
                        Text(String(format: "includes $%.2f tax", taxPart))
                            .font(.system(size: 12, design: .rounded))
                            .foregroundColor(.secondary)
                    } else if !d.taxIncluded {
                        Text("no tax")
                            .font(.system(size: 12, design: .rounded))
                            .foregroundColor(.secondary)
                    }
                }
            }

            HStack(spacing: 10) {
                Button {
                    withAnimation { assistant.showConfirmation = false }
                    inputFocused = true
                } label: {
                    Text("Edit")
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(baPrimary.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
                        .foregroundColor(baPrimary)
                }
                Button {
                    openSignature()
                } label: {
                    Label("Sign & Confirm", systemImage: "signature")
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(
                            LinearGradient(colors: [baPrimary, baPrimaryDark], startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 14)
                        )
                        .foregroundColor(.white)
                }
            }
            .buttonStyle(.plain)
        }
        .padding(16)
        .background(Color(UIColor.systemBackground), in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(baPrimary.opacity(0.25), lineWidth: 1))
        .shadow(color: .black.opacity(0.06), radius: 10, y: 4)
    }

    private func cardRow(_ label: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(label)
                .font(.system(size: 14, design: .rounded))
                .foregroundColor(.secondary)
                .frame(width: 76, alignment: .leading)
            Text(value)
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundColor(.primary)
            Spacer(minLength: 0)
        }
    }

    private func paymentText(_ d: AssistantDraft) -> String {
        guard let method = d.payment else { return "—" }
        switch method {
        case .cash:         return "Cash"
        case .card:         return "Card · \(d.cardType)"
        case .check:        return "Check #\(d.checkNumber)"
        case .organization: return "\(d.organizationName) · \(d.billLater ? "bill later (Pending)" : "paid now")"
        }
    }

    // MARK: Signature

    private var signatureSheet: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    signatureSummary
                    SignatureStepView(
                        signatureImage: $signatureImage,
                        hasSignature: $hasSignature,
                        customerName: assistant.draft.guestName
                    )
                }
                .padding(20)
                .readableWidth(640)
            }
            // Always visible, so nobody has to scroll to find it after signing.
            .safeAreaInset(edge: .bottom) {
                Button {
                    guard let image = signatureImage, hasSignature else { return }
                    _ = assistant.saveBooking(signature: image)
                    showSignature = false
                } label: {
                    Label(hasSignature ? "Complete Check-In" : "Guest signature needed",
                          systemImage: hasSignature ? "checkmark.circle.fill" : "signature")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(hasSignature ? baGreen : Color.gray.opacity(0.4), in: RoundedRectangle(cornerRadius: 14))
                        .foregroundColor(.white)
                }
                .buttonStyle(.plain)
                .disabled(!hasSignature)
                .padding(.horizontal, 20)
                .padding(.vertical, 10)
                .background(.bar)
            }
            .navigationTitle("Guest Signature")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showSignature = false }
                }
            }
        }
    }

    /// Read-aloud switch and the choice of voice (MotelR only — Siri is untouched).
    private var voiceMenu: some View {
        Menu {
            Toggle(isOn: Binding(
                get: { readAloud },
                set: { readAloud = $0; if !$0 { speaker.stop() } }
            )) {
                Label("Read Replies Aloud", systemImage: "speaker.wave.2")
            }
            Picker(selection: Binding(
                get: { voiceID.isEmpty ? (AssistantSpeaker.currentVoice?.identifier ?? "") : voiceID },
                set: { id in
                    voiceID = id
                    speaker.speak("Hello. I'm your MotelR assistant. How may I help?")
                }
            )) {
                ForEach(AssistantSpeaker.availableVoices, id: \.identifier) { voice in
                    Text(AssistantSpeaker.label(for: voice)).tag(voice.identifier)
                }
            } label: {
                Label("Voice", systemImage: "person.wave.2")
            }
            .pickerStyle(.menu)
        } label: {
            Label("Voice", systemImage: readAloud ? "speaker.wave.2.fill" : "speaker.slash.fill")
        }
    }

    /// What's being signed for, so the confirm step isn't needed in voice mode.
    private var signatureSummary: some View {
        let d = assistant.draft
        return VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(d.guestName)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                Spacer()
                Text(String(format: "$%.2f", d.total))
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundColor(baPrimary)
            }
            Text("Room \(d.roomNumber ?? 0) · \(d.nights ?? 1) night\(d.nights == 1 ? "" : "s") · \(BookingAssistant.shortDate(d.checkIn)) – \(BookingAssistant.shortDate(d.checkOut))")
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundColor(.secondary)
            Text(paymentText(d))
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundColor(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(UIColor.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
    }

    // MARK: Quick replies

    private var quickReplies: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                if assistant.bookingSaved {
                    chip("Done", icon: "checkmark") { dismiss() }
                }
                // The assistant decides which buttons fit the question it just asked.
                ForEach(assistant.quickReplies) { reply in
                    chip(reply.title, icon: reply.icon) { perform(reply.action) }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .disabled(assistant.isThinking)
    }

    // MARK: Screens the assistant can open

    @ViewBuilder
    private func screenView(_ screen: AssistantScreen) -> some View {
        switch screen {
        case .rooms:         withDoneButton(ManageRoomsView(), title: screen.title)
        case .customers:     withDoneButton(CustomersView(), title: screen.title)
        case .history:       withDoneButton(HistoryView(), title: screen.title)
        case .analytics:     withDoneButton(AnalyticsView(), title: screen.title)
        case .bookings:      CheckInOutView()
        case .reports:       ReportsView()
        case .organizations: OrganizationsView()
        case .incidents:     IncidentListView()
        case .settings:      SettingsView()
        case .terms:         TermsAndConditionsEditorView()
        }
    }

    private func withDoneButton<Content: View>(_ content: Content, title: String) -> some View {
        NavigationStack {
            content
                .navigationTitle(title)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") { assistant.openScreen = nil }
                    }
                }
        }
    }

    private func perform(_ action: AssistantQuickReply.Action) {
        switch action {
        case .send(let text):
            send(text)
        case .scan:
            voice.stop(send: false)
            assistant.showScanner = true
        case .sign:
            openSignature()
        case .review:
            withAnimation { assistant.showConfirmation = true }
        }
    }

    private func openSignature() {
        voice.stop(send: false)
        signatureImage = nil
        hasSignature = false
        showSignature = true
    }

    private func chip(_ title: String, icon: String? = nil, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 5) {
                if let icon { Image(systemName: icon).font(.system(size: 12, weight: .semibold)) }
                Text(title).font(.system(size: 14, weight: .semibold, design: .rounded))
            }
            .foregroundColor(baPrimary)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(baPrimary.opacity(0.10), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: Input

    private var inputBar: some View {
        HStack(spacing: 10) {
            if voice.isListening {
                listeningPill
            } else {
                TextField("Type or tap the mic…", text: $input)
                    .font(.system(size: 16, design: .rounded))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 11)
                    .background(Color(UIColor.systemBackground), in: Capsule())
                    .focused($inputFocused)
                    .submitLabel(.send)
                    .onSubmit { sendTyped() }
                }

            if canSend && !voice.isListening {
                Button { sendTyped() } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 32))
                        .foregroundColor(baPrimary)
                }
            } else {
                micButton
                if !voice.isListening { voiceModeButton }
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 4)
        .padding(.bottom, 10)
        .animation(.easeInOut(duration: 0.2), value: voice.isListening)
    }

    private var micButton: some View {
        Button {
            speaker.stop()   // don't let it hear its own voice
            inputFocused = false
            voice.toggle(contextualStrings: assistant.motelData.rooms.map { "room \($0.number)" })
        } label: {
            Image(systemName: voice.isListening ? "stop.circle.fill" : "mic.circle.fill")
                .font(.system(size: 32))
                .foregroundColor(voice.isListening ? .red : baPrimary)
                .symbolEffect(.pulse, isActive: voice.isListening)
        }
        .disabled(assistant.isThinking)
        .accessibilityLabel(voice.isListening ? "Stop and send" : "Talk")
    }

    /// Opens the full-screen voice conversation.
    private var voiceModeButton: some View {
        Button { startVoiceMode() } label: {
            Image(systemName: "waveform")
                .font(.system(size: 15, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 34, height: 34)
                .background(
                    LinearGradient(colors: [baPrimary, baPrimaryDark],
                                   startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: Circle()
                )
        }
        .disabled(assistant.isThinking)
        .accessibilityLabel("Voice mode")
    }

    // MARK: Voice mode

    private func startVoiceMode() {
        inputFocused = false
        speaker.stop()
        voicePaused = false
        lastInputWasVoice = true
        assistant.voiceMode = true
        voiceMode = true
        // A short hello; listening starts by itself when he finishes speaking.
        assistant.voiceGreeting()
    }

    private func exitVoiceMode() {
        guard voiceMode else { return }
        voiceMode = false
        assistant.voiceMode = false
        voice.stop(send: false)
        speaker.stop()
    }

    private func startListening() {
        voice.start(contextualStrings: assistant.motelData.rooms.map { "room \($0.number)" })
    }

    /// Mute / unmute the microphone. A reply that is being read keeps playing.
    private func toggleVoiceMic() {
        if voicePaused {
            voicePaused = false
            speaker.stop()
            startListening()
        } else {
            voicePaused = true
            voice.stop(send: false)
        }
    }

    /// Tapping the orb: interrupt a reply, unmute, or send what was said so far.
    private func tapOrb() {
        if speaker.isSpeaking {
            speaker.stop()
            voicePaused = false
            startListening()
        } else if voicePaused {
            toggleVoiceMic()
        } else if voice.isListening {
            voice.stop(send: true)
        }
    }

    /// Starts listening again once nothing else is going on.
    private func resumeListeningIfNeeded() {
        guard voiceMode else { return }
        Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(350))
            guard voiceMode, !voicePaused, !voice.isListening, !speaker.isSpeaking,
                  !assistant.isThinking, !showSignature, !assistant.showScanner,
                  assistant.openScreen == nil else { return }
            startListening()
        }
    }

    /// Shows the words as they are heard; sends by itself after a short pause.
    private var listeningPill: some View {
        HStack(spacing: 8) {
            Image(systemName: "waveform")
                .foregroundColor(.red)
                .symbolEffect(.variableColor.iterative, isActive: true)
            Text(voice.transcript.isEmpty ? "Listening…" : voice.transcript)
                .font(.system(size: 16, design: .rounded))
                .foregroundColor(voice.transcript.isEmpty ? .secondary : .primary)
                .lineLimit(2)
                .truncationMode(.head)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .background(Color(UIColor.systemBackground), in: Capsule())
        .overlay(Capsule().stroke(Color.red.opacity(0.35), lineWidth: 1))
    }

    private func sendTyped() {
        lastInputWasVoice = false
        speaker.stop()
        send(input)
    }

    private var canSend: Bool {
        !input.trimmingCharacters(in: .whitespaces).isEmpty && !assistant.isThinking
    }

    private func send(_ text: String) {
        guard !assistant.isThinking else { return }
        assistant.send(text)
        if text == input { input = "" }
    }
}

// MARK: - Voice mode screen

@available(iOS 26.0, *)
enum AssistantVoiceState: Equatable {
    case listening, thinking, speaking, paused
}

/// Full-screen voice conversation: a living orb that reacts to the manager's
/// voice and pulses with every word of the reply.
@available(iOS 26.0, *)
struct AssistantVoiceModeView: View {
    @ObservedObject var assistant: BookingAssistant
    @ObservedObject var voice: AssistantVoiceInput
    @ObservedObject var speaker: AssistantSpeaker
    let isPaused: Bool
    let onToggleMic: () -> Void
    let onTapOrb: () -> Void
    let onClose: () -> Void

    private var state: AssistantVoiceState {
        if speaker.isSpeaking { return .speaking }
        if assistant.isThinking { return .thinking }
        if isPaused { return .paused }
        return .listening
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.02, green: 0.03, blue: 0.09),
                                    Color(red: 0.05, green: 0.07, blue: 0.20)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                header
                    .padding(.top, 18)
                Spacer(minLength: 20)
                AssistantOrb(state: state, mic: voice.meter, voiceOut: speaker.meter)
                    .frame(width: 340, height: 340)
                    .contentShape(Circle())
                    .onTapGesture { onTapOrb() }
                    .accessibilityElement()
                    .accessibilityLabel(statusText)
                    .accessibilityAddTraits(.isButton)
                Spacer(minLength: 20)
                caption
                    .frame(maxWidth: .infinity, minHeight: 120, alignment: .top)
                    .padding(.horizontal, 28)
                controls
                    .padding(.horizontal, 44)
                    .padding(.bottom, 28)
            }
        }
        .sensoryFeedback(.impact(weight: .light), trigger: state)
    }

    private var header: some View {
        VStack(spacing: 6) {
            Text("MotelR Assistant")
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .foregroundColor(.white)
            HStack(spacing: 6) {
                Circle()
                    .fill(statusColor)
                    .frame(width: 7, height: 7)
                Text(statusText)
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.65))
                    .contentTransition(.opacity)
            }
            .animation(.easeInOut(duration: 0.25), value: state)
        }
    }

    private var statusText: String {
        switch state {
        case .listening: return voice.isListening ? "Listening" : "Starting…"
        case .thinking:  return "Thinking…"
        case .speaking:  return "Speaking · tap to interrupt"
        case .paused:    return "Mic off"
        }
    }

    private var statusColor: Color {
        switch state {
        case .listening: return Color(red: 0.35, green: 0.80, blue: 1.0)
        case .thinking:  return Color(red: 0.70, green: 0.50, blue: 1.0)
        case .speaking:  return .white
        case .paused:    return .red
        }
    }

    private var caption: some View {
        ZStack {
            captionLabel
                .id(state)
                .transition(.asymmetric(insertion: .opacity.combined(with: .offset(y: 10)),
                                        removal: .opacity))
        }
        .animation(.easeInOut(duration: 0.4), value: state)
    }

    private var captionLabel: some View {
        Text(captionText)
            .font(.system(size: state == .listening && !voice.transcript.isEmpty ? 22 : 19,
                          weight: .medium, design: .rounded))
            .foregroundColor(.white.opacity(captionIsHint ? 0.45 : 0.92))
            .multilineTextAlignment(.center)
            .lineLimit(5)
            .truncationMode(.head)
            .animation(.easeInOut(duration: 0.2), value: captionText)
    }

    private var captionIsHint: Bool {
        switch state {
        case .listening: return voice.transcript.isEmpty
        case .paused:    return true
        default:         return false
        }
    }

    private var captionText: String {
        switch state {
        case .listening:
            return voice.transcript.isEmpty ? "Go ahead — I'm listening." : voice.transcript
        case .thinking:
            return assistant.messages.last(where: { $0.sender == .manager })?.text ?? ""
        case .speaking:
            return assistant.messages.last(where: { $0.sender != .manager })?.text ?? ""
        case .paused:
            return "Tap the mic to keep talking."
        }
    }

    private var controls: some View {
        HStack {
            Button(action: onToggleMic) {
                Image(systemName: isPaused ? "mic.slash.fill" : "mic.fill")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(isPaused ? .white : .white.opacity(0.9))
                    .frame(width: 64, height: 64)
                    .background(isPaused ? Color.red.opacity(0.85) : Color.white.opacity(0.12), in: Circle())
            }
            .accessibilityLabel(isPaused ? "Turn mic on" : "Turn mic off")

            Spacer()

            Button(action: onClose) {
                Image(systemName: "xmark")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(.white.opacity(0.9))
                    .frame(width: 64, height: 64)
                    .background(Color.white.opacity(0.12), in: Circle())
            }
            .accessibilityLabel("End voice mode")
        }
    }
}

/// The animated orb. Its edge ripples with the microphone level while
/// listening, breathes while thinking and pulses on every spoken word.
@available(iOS 26.0, *)
struct AssistantOrb: View {
    let state: AssistantVoiceState
    @ObservedObject var mic: AssistantAudioMeter
    @ObservedObject var voiceOut: AssistantAudioMeter
    @State private var motion = OrbMotion()

    var body: some View {
        // 45 fps is smooth to the eye and leaves the phone free to speak cleanly.
        TimelineView(.animation(minimumInterval: 1.0 / 45.0)) { timeline in
            let now = timeline.date
            let t = now.timeIntervalSinceReferenceDate
            // Glide towards the new colours and movement instead of jumping.
            let _ = motion.step(to: Self.palette(for: state), energy: Double(energy(now: now, t: t)), at: now)
            let energy = CGFloat(motion.energy)
            let colors = motion.colors.map { Color(red: $0.x, green: $0.y, blue: $0.z) }

            Canvas { ctx, size in
                let c = CGPoint(x: size.width / 2, y: size.height / 2)
                let base = min(size.width, size.height) * 0.27
                let r = base * (1 + 0.18 * energy + breathing(t))
                let wobble = 0.35 + energy * 1.6

                // Soft glow behind the orb.
                var glow = ctx
                glow.addFilter(.blur(radius: 26))
                glow.opacity = 0.45 + 0.4 * Double(energy)
                glow.fill(blob(c, r * 1.1, t, wobble: wobble * 0.8, seed: 0.7), with: .color(colors[0]))

                // The body, with a slowly turning gradient.
                let body = blob(c, r, t, wobble: wobble, seed: 0)
                let a = t * 0.5
                ctx.fill(body, with: .linearGradient(
                    Gradient(colors: colors),
                    startPoint: CGPoint(x: c.x + cos(a) * r, y: c.y + sin(a) * r),
                    endPoint: CGPoint(x: c.x - cos(a) * r, y: c.y - sin(a) * r)))

                // Swirling light inside.
                var inside = ctx
                inside.clip(to: body)
                var swirl = inside
                swirl.blendMode = .screen
                swirl.opacity = 0.55
                swirl.addFilter(.blur(radius: 12))
                let sc = CGPoint(x: c.x + cos(t * 0.9) * r * 0.22, y: c.y + sin(t * 1.15) * r * 0.22)
                swirl.fill(blob(sc, r * 0.6, t * 1.4, wobble: wobble * 1.5, seed: 2.1), with: .color(colors[2]))
                var highlight = inside
                highlight.addFilter(.blur(radius: 16))
                highlight.opacity = 0.35
                highlight.fill(Path(ellipseIn: CGRect(x: c.x - r * 0.6, y: c.y - r * 0.85,
                                                      width: r * 0.8, height: r * 0.5)),
                               with: .color(.white))
            }
        }
    }

    /// 0…1: how much the orb should move right now.
    private func energy(now: Date, t: Double) -> CGFloat {
        switch state {
        case .listening:
            return min(1, mic.level * 1.35)
        case .speaking:
            let since = now.timeIntervalSince(voiceOut.lastWordAt)
            let pulse = exp(-max(since, 0) / 0.22)
            let flutter = 0.75 + 0.25 * sin(t * 17)
            return CGFloat(0.25 + 0.6 * pulse * flutter)
        case .thinking:
            return CGFloat(0.18 + 0.08 * sin(t * 3))
        case .paused:
            return 0
        }
    }

    private func breathing(_ t: Double) -> CGFloat {
        switch state {
        case .listening: return CGFloat(0.02 * sin(t * 1.6))
        case .thinking:  return CGFloat(0.05 * sin(t * 2.4))
        case .paused:    return CGFloat(0.01 * sin(t * 0.8))
        case .speaking:  return 0
        }
    }

    static func palette(for state: AssistantVoiceState) -> [SIMD3<Double>] {
        switch state {
        case .listening: return [[0.35, 0.78, 1.0], [0.18, 0.27, 0.90], [0.70, 0.95, 1.0]]
        case .thinking:  return [[0.64, 0.42, 1.0], [0.26, 0.20, 0.85], [0.95, 0.72, 1.0]]
        case .speaking:  return [[0.45, 0.85, 1.0], [0.22, 0.45, 1.0], [1.0, 1.0, 1.0]]
        case .paused:    return [[0.55, 0.55, 0.55], [0.28, 0.28, 0.28], [0.80, 0.80, 0.80]]
        }
    }

    /// A circle whose edge is pushed in and out by a few moving waves.
    private func blob(_ c: CGPoint, _ r: CGFloat, _ t: Double, wobble: CGFloat, seed: Double) -> Path {
        var path = Path()
        let steps = 96
        for i in 0...steps {
            let a = Double(i) / Double(steps) * 2 * .pi
            let d = 0.045 * sin(3 * a + t * 1.7 + seed)
                  + 0.035 * sin(5 * a - t * 2.3 + seed * 2)
                  + 0.025 * sin(7 * a + t * 3.1 + seed * 3)
                  + 0.015 * sin(2 * a - t * 1.1)
            let rr = r * (1 + CGFloat(d) * wobble)
            let p = CGPoint(x: c.x + rr * CGFloat(cos(a)), y: c.y + rr * CGFloat(sin(a)))
            if i == 0 { path.move(to: p) } else { path.addLine(to: p) }
        }
        path.closeSubpath()
        return path
    }
}

/// The orb's last drawn colours and movement, so state changes glide.
@available(iOS 26.0, *)
final class OrbMotion {
    var colors: [SIMD3<Double>] = AssistantOrb.palette(for: .listening)
    var energy: Double = 0
    private var last: Date?

    func step(to target: [SIMD3<Double>], energy goal: Double, at now: Date) {
        let dt = min(max(now.timeIntervalSince(last ?? now), 0), 0.1)
        last = now
        let blend = 1 - exp(-dt * 3.2)              // ~0.6 s colour change
        for i in colors.indices where i < target.count {
            colors[i] += (target[i] - colors[i]) * blend
        }
        let speed = goal > energy ? 16.0 : 5.0     // quick to rise, gentle to settle
        energy += (goal - energy) * (1 - exp(-dt * speed))
    }
}

/// Lets `body` hand part of its modifier chain to a separate function.
struct VoiceBehaviour: ViewModifier {
    let apply: (AnyView) -> AnyView
    func body(content: Content) -> some View { apply(AnyView(content)) }
}

#endif
