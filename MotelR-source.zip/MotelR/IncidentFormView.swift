//  IncidentFormView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Design Tokens
private let ifPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let ifGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)

struct IncidentFormView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    // Form fields
    @State private var customerName = ""
    @State private var customerID = ""
    @State private var incidentDate = Date()
    @State private var severity: IncidentSeverity = .medium
    @State private var description = ""
    @State private var reportedBy = ""
    @State private var showAutoComplete = false
    @FocusState private var focusedField: FormField?

    // Validation
    @State private var showValidationError = false
    @State private var validationMessage = ""

    private enum FormField: Hashable {
        case customerName, customerID, description, reportedBy
    }

    private var autoCompleteSuggestions: [String] {
        guard !customerName.isEmpty else { return [] }
        let query = customerName.lowercased()
        let names = Set((motelData.bookings + motelData.history).map { $0.customerName })
        return names
            .filter { $0.lowercased().contains(query) && $0.lowercased() != customerName.lowercased() }
            .sorted()
    }

    private var isFormValid: Bool {
        !customerName.trimmingCharacters(in: .whitespaces).isEmpty &&
        !customerID.trimmingCharacters(in: .whitespaces).isEmpty &&
        description.trimmingCharacters(in: .whitespaces).count >= 10 &&
        !reportedBy.trimmingCharacters(in: .whitespaces).isEmpty
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    // Customer name with autocomplete
                    formSection(header: "Customer Name") {
                        VStack(spacing: 0) {
                            formTextField(
                                placeholder: "Full name",
                                text: $customerName,
                                field: .customerName,
                                keyboardType: .default
                            )
                            .onChange(of: customerName) { _, newValue in
                                showAutoComplete = !newValue.isEmpty && !autoCompleteSuggestions.isEmpty
                            }
                            if showAutoComplete {
                                Divider()
                                ForEach(autoCompleteSuggestions.prefix(4), id: \.self) { suggestion in
                                    Button {
                                        customerName = suggestion
                                        showAutoComplete = false
                                        focusedField = .customerID
                                    } label: {
                                        HStack {
                                            Image(systemName: "person.fill")
                                                .font(.system(size: 12))
                                                .foregroundStyle(ifPrimary.opacity(0.7))
                                            Text(suggestion)
                                                .font(.system(.subheadline, design: .rounded))
                                                .foregroundStyle(.primary)
                                            Spacer()
                                        }
                                        .padding(.horizontal, 14)
                                        .padding(.vertical, 10)
                                    }
                                    .buttonStyle(.plain)
                                    Divider()
                                }
                            }
                        }
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: .black.opacity(0.05), radius: 6)
                    }

                    // Customer ID
                    formSection(header: "Driver's License / ID") {
                        formTextField(
                            placeholder: "License number",
                            text: $customerID,
                            field: .customerID,
                            keyboardType: .default
                        )
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: .black.opacity(0.05), radius: 6)
                    }

                    // Incident Date
                    formSection(header: "Incident Date") {
                        HStack {
                            Image(systemName: "calendar")
                                .foregroundStyle(ifPrimary)
                            DatePicker("", selection: $incidentDate, displayedComponents: [.date, .hourAndMinute])
                                .labelsHidden()
                                .accentColor(ifPrimary)
                            Spacer()
                        }
                        .padding(14)
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: .black.opacity(0.05), radius: 6)
                    }

                    // Severity
                    formSection(header: "Severity") {
                        VStack(spacing: 10) {
                            HStack(spacing: 10) {
                                ForEach(IncidentSeverity.allCases, id: \.self) { level in
                                    severityOption(level)
                                }
                            }
                        }
                        .padding(14)
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: .black.opacity(0.05), radius: 6)
                    }

                    // Description
                    formSection(header: "Description") {
                        VStack(alignment: .trailing, spacing: 4) {
                            TextEditor(text: $description)
                                .focused($focusedField, equals: .description)
                                .font(.system(.body, design: .rounded))
                                .frame(minHeight: 90)
                                .scrollContentBackground(.hidden)
                                .background(Color.clear)
                                .padding(10)
                            Text("\(description.count) chars \(description.count < 10 ? "(min 10)" : "")")
                                .font(.system(.caption2, design: .rounded))
                                .foregroundStyle(description.count < 10 ? Color(red: 1.0, green: 0.23, blue: 0.19) : .secondary)
                                .padding(.trailing, 12)
                                .padding(.bottom, 6)
                        }
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: .black.opacity(0.05), radius: 6)
                    }

                    // Reported By
                    formSection(header: "Reported By") {
                        formTextField(
                            placeholder: "Your name",
                            text: $reportedBy,
                            field: .reportedBy,
                            keyboardType: .default
                        )
                        .background(Color(.systemBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .shadow(color: .black.opacity(0.05), radius: 6)
                    }

                    if showValidationError {
                        Text(validationMessage)
                            .font(.system(.subheadline, design: .rounded))
                            .foregroundStyle(Color(red: 1.0, green: 0.23, blue: 0.19))
                            .padding(.horizontal, 4)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("New Incident")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .font(.system(.body, design: .rounded))
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { attemptSave() }
                        .font(.system(.body, design: .rounded).weight(.semibold))
                        .foregroundStyle(isFormValid ? ifPrimary : .secondary)
                }
            }
        }
        .onAppear {
            reportedBy = motelData.businessName
        }
    }

    // MARK: - Severity Option
    private func severityOption(_ level: IncidentSeverity) -> some View {
        Button {
            severity = level
        } label: {
            HStack(spacing: 6) {
                Image(systemName: level.icon)
                    .font(.system(size: 13, weight: .semibold))
                Text(level.rawValue)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
            }
            .foregroundStyle(severity == level ? .white : level.color)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 9)
            .background(
                severity == level
                    ? AnyView(level.color)
                    : AnyView(level.color.opacity(0.12))
            )
            .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Form Helpers
    private func formSection<Content: View>(header: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(header.uppercased())
                .font(.system(.caption, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
                .padding(.leading, 4)
            content()
        }
    }

    private func formTextField(
        placeholder: String,
        text: Binding<String>,
        field: FormField,
        keyboardType: UIKeyboardType
    ) -> some View {
        TextField(placeholder, text: text)
            .focused($focusedField, equals: field)
            .font(.system(.body, design: .rounded))
            .keyboardType(keyboardType)
            .padding(14)
    }

    // MARK: - Save
    private func attemptSave() {
        let trimmedName = customerName.trimmingCharacters(in: .whitespaces)
        let trimmedID   = customerID.trimmingCharacters(in: .whitespaces)
        let trimmedDesc = description.trimmingCharacters(in: .whitespaces)
        let trimmedBy   = reportedBy.trimmingCharacters(in: .whitespaces)

        guard !trimmedName.isEmpty else {
            validationMessage = "Customer name is required."; showValidationError = true; return
        }
        guard !trimmedID.isEmpty else {
            validationMessage = "Customer ID / license number is required."; showValidationError = true; return
        }
        guard trimmedDesc.count >= 10 else {
            validationMessage = "Description must be at least 10 characters."; showValidationError = true; return
        }
        guard !trimmedBy.isEmpty else {
            validationMessage = "\"Reported By\" is required."; showValidationError = true; return
        }

        let incident = CDIncidentReport(
            context: CoreDataManager.shared.context,
            customerName: trimmedName,
            customerID: trimmedID,
            incidentDate: incidentDate,
            description: trimmedDesc,
            severity: severity,
            reportedBy: trimmedBy
        )

        motelData.addIncident(incident)
        let haptic = UINotificationFeedbackGenerator()
        haptic.notificationOccurred(.success)
        dismiss()
    }
}
