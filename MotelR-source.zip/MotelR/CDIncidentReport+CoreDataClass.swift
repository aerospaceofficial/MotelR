//
//  CDIncidentReport+CoreDataClass.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/14/24.
//
//

import Foundation
import CoreData

@objc(CDIncidentReport)
public class CDIncidentReport: NSManagedObject {

}
