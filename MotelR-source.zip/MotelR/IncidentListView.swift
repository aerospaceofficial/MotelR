//  IncidentListView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Design Tokens
private let ilPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let ilGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let ilGreen = Color(red: 0.20, green: 0.78, blue: 0.35)
private let ilRed   = Color(red: 1.0,  green: 0.23, blue: 0.19)
private let ilGold  = Color(red: 0.96, green: 0.65, blue: 0.14)

// MARK: - Filter Options
private enum IncidentFilter: String, CaseIterable, Identifiable {
    case all      = "All"
    case open     = "Open"
    case resolved = "Resolved"
    case low      = "Low"
    case medium   = "Medium"
    case high     = "High"
    var id: String { rawValue }
}

// MARK: - IncidentListView
struct IncidentListView: View {
    @EnvironmentObject var motelData: MotelData
    @State private var activeFilter: IncidentFilter = .all
    @State private var searchText = ""
    @State private var showingForm = false
    @State private var incidentToDelete: CDIncidentReport?
    @State private var showDeleteConfirmation = false
    @State private var deleteError: String?
    @State private var showDeleteError = false

    private var filteredIncidents: [CDIncidentReport] {
        motelData.incidents
            .filter { incident in
                // text search
                if !searchText.isEmpty {
                    let query = searchText.lowercased()
                    let nameMatch = incident.customerName.lowercased().contains(query)
                    let descMatch = incident.incidentDescription.lowercased().contains(query)
                    if !nameMatch && !descMatch { return false }
                }
                // chip filter
                switch activeFilter {
                case .all:      return true
                case .open:     return !incident.isResolved
                case .resolved: return incident.isResolved
                case .low:      return incident.severityLevel == .low
                case .medium:   return incident.severityLevel == .medium
                case .high:     return incident.severityLevel == .high
                }
            }
            .sorted { $0.incidentDate > $1.incidentDate }
    }

    private var openCount: Int  { motelData.incidents.filter { !$0.isResolved }.count }
    private var lowCount: Int   { motelData.incidents.filter { !$0.isResolved && $0.severityLevel == .low }.count }
    private var medCount: Int   { motelData.incidents.filter { !$0.isResolved && $0.severityLevel == .medium }.count }
    private var highCount: Int  { motelData.incidents.filter { !$0.isResolved && $0.severityLevel == .high }.count }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                statsHeader
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                    .padding(.bottom, 8)

                searchBar
                    .padding(.horizontal, 16)
                    .padding(.bottom, 8)

                filterChips
                    .padding(.bottom, 8)

                incidentList
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Incident Reports")
            .navigationBarTitleDisplayMode(.large)
            .overlay(alignment: .bottomTrailing) { fab }
            .sheet(isPresented: $showingForm) {
                IncidentFormView()
                    .environmentObject(motelData)
            }
            .confirmationDialog(
                "Delete Incident",
                isPresented: $showDeleteConfirmation,
                titleVisibility: .visible
            ) {
                Button("Delete", role: .destructive) {
                    if let incident = incidentToDelete {
                        do {
                            try motelData.deleteIncident(incident)
                        } catch {
                            deleteError = error.localizedDescription
                            showDeleteError = true
                        }
                    }
                    incidentToDelete = nil
                }
                Button("Cancel", role: .cancel) { incidentToDelete = nil }
            } message: {
                Text("This incident report will be permanently deleted.")
            }
            .alert("Delete Failed", isPresented: $showDeleteError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(deleteError ?? "An unknown error occurred.")
            }
        }
    }

    // MARK: Stats Header
    private var statsHeader: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text("\(openCount)")
                    .font(.system(.title2, design: .rounded).weight(.bold))
                    .foregroundStyle(openCount > 0 ? ilRed : .primary)
                Text("Open")
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.secondary)
            }
            Spacer()
            HStack(spacing: 14) {
                severityPill(count: highCount, severity: .high)
                severityPill(count: medCount,  severity: .medium)
                severityPill(count: lowCount,  severity: .low)
            }
        }
        .padding(14)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.07), radius: 8)
    }

    private func severityPill(count: Int, severity: IncidentSeverity) -> some View {
        HStack(spacing: 4) {
            Circle()
                .fill(severity.color)
                .frame(width: 8, height: 8)
            Text("\(count) \(severity.rawValue)")
                .font(.system(.caption2, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
        }
    }

    // MARK: Search Bar
    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)
            TextField("Search name or description…", text: $searchText)
                .font(.system(.body, design: .rounded))
            if !searchText.isEmpty {
                Button { searchText = "" } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    // MARK: Filter Chips
    private var filterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(IncidentFilter.allCases) { filter in
                    filterChip(filter)
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private func filterChip(_ filter: IncidentFilter) -> some View {
        Button {
            withAnimation(.easeInOut(duration: 0.2)) {
                activeFilter = filter
            }
        } label: {
            Text(filter.rawValue)
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(activeFilter == filter ? .white : ilPrimary)
                .padding(.horizontal, 14)
                .padding(.vertical, 7)
                .background(
                    activeFilter == filter
                        ? ilGradient
                        : LinearGradient(colors: [ilPrimary.opacity(0.1), ilPrimary.opacity(0.1)], startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: Incident List
    @ViewBuilder
    private var incidentList: some View {
        if filteredIncidents.isEmpty {
            Spacer()
            VStack(spacing: 16) {
                Image(systemName: "shield.slash")
                    .font(.system(size: 52))
                    .foregroundStyle(ilPrimary.opacity(0.3))
                Text(searchText.isEmpty ? "No Incidents" : "No Results")
                    .font(.system(.headline, design: .rounded))
                Text(searchText.isEmpty ? "All clear — no incident reports." : "Try a different search term.")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(40)
            Spacer()
        } else {
            List {
                ForEach(filteredIncidents) { incident in
                    NavigationLink(destination: IncidentDetailView(incident: incident).environmentObject(motelData)) {
                        IncidentCard(incident: incident)
                    }
                    .listRowBackground(Color(.systemBackground))
                    .listRowSeparator(.hidden)
                    .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            incidentToDelete = incident
                            showDeleteConfirmation = true
                        } label: {
                            Label("Delete", systemImage: "trash.fill")
                        }
                    }
                }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(Color(.systemGroupedBackground))
        }
    }

    // MARK: FAB
    private var fab: some View {
        Button {
            showingForm = true
        } label: {
            Image(systemName: "plus")
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: 56, height: 56)
                .background(ilGradient)
                .clipShape(Circle())
                .shadow(color: ilPrimary.opacity(0.40), radius: 12, y: 6)
        }
        .padding(.trailing, 24)
        .padding(.bottom, 24)
    }
}

// MARK: - Incident Card
private struct IncidentCard: View {
    let incident: CDIncidentReport

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .medium
        return f
    }()

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top) {
                // Severity badge
                HStack(spacing: 5) {
                    Image(systemName: incident.severityLevel.icon)
                        .font(.system(size: 11, weight: .bold))
                    Text(incident.severityLevel.rawValue)
                        .font(.system(.caption, design: .rounded).weight(.bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 9)
                .padding(.vertical, 4)
                .background(incident.severityLevel.color)
                .clipShape(Capsule())

                Spacer()

                if incident.isResolved {
                    HStack(spacing: 4) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 13))
                        Text("Resolved")
                            .font(.system(.caption, design: .rounded).weight(.semibold))
                    }
                    .foregroundStyle(Color(red: 0.20, green: 0.78, blue: 0.35))
                }
            }

            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(incident.customerName)
                        .font(.system(.headline, design: .rounded).weight(.semibold))
                    Text(Self.dateFormatter.string(from: incident.incidentDate))
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }

            Text(incident.incidentDescription)
                .font(.system(.subheadline, design: .rounded))
                .foregroundStyle(.secondary)
                .lineLimit(2)

            HStack {
                Image(systemName: "person.fill")
                    .font(.system(size: 11))
                    .foregroundStyle(.tertiary)
                Text("Reported by \(incident.reportedBy)")
                    .font(.system(.caption2, design: .rounded))
                    .foregroundStyle(.tertiary)
            }
        }
        .padding(14)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 3)
    }
}
