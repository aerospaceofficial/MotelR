//  ManageRoomsView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Housekeeping Status

enum HousekeepingStatus: String {
    case available = "available"
    case occupied  = "occupied"
    case cleaning  = "cleaning"

    var label: String {
        switch self {
        case .available: return "Available"
        case .occupied:  return "Occupied"
        case .cleaning:  return "Cleaning"
        }
    }

    var color: Color {
        switch self {
        case .available: return Color(red: 0.20, green: 0.78, blue: 0.35)
        case .occupied:  return Color(red: 1.0,  green: 0.23, blue: 0.19)
        case .cleaning:  return Color(red: 0.96, green: 0.65, blue: 0.14)
        }
    }

    var icon: String {
        switch self {
        case .available: return "checkmark.circle.fill"
        case .occupied:  return "bed.double.fill"
        case .cleaning:  return "bubbles.and.sparkles.fill"
        }
    }
}

// MARK: - UserDefaults helpers

private func housekeepingStatus(for room: CDRoom) -> HousekeepingStatus {
    RoomHousekeeping.status(for: room)
}

private func setHousekeepingStatus(_ status: HousekeepingStatus, for room: CDRoom) {
    RoomHousekeeping.set(status, for: room)
}

// MARK: - ManageRoomsView

struct ManageRoomsView: View {
    @EnvironmentObject var motelData: MotelData

    // Add Room sheet
    @State private var showAddRoomSheet      = false
    // Room detail sheet
    @State private var selectedRoom: CDRoom? = nil
    // Delete confirmation
    @State private var showDeleteConfirmation = false
    @State private var roomsToDelete: IndexSet?
    @State private var showOccupiedDeleteAlert = false
    @State private var occupiedDeleteMessage = ""
    // Housekeeping refresh trigger
    @State private var housekeepingTick: UUID = UUID()

    private let gridColumns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    // MARK: Computed helpers

    /// Occupied only while a guest is actually staying; a future reservation
    /// leaves the room available until its check-in day.
    private func isOccupied(_ room: CDRoom) -> Bool {
        motelData.currentBooking(for: room) != nil
    }

    private func effectiveStatus(for room: CDRoom) -> HousekeepingStatus {
        if isOccupied(room) { return .occupied }
        return housekeepingStatus(for: room)
    }

    private func currentGuest(for room: CDRoom) -> String? {
        motelData.currentBooking(for: room)?.customerName
    }

    private var roomsNeedingAttention: [CDRoom] {
        motelData.rooms.filter { effectiveStatus(for: $0) == .cleaning }
    }

    // MARK: Body

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Color(.systemGroupedBackground).ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 24) {

                    // ── Header ──────────────────────────────────────────
                    headerView

                    // ── Stats Bar ────────────────────────────────────────
                    statsBar

                    // ── Room Grid ────────────────────────────────────────
                    roomGridSection

                    // ── Housekeeping ────────────────────────────────────
                    if !roomsNeedingAttention.isEmpty {
                        housekeepingSection
                    }

                    // ── Room List ────────────────────────────────────────
                    roomListSection

                    // Bottom padding for FAB
                    Color.clear.frame(height: 80)
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .readableWidth()
            }

            // ── FAB ──────────────────────────────────────────────────
            addRoomFAB
        }
        .navigationTitle("Rooms")
        .navigationBarTitleDisplayMode(.large)
        .sheet(isPresented: $showAddRoomSheet) {
            AddRoomSheet()
                .environmentObject(motelData)
        }
        .sheet(item: $selectedRoom) { room in
            RoomDetailSheet(
                room: room,
                onHousekeepingChange: { housekeepingTick = UUID() },
                onRequestDelete: { target in
                    // Wait for the sheet to finish dismissing before the object goes away.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                        guard let idx = motelData.rooms.firstIndex(where: { $0.id == target.id }) else { return }
                        if !motelData.deleteRoom(at: IndexSet([idx])) {
                            occupiedDeleteMessage = "This room still has an active booking. Check the guest out before deleting the room."
                            showOccupiedDeleteAlert = true
                        }
                    }
                }
            )
            .environmentObject(motelData)
        }
        .confirmationDialog("Delete Room?", isPresented: $showDeleteConfirmation, titleVisibility: .visible) {
            Button("Delete", role: .destructive) {
                if let offsets = roomsToDelete, !motelData.deleteRoom(at: offsets) {
                    occupiedDeleteMessage = "This room still has an active booking. Check the guest out before deleting the room."
                    showOccupiedDeleteAlert = true
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text(deleteConfirmationMessage)
        }
        .alert("Room In Use", isPresented: $showOccupiedDeleteAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(occupiedDeleteMessage)
        }
        .id(housekeepingTick)
        // Housekeeping changed on another of the owner's devices.
        .onReceive(NotificationCenter.default.publisher(for: SettingsSync.didChangeExternally)) { _ in
            housekeepingTick = UUID()
        }
    }

    /// Spells out exactly what a delete will take with it, so past guest records are
    /// never removed by surprise.
    private var deleteConfirmationMessage: String {
        guard let offsets = roomsToDelete else {
            return "This will permanently remove the room and all its data."
        }
        let targets = offsets.compactMap { $0 < motelData.rooms.count ? motelData.rooms[$0] : nil }
        if targets.contains(where: { motelData.activeBookingCount(for: $0) > 0 }) {
            return "This room still has an active booking and cannot be deleted yet."
        }
        let historyCount = targets.reduce(0) { $0 + motelData.historyBookingCount(for: $1) }
        if historyCount > 0 {
            return "This will permanently remove the room and \(historyCount) past booking record\(historyCount == 1 ? "" : "s")."
        }
        return "This will permanently remove the room."
    }

    // MARK: Subviews

    private var headerView: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("\(motelData.rooms.count) rooms registered")
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "building.2.fill")
                .font(.system(size: 28))
                .foregroundStyle(
                    LinearGradient(
                        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                 Color(red: 0.05, green: 0.12, blue: 0.65)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        }
        .padding(.top, 4)
    }

    private var statsBar: some View {
        let occupied  = motelData.rooms.filter { isOccupied($0) }.count
        let cleaning  = motelData.rooms.filter { effectiveStatus(for: $0) == .cleaning }.count
        let available = motelData.rooms.count - occupied - cleaning

        return HStack(spacing: 12) {
            StatPill(value: occupied,  label: "Occupied",  color: Color(red: 1.0, green: 0.23, blue: 0.19))
            StatPill(value: available, label: "Available", color: Color(red: 0.20, green: 0.78, blue: 0.35))
            StatPill(value: cleaning,  label: "Cleaning",  color: Color(red: 0.96, green: 0.65, blue: 0.14))
        }
    }

    private var roomGridSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Room Overview", systemImage: "square.grid.3x3.fill")

            LazyVGrid(columns: gridColumns, spacing: 12) {
                ForEach(motelData.rooms) { room in
                    RoomGridCard(
                        room: room,
                        status: effectiveStatus(for: room),
                        guestName: currentGuest(for: room)
                    )
                    .onTapGesture {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                            selectedRoom = room
                        }
                    }
                }
            }
        }
    }

    private var housekeepingSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "Needs Cleaning", systemImage: "bubbles.and.sparkles.fill")

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(roomsNeedingAttention) { room in
                        HousekeepingCard(
                            room: room,
                            isOccupied: isOccupied(room),
                            onStatusChange: { newStatus in
                                setHousekeepingStatus(newStatus, for: room)
                                withAnimation(.spring()) { housekeepingTick = UUID() }
                            }
                        )
                    }
                }
                .padding(.horizontal, 2)
                .padding(.bottom, 4)
            }
        }
    }

    private var roomListSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            SectionHeader(title: "All Rooms", systemImage: "list.bullet.rectangle.fill")

            VStack(spacing: 0) {
                ForEach(Array(motelData.rooms.enumerated()), id: \.element.id) { index, room in
                    RoomListRow(
                        room: room,
                        status: effectiveStatus(for: room),
                        guestName: currentGuest(for: room)
                    )
                    .onTapGesture { selectedRoom = room }
                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                        Button(role: .destructive) {
                            roomsToDelete = IndexSet([index])
                            showDeleteConfirmation = true
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }

                    if index < motelData.rooms.count - 1 {
                        Divider().padding(.leading, 72)
                    }
                }
            }
            .background(Color(.systemBackground))
            .cornerRadius(18)
            .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
        }
    }

    private var addRoomFAB: some View {
        Button(action: { showAddRoomSheet = true }) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                     Color(red: 0.05, green: 0.12, blue: 0.65)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 60, height: 60)
                    .shadow(color: Color(red: 0.05, green: 0.12, blue: 0.65).opacity(0.45), radius: 12, x: 0, y: 6)

                Image(systemName: "plus")
                    .font(.system(size: 24, weight: .semibold))
                    .foregroundColor(.white)
            }
        }
        .padding(.trailing, 20)
        .padding(.bottom, 28)
    }
}

// MARK: - Supporting Views

private struct StatPill: View {
    let value: Int
    let label: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text("\(value)")
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(color.opacity(0.10))
        .cornerRadius(14)
    }
}

private struct SectionHeader: View {
    let title: String
    let systemImage: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: systemImage)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
            Text(title)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .foregroundColor(.primary)
        }
    }
}

private struct RoomGridCard: View {
    let room: CDRoom
    let status: HousekeepingStatus
    let guestName: String?

    var body: some View {
        VStack(spacing: 6) {
            Text("\(room.number)")
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundColor(.primary)

            if !room.name.isEmpty {
                Text(room.name)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }

            HStack(spacing: 3) {
                Circle()
                    .fill(status.color)
                    .frame(width: 7, height: 7)
                Text(status.label)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundColor(status.color)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(status.color.opacity(0.12))
            .cornerRadius(8)

            if let guest = guestName {
                Text(guest)
                    .font(.system(size: 9, weight: .regular, design: .rounded))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                    .truncationMode(.tail)
            }
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 6)
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(status.color.opacity(0.25), lineWidth: 1.5)
        )
        .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 3)
    }
}

private struct HousekeepingCard: View {
    let room: CDRoom
    let isOccupied: Bool
    let onStatusChange: (HousekeepingStatus) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Room \(room.number)")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                Spacer()
                Image(systemName: "bubbles.and.sparkles.fill")
                    .foregroundColor(Color(red: 0.96, green: 0.65, blue: 0.14))
            }

            if !room.name.isEmpty {
                Text(room.name)
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
            }

            HStack(spacing: 8) {
                ForEach([HousekeepingStatus.available, .occupied, .cleaning], id: \.rawValue) { s in
                    Button(action: {
                        if !isOccupied || s != .available {
                            onStatusChange(s)
                        }
                    }) {
                        Image(systemName: s.icon)
                            .font(.system(size: 18))
                            .foregroundColor(s.color)
                            .padding(6)
                            .background(s.color.opacity(0.12))
                            .clipShape(Circle())
                    }
                    .disabled(isOccupied && s == .available)
                    .opacity(isOccupied && s == .available ? 0.35 : 1.0)
                }
            }
        }
        .padding(14)
        .frame(width: 160)
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.07), radius: 8, x: 0, y: 3)
    }
}

private struct RoomListRow: View {
    let room: CDRoom
    let status: HousekeepingStatus
    let guestName: String?

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(
                        LinearGradient(
                            colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                     Color(red: 0.05, green: 0.12, blue: 0.65)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 44, height: 44)
                Text("\(room.number)")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            }

            VStack(alignment: .leading, spacing: 2) {
                Text(room.name.isEmpty ? "Room \(room.number)" : room.name)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))

                HStack(spacing: 4) {
                    Text(room.members.isEmpty ? "—" : room.members)
                        .font(.system(size: 12, design: .rounded))
                        .foregroundColor(.secondary)

                    if let guest = guestName {
                        Text("· \(guest)")
                            .font(.system(size: 12, design: .rounded))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                }
            }

            Spacer()

            Text(status.label)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundColor(status.color)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(status.color.opacity(0.12))
                .cornerRadius(10)

            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(Color(UIColor.tertiaryLabel))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }
}

// MARK: - Add Room Sheet

struct AddRoomSheet: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    @State private var roomNumber = ""
    @State private var roomName   = ""
    @State private var members    = ""

    @State private var showDuplicateAlert  = false
    @State private var showValidationAlert = false
    @State private var validationMessage   = ""
    @State private var appeared            = false

    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 24) {

                        // Icon
                        ZStack {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                                 Color(red: 0.05, green: 0.12, blue: 0.65)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 72, height: 72)
                            Image(systemName: "plus.square.fill")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                        }
                        .scaleEffect(appeared ? 1.0 : 0.5)
                        .opacity(appeared ? 1.0 : 0.0)
                        .padding(.top, 8)

                        // Form card
                        VStack(spacing: 0) {
                            FormField(
                                icon: "number.square.fill",
                                iconColor: Color(red: 0.18, green: 0.27, blue: 0.90),
                                label: "Room Number",
                                placeholder: "e.g. 101",
                                text: $roomNumber,
                                keyboardType: .numberPad
                            )
                            Divider().padding(.leading, 56)

                            FormField(
                                icon: "tag.fill",
                                iconColor: Color(red: 0.96, green: 0.65, blue: 0.14),
                                label: "Room Name",
                                placeholder: "e.g. King Suite (optional)",
                                text: $roomName
                            )
                            Divider().padding(.leading, 56)

                            FormField(
                                icon: "person.2.fill",
                                iconColor: Color(red: 0.20, green: 0.78, blue: 0.35),
                                label: "Members / Description",
                                placeholder: "e.g. 2 guests max",
                                text: $members
                            )
                        }
                        .background(Color(.systemBackground))
                        .cornerRadius(18)
                        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)

                        // Add button
                        Button(action: addRoom) {
                            HStack {
                                Image(systemName: "plus.circle.fill")
                                Text("Add Room")
                                    .font(.system(size: 17, weight: .semibold, design: .rounded))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(
                                    colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                             Color(red: 0.05, green: 0.12, blue: 0.65)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .cornerRadius(16)
                            .shadow(color: Color(red: 0.05, green: 0.12, blue: 0.65).opacity(0.4), radius: 8, x: 0, y: 4)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
            }
            .navigationTitle("Add New Room")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .alert("Duplicate Room", isPresented: $showDuplicateAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Room number \(roomNumber) is already registered.")
            }
            .alert("Invalid Input", isPresented: $showValidationAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(validationMessage)
            }
            .onAppear {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.65)) {
                    appeared = true
                }
            }
        }
    }

    private func addRoom() {
        // Room numbers are stored as Int16, so anything outside that range must be
        // rejected here — converting it would trap and crash the app.
        guard let number = Int(roomNumber.trimmingCharacters(in: .whitespaces)),
              number > 0, number <= Int(Int16.max) else {
            validationMessage = "Please enter a valid room number between 1 and \(Int16.max)."
            showValidationAlert = true
            return
        }
        guard !members.trimmingCharacters(in: .whitespaces).isEmpty else {
            validationMessage = "Please enter a description or occupancy for the room."
            showValidationAlert = true
            return
        }
        if motelData.rooms.contains(where: { $0.number == Int16(number) }) {
            showDuplicateAlert = true
            return
        }
        motelData.addRoom(number, name: roomName.trimmingCharacters(in: .whitespaces), members: members.trimmingCharacters(in: .whitespaces))
        dismiss()
    }
}

private struct FormField: View {
    let icon: String
    let iconColor: Color
    let label: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundColor(iconColor)
                .frame(width: 28)
                .padding(.leading, 16)

            VStack(alignment: .leading, spacing: 2) {
                Text(label)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
                TextField(placeholder, text: $text)
                    .font(.system(size: 16, design: .rounded))
                    .keyboardType(keyboardType)
            }
            .padding(.vertical, 12)
            .padding(.trailing, 16)
        }
    }
}

// MARK: - Room Detail Sheet

struct RoomDetailSheet: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    let room: CDRoom
    let onHousekeepingChange: () -> Void
    /// Deletion is handed back to the parent so it happens after this sheet is
    /// gone — rendering a row from an already-deleted room crashes.
    var onRequestDelete: (CDRoom) -> Void = { _ in }

    @State private var editedName    = ""
    @State private var editedMembers = ""
    @State private var isEditing     = false
    @State private var selectedStatus: HousekeepingStatus = .available
    @State private var showDeleteConfirm = false
    @State private var showOccupiedDeleteAlert = false
    @State private var showCheckOutConfirm = false

    private var isOccupied: Bool {
        motelData.currentBooking(for: room) != nil
    }

    private var currentBooking: CDBooking? {
        motelData.currentBooking(for: room)
    }

    private var effectiveStatus: HousekeepingStatus {
        isOccupied ? .occupied : selectedStatus
    }

    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {

                        // Room header card
                        roomHeaderCard

                        // Occupant card (if occupied)
                        if let booking = currentBooking {
                            occupantCard(booking: booking)
                        }

                        // Housekeeping card
                        housekeepingCard

                        // Edit card
                        editCard

                        // Delete button
                        deleteButton
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("Room \(room.number)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        if isEditing { saveEdits() }
                        dismiss()
                    }
                }
            }
            .confirmationDialog(
                "Check out Room \(room.number)?",
                isPresented: $showCheckOutConfirm,
                titleVisibility: .visible
            ) {
                Button("Check Out", role: .destructive) {
                    motelData.checkOutRoom(room)
                    dismiss()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will move the booking to history.")
            }
            .confirmationDialog(
                "Delete Room \(room.number)?",
                isPresented: $showDeleteConfirm,
                titleVisibility: .visible
            ) {
                Button("Delete Room", role: .destructive) {
                    guard motelData.activeBookingCount(for: room) == 0 else {
                        showOccupiedDeleteAlert = true
                        return
                    }
                    let target = room
                    dismiss()
                    onRequestDelete(target)
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text(detailDeleteMessage)
            }
            .alert("Room In Use", isPresented: $showOccupiedDeleteAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("This room still has an active booking. Check the guest out before deleting the room.")
            }
            .onAppear {
                editedName    = room.name
                editedMembers = room.members
                selectedStatus = isOccupied ? .occupied : housekeepingStatus(for: room)
            }
        }
    }

    /// States up front how many past booking records go with the room.
    private var detailDeleteMessage: String {
        if motelData.activeBookingCount(for: room) > 0 {
            return "This room still has an active booking and cannot be deleted yet."
        }
        let historyCount = motelData.historyBookingCount(for: room)
        if historyCount > 0 {
            return "This will permanently remove the room and \(historyCount) past booking record\(historyCount == 1 ? "" : "s"). This cannot be undone."
        }
        return "This action cannot be undone."
    }

    // MARK: Detail subviews

    private var roomHeaderCard: some View {
        HStack(spacing: 16) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(
                        LinearGradient(
                            colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                     Color(red: 0.05, green: 0.12, blue: 0.65)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 64, height: 64)
                Text("\(room.number)")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(room.name.isEmpty ? "Room \(room.number)" : room.name)
                    .font(.system(size: 20, weight: .bold, design: .rounded))

                Text(room.members.isEmpty ? "No description" : room.members)
                    .font(.system(size: 13, design: .rounded))
                    .foregroundColor(.secondary)

                HStack(spacing: 4) {
                    Circle()
                        .fill(effectiveStatus.color)
                        .frame(width: 8, height: 8)
                    Text(effectiveStatus.label)
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundColor(effectiveStatus.color)
                }
            }
            Spacer()
        }
        .padding(18)
        .background(Color(.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }

    private func occupantCard(booking: CDBooking) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Current Guest", systemImage: "person.fill")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundColor(.secondary)
                Spacer()
            }

            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.12))
                        .frame(width: 44, height: 44)
                    Text(String(booking.customerName.prefix(1)).uppercased())
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(booking.customerName)
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                    Text(booking.phoneNumber)
                        .font(.system(size: 13, design: .rounded))
                        .foregroundColor(.secondary)
                }
                Spacer()
            }

            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Check-in")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundColor(.secondary)
                    Text(booking.checkInDate, style: .date)
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Check-out")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundColor(.secondary)
                    Text(booking.checkOutDate, style: .date)
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("Amount")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundColor(.secondary)
                    Text(booking.prize)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundColor(Color(red: 0.96, green: 0.65, blue: 0.14))
                }
            }
            .padding(.top, 4)

            Button(action: { showCheckOutConfirm = true }) {
                HStack {
                    Image(systemName: "arrow.right.square.fill")
                    Text("Check Out Guest")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(Color(red: 1.0, green: 0.23, blue: 0.19))
                .cornerRadius(12)
            }
        }
        .padding(18)
        .background(Color(.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }

    private var housekeepingCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("Housekeeping Status", systemImage: "bubbles.and.sparkles")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundColor(.secondary)

            HStack(spacing: 10) {
                ForEach([HousekeepingStatus.available, .cleaning, .occupied], id: \.rawValue) { s in
                    Button(action: {
                        guard !isOccupied else { return }
                        withAnimation(.spring()) {
                            selectedStatus = s
                            setHousekeepingStatus(s, for: room)
                            onHousekeepingChange()
                        }
                    }) {
                        VStack(spacing: 6) {
                            Image(systemName: s.icon)
                                .font(.system(size: 20))
                                .foregroundColor(effectiveStatus == s ? .white : s.color)
                            Text(s.label)
                                .font(.system(size: 11, weight: .semibold, design: .rounded))
                                .foregroundColor(effectiveStatus == s ? .white : s.color)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(effectiveStatus == s ? s.color : s.color.opacity(0.10))
                        .cornerRadius(12)
                    }
                    .disabled(isOccupied)
                }
            }

            if isOccupied {
                Text("Housekeeping status is locked while a guest is checked in.")
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
            }
        }
        .padding(18)
        .background(Color(.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }

    private var editCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Edit Details", systemImage: "pencil")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundColor(.secondary)
                Spacer()
                if isEditing {
                    Button("Save") { saveEdits() }
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                } else {
                    Button("Edit") {
                        withAnimation { isEditing = true }
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                }
            }

            VStack(spacing: 12) {
                HStack {
                    Text("Name")
                        .font(.system(size: 13, weight: .medium, design: .rounded))
                        .foregroundColor(.secondary)
                        .frame(width: 80, alignment: .leading)
                    if isEditing {
                        TextField("Room Name", text: $editedName)
                            .font(.system(size: 15, design: .rounded))
                            .textFieldStyle(.roundedBorder)
                    } else {
                        Text(editedName.isEmpty ? "—" : editedName)
                            .font(.system(size: 15, design: .rounded))
                    }
                }
                Divider()
                HStack {
                    Text("Members")
                        .font(.system(size: 13, weight: .medium, design: .rounded))
                        .foregroundColor(.secondary)
                        .frame(width: 80, alignment: .leading)
                    if isEditing {
                        TextField("Description / Occupancy", text: $editedMembers)
                            .font(.system(size: 15, design: .rounded))
                            .textFieldStyle(.roundedBorder)
                    } else {
                        Text(editedMembers.isEmpty ? "—" : editedMembers)
                            .font(.system(size: 15, design: .rounded))
                    }
                }
            }
        }
        .padding(18)
        .background(Color(.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }

    private var deleteButton: some View {
        Button(action: { showDeleteConfirm = true }) {
            HStack {
                Image(systemName: "trash.fill")
                Text("Delete Room")
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
            }
            .foregroundColor(Color(red: 1.0, green: 0.23, blue: 0.19))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color(red: 1.0, green: 0.23, blue: 0.19).opacity(0.08))
            .cornerRadius(14)
        }
    }

    private func saveEdits() {
        room.name    = editedName.trimmingCharacters(in: .whitespaces)
        room.members = editedMembers.trimmingCharacters(in: .whitespaces)
        CoreDataManager.shared.save()
        motelData.fetchAllData()
        withAnimation { isEditing = false }
    }
}

// MARK: - Preview

struct ManageRoomsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ManageRoomsView()
                .environmentObject(MotelData())
        }
    }
}
