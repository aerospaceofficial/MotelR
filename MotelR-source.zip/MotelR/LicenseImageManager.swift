//
//  LicenseImageManager.swift
//  MotelR
//
//  New licence photos are stored inside the booking itself (Booking.licenseImageData),
//  so they sync through the owner's private iCloud like the rest of the booking.
//  Each photo is shrunk first (see `prepareForStorage`) to keep the database small.
//
//  Older builds wrote photos to files on disk. Those files never left the device,
//  so `MotelData` moves them into their bookings once, on launch. The file helpers
//  below stay for that migration and for cleaning up legacy files.
//
//  These are photographs of government ID, so they live in Application Support
//  rather than Documents: the app enables iTunes/Files file sharing, which would
//  otherwise expose every guest's licence to anyone browsing the device.
//

import UIKit

enum LicenseImageManager {

    private static let folderName = "LicenseImages"

    private static var directory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory())
        var dir = base.appendingPathComponent(folderName)

        try? FileManager.default.createDirectory(
            at: dir,
            withIntermediateDirectories: true,
            // Readable by background backup tasks, but not while the device is locked
            // and has never been unlocked.
            attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication]
        )

        // Exclude sensitive ID photos from iCloud and iTunes device backups.
        var resourceValues = URLResourceValues()
        resourceValues.isExcludedFromBackup = true
        try? dir.setResourceValues(resourceValues)

        migrateLegacyImagesIfNeeded(to: dir)
        return dir
    }

    /// Earlier builds kept these in Documents, which is file-sharing visible.
    /// Move anything left there across on first use, then remove the old folder.
    private static var didMigrate = false
    private static func migrateLegacyImagesIfNeeded(to newDirectory: URL) {
        guard !didMigrate else { return }
        didMigrate = true

        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        else { return }
        let legacy = documents.appendingPathComponent(folderName)
        guard FileManager.default.fileExists(atPath: legacy.path),
              let files = try? FileManager.default.contentsOfDirectory(at: legacy, includingPropertiesForKeys: nil)
        else { return }

        for file in files {
            let destination = newDirectory.appendingPathComponent(file.lastPathComponent)
            if FileManager.default.fileExists(atPath: destination.path) {
                try? FileManager.default.removeItem(at: file)
            } else {
                try? FileManager.default.moveItem(at: file, to: destination)
            }
        }
        try? FileManager.default.removeItem(at: legacy)
    }

    /// Shrinks a licence photo before it is stored in a booking: longest side at most
    /// 1200 pt, JPEG at 0.6 quality. That keeps the text on the licence readable while
    /// keeping each photo to roughly 100 KB, which matters because it syncs through iCloud.
    static func prepareForStorage(_ data: Data) -> Data {
        guard let image = UIImage(data: data) else { return data }
        let maxSide: CGFloat = 1200
        let longest = max(image.size.width, image.size.height)
        // Already small enough (e.g. restored from a backup): keep it as-is rather
        // than re-compressing and losing quality every time.
        if longest <= maxSide && data.count <= 250_000 { return data }
        var output = image
        if longest > maxSide {
            let scale = maxSide / longest
            let newSize = CGSize(width: (image.size.width * scale).rounded(),
                                 height: (image.size.height * scale).rounded())
            let format = UIGraphicsImageRendererFormat.default()
            format.scale = 1
            output = UIGraphicsImageRenderer(size: newSize, format: format).image { _ in
                image.draw(in: CGRect(origin: .zero, size: newSize))
            }
        }
        return output.jpegData(compressionQuality: 0.6) ?? data
    }

    /// Save image data to disk. Returns the filename to store in Core Data.
    /// Legacy only — new bookings keep the photo in `Booking.licenseImageData`.
    @discardableResult
    static func save(_ data: Data) -> String {
        let filename = UUID().uuidString + ".jpg"
        let url = directory.appendingPathComponent(filename)
        try? data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return filename
    }

    /// Load a license image from disk by filename.
    static func load(named filename: String) -> UIImage? {
        guard let data = data(named: filename) else { return nil }
        return UIImage(data: data)
    }

    /// Read raw data for a license image (used during backup).
    static func data(named filename: String) -> Data? {
        try? Data(contentsOf: directory.appendingPathComponent(filename))
    }

    /// Delete a license image from disk.
    static func delete(named filename: String) {
        try? FileManager.default.removeItem(at: directory.appendingPathComponent(filename))
    }
}
