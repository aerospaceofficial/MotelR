//  MainView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import SafariServices
import UniformTypeIdentifiers

// MARK: - MainView (Root Tab Bar Navigation Hub)

struct MainView: View {
    @EnvironmentObject private var motelData: MotelData
    @State private var selectedTab: Int = 0
    @State private var showAssistant = false
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        TabView(selection: $selectedTab) {

            // Tab 1: Dashboard
            DashboardTab()
                .environmentObject(motelData)
                .tabItem {
                    Label("Dashboard", systemImage: "house.fill")
                }
                .tag(0)

            // Tab 2: Rooms
            NavigationStack {
                ManageRoomsView()
                    .navigationTitle("Rooms")
                    .navigationBarTitleDisplayMode(.large)
            }
            .environmentObject(motelData)
            .tabItem {
                Label("Rooms", systemImage: "bed.double.fill")
            }
            .tag(1)

            // Tab 3: Bookings
            NavigationStack {
                CheckInOutView()
                    .toolbar(.hidden, for: .navigationBar)
            }
            .environmentObject(motelData)
            .tabItem {
                Label("Bookings", systemImage: "calendar")
            }
            .tag(2)

            // Tab 4: Customers
            NavigationStack {
                CustomersView()
                    .navigationTitle("Customers")
                    .navigationBarTitleDisplayMode(.large)
            }
            .environmentObject(motelData)
            .tabItem {
                Label("Customers", systemImage: "person.2.fill")
            }
            .tag(3)

            // Tab 5: More
            MoreTab()
                .environmentObject(motelData)
                .tabItem {
                    Label("More", systemImage: "ellipsis.circle.fill")
                }
                .tag(4)
        }
        .tint(Color(red: 0.18, green: 0.27, blue: 0.90))
        // The assistant is one tap away on every tab.
        #if canImport(FoundationModels)
        .overlay(alignment: .bottomTrailing) {
            // Not on the Dashboard, which has its own Assistant banner (and the button
            // would cover Today's Activity there).
            if AssistantAvailability.current == .available && selectedTab != 0 {
                Button { showAssistant = true } label: {
                    Image(systemName: "sparkles")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundColor(.white)
                        .frame(width: 56, height: 56)
                        .background(
                            LinearGradient(
                                colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
                                startPoint: .topLeading, endPoint: .bottomTrailing
                            ),
                            in: Circle()
                        )
                        .shadow(color: .black.opacity(0.25), radius: 10, y: 4)
                }
                .padding(.trailing, 18)
                // Sit above the screens' own "+" buttons (Rooms: add room;
                // More → Incidents: add incident).
                .padding(.bottom, selectedTab == 1 || selectedTab == 4 ? 150 : 64)
                .accessibilityLabel("MotelR Assistant")
            }
        }
        .sheet(isPresented: $showAssistant) {
            if #available(iOS 26.0, *) {
                BookingAssistantView(motelData: motelData)
            }
        }
        #endif
        // Global data-load error alert
        .alert("Data Load Error", isPresented: Binding(
            get: { motelData.fetchErrorMessage != nil },
            set: { if !$0 { motelData.fetchErrorMessage = nil } }
        )) {
            Button("OK") { motelData.fetchErrorMessage = nil }
        } message: {
            Text(motelData.fetchErrorMessage ?? "")
        }
    }
}

// MARK: - Dashboard Tab

private struct DashboardTab: View {
    @EnvironmentObject private var motelData: MotelData

    // Sheet states
    @State private var showCheckIn        = false
    @State private var showCheckOut       = false
    @State private var showNewBooking     = false
    @State private var showAssistant      = false
    @State private var showOrganizations  = false
    @State private var showSettings       = false
    @State private var showPrivacyPolicy  = false
    @State private var showContactSupport = false

    // Animation
    @State private var headerVisible = false
    @State private var statsVisible  = false
    @State private var bodyVisible   = false

    // MARK: Computed stats
    private var occupiedCount: Int {
        motelData.occupiedRoomCount
    }
    private var todayCheckIns: Int {
        motelData.bookings.filter { Calendar.current.isDateInToday($0.checkInDate) }.count
    }
    private var todayCheckOuts: Int {
        motelData.bookings.filter {
            let cal = Calendar.current
            return cal.isDateInToday($0.checkOutDate) || $0.checkOutDate < Date()
        }.count
    }
    private var monthRevenue: Double {
        let cal = Calendar.current; let now = Date()
        return motelData.paidBookings
            .filter { cal.isDate($0.checkInDate, equalTo: now, toGranularity: .month) }
            .reduce(0) { $0 + $1.prizeAmount }
    }
    private var pendingCount: Int { motelData.pendingBookings.count }

    // Today's activity (up to 5 bookings touching today)
    private var todayActivity: [CDBooking] {
        let cal = Calendar.current; let now = Date()
        return motelData.bookings
            .filter { cal.isDateInToday($0.checkInDate) || cal.isDateInToday($0.checkOutDate) || $0.checkOutDate < now }
            .sorted { $0.checkInDate > $1.checkInDate }
            .prefix(5)
            .map { $0 }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {

                        // ── Hero Header ──────────────────────────────────
                        heroHeader
                            .opacity(headerVisible ? 1 : 0)
                            .offset(y: headerVisible ? 0 : -16)

                        // ── Floating Stats Card ──────────────────────────
                        statsRow
                            .padding(.horizontal, 16)
                            .padding(.top, -28)
                            .opacity(statsVisible ? 1 : 0)
                            .offset(y: statsVisible ? 0 : 18)

                        // ── Main Body ───────────────────────────────────
                        VStack(spacing: 24) {

                            // Pending payments banner
                            if pendingCount > 0 {
                                pendingBanner
                            }

                            // On-device booking assistant (iOS 26+, Apple Intelligence)
                            #if canImport(FoundationModels)
                            assistantBanner
                            #endif

                            // Quick Actions 2x2
                            quickActions

                            // Today's Activity
                            todayActivitySection

                            // Footer
                            footerLinks
                        }
                        .padding(.top, 24)
                        .opacity(bodyVisible ? 1 : 0)
                        .offset(y: bodyVisible ? 0 : 24)
                    }
                    .readableWidth()
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showCheckIn)       { CheckInView().environmentObject(motelData) }
            .sheet(isPresented: $showCheckOut)      { CheckOutView().environmentObject(motelData) }
            .sheet(isPresented: $showNewBooking)    { ViewBookingsView().environmentObject(motelData) }
            #if canImport(FoundationModels)
            .sheet(isPresented: $showAssistant) {
                if #available(iOS 26.0, *) {
                    BookingAssistantView(motelData: motelData)
                }
            }
            #endif
            .sheet(isPresented: $showOrganizations) { OrganizationsView().environmentObject(motelData) }
            .sheet(isPresented: $showSettings)      { SettingsView().environmentObject(motelData) }
            .sheet(isPresented: $showPrivacyPolicy) {
                if let url = URL(string: "https://nishant-co.github.io/MotelR/privacy.html") {
                    SafariView(url: url)
                }
            }
            .sheet(isPresented: $showContactSupport) {
                if let url = URL(string: "https://nishant-co.github.io/MotelR/support.html") {
                    SafariView(url: url)
                }
            }
            // `task` rather than `onAppear`: the dashboard can be swapped in while the
            // setup sheet is still dismissing, and an onAppear missed there left the
            // whole screen stuck at opacity 0 — a blank dashboard.
            .task { revealContent() }
            .onAppear { revealContent() }
        }
    }

    /// Fades the dashboard in. Safe to call more than once, and never leaves the
    /// screen invisible if the entrance animation is skipped.
    private func revealContent() {
        guard !bodyVisible else { return }
        withAnimation(.spring(response: 0.45, dampingFraction: 0.8))             { headerVisible = true }
        withAnimation(.spring(response: 0.45, dampingFraction: 0.8).delay(0.12)) { statsVisible  = true }
        withAnimation(.spring(response: 0.45, dampingFraction: 0.8).delay(0.22)) { bodyVisible   = true }
    }

    // MARK: Hero Header

    private var heroHeader: some View {
        ZStack(alignment: .bottom) {
            LinearGradient(
                colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea(edges: .top)
            .frame(height: 210)

            // Decorative circles
            Circle().fill(Color.white.opacity(0.06)).frame(width: 200).offset(x: 150, y: -55)
            Circle().fill(Color.white.opacity(0.04)).frame(width: 130).offset(x: -140, y: 5)

            VStack(spacing: 0) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 6) {
                            Text(motelData.businessName)
                                .font(.system(size: 26, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            if motelData.isSyncingFromCloud {
                                Image(systemName: "icloud.and.arrow.down")
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.8))
                                    .rotationEffect(.degrees(motelData.isSyncingFromCloud ? 360 : 0))
                                    .animation(
                                        motelData.isSyncingFromCloud
                                            ? .linear(duration: 1.2).repeatForever(autoreverses: false)
                                            : .default,
                                        value: motelData.isSyncingFromCloud
                                    )
                                    .transition(.opacity.combined(with: .scale))
                            }
                        }
                        HStack(spacing: 5) {
                            Image(systemName: greetingIcon)
                                .font(.system(size: 12))
                                .foregroundColor(.white.opacity(0.65))
                            Text(greetingText)
                                .font(.system(size: 13, weight: .medium, design: .rounded))
                                .foregroundColor(.white.opacity(0.70))
                        }
                    }
                    Spacer()
                    // Settings gear
                    Button { showSettings = true } label: {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white.opacity(0.9))
                            .frame(width: 38, height: 38)
                            .background(Color.white.opacity(0.15))
                            .clipShape(Circle())
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 58)

                HStack {
                    Text(todayDateString)
                        .font(.system(size: 13, design: .rounded))
                        .foregroundColor(.white.opacity(0.55))
                    Spacer()
                    if motelData.isSyncingFromCloud {
                        HStack(spacing: 4) {
                            ProgressView()
                                .progressViewStyle(.circular)
                                .scaleEffect(0.65)
                                .tint(.white.opacity(0.7))
                            Text("Syncing with iCloud…")
                                .font(.system(size: 11))
                                .foregroundColor(.white.opacity(0.65))
                        }
                        .transition(.opacity)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 46)
            }
        }
    }

    // MARK: Stats Row

    private var statsRow: some View {
        HStack(spacing: 0) {
            DashStatTile(
                value: "\(occupiedCount)/\(motelData.rooms.count)",
                label: "Occupied",
                icon: "bed.double.fill",
                color: Color(red: 0.18, green: 0.27, blue: 0.90)
            )
            Divider().frame(height: 40)
            DashStatTile(
                value: "\(todayCheckIns)",
                label: "Check-Ins",
                icon: "arrow.right.square.fill",
                color: .green
            )
            Divider().frame(height: 40)
            DashStatTile(
                value: "\(todayCheckOuts)",
                label: "Check-Outs",
                icon: "arrow.left.square.fill",
                color: todayCheckOuts > 0 ? .red : .secondary
            )
            Divider().frame(height: 40)
            DashStatTile(
                value: monthRevenueFormatted,
                label: "This Month",
                icon: "dollarsign.circle.fill",
                color: Color(red: 0.96, green: 0.65, blue: 0.14)
            )
        }
        .padding(.vertical, 18)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(Color(UIColor.systemBackground))
                .shadow(color: .black.opacity(0.10), radius: 14, x: 0, y: 5)
        )
    }

    private var monthRevenueFormatted: String {
        if monthRevenue >= 1000 {
            return "$\(Int(monthRevenue / 1000))k"
        }
        return "$\(Int(monthRevenue))"
    }

    // MARK: Pending Banner

    private var pendingBanner: some View {
        Button { showOrganizations = true } label: {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.18))
                        .frame(width: 44, height: 44)
                    Image(systemName: "clock.badge.exclamationmark.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(Color(red: 0.96, green: 0.65, blue: 0.14))
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(pendingCount) Pending Payment\(pendingCount > 1 ? "s" : "")")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .foregroundColor(.primary)
                    Text("Organization invoices awaiting payment")
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.secondary)
            }
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color(UIColor.systemBackground))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.45), lineWidth: 1.5)
                    )
                    .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 3)
            )
        }
        .buttonStyle(DashScaleButton())
        .padding(.horizontal, 16)
    }

    // MARK: Booking Assistant

    #if canImport(FoundationModels)
    @ViewBuilder
    private var assistantBanner: some View {
        switch AssistantAvailability.current {
        case .available:
            Button { showAssistant = true } label: {
                assistantBannerLabel(
                    title: "MotelR Assistant",
                    subtitle: "Talk or type — it books rooms and answers questions",
                    showsChevron: true
                )
            }
            .buttonStyle(DashScaleButton())
            .padding(.horizontal, 16)
        case .needsAppleIntelligence:
            assistantBannerLabel(
                title: "MotelR Assistant",
                subtitle: "Turn on Apple Intelligence in Settings to use it",
                showsChevron: false
            )
            .opacity(0.75)
            .padding(.horizontal, 16)
        case .modelDownloading:
            assistantBannerLabel(
                title: "MotelR Assistant",
                subtitle: "Getting ready — Apple Intelligence is still downloading",
                showsChevron: false
            )
            .opacity(0.75)
            .padding(.horizontal, 16)
        case .unsupported:
            EmptyView()
        }
    }

    private func assistantBannerLabel(title: String, subtitle: String, showsChevron: Bool) -> some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.white.opacity(0.18))
                    .frame(width: 44, height: 44)
                Image(systemName: "sparkles")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 12, design: .rounded))
                    .foregroundColor(.white.opacity(0.85))
            }
            Spacer()
            if showsChevron {
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.white.opacity(0.8))
            }
        }
        .padding(14)
        .background(
            LinearGradient(
                colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 16)
        )
        .shadow(color: Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.25), radius: 10, y: 4)
    }
    #endif

    // MARK: Quick Actions

    private var quickActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick Actions")
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .padding(.horizontal, 16)

            LazyVGrid(
                columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)],
                spacing: 12
            ) {
                DashActionButton(
                    title: "Check In",
                    subtitle: "\(motelData.rooms.count - occupiedCount) rooms available",
                    icon: "person.badge.plus.fill",
                    color: .green
                ) { showCheckIn = true }

                DashActionButton(
                    title: "Check Out",
                    subtitle: todayCheckOuts > 0 ? "\(todayCheckOuts) due today" : "No checkouts today",
                    icon: "person.badge.minus.fill",
                    color: .red
                ) { showCheckOut = true }

                DashActionButton(
                    title: "New Booking",
                    subtitle: motelData.reservedBookings.isEmpty
                        ? "\(motelData.inHouseBookings.count) in house"
                        : "\(motelData.inHouseBookings.count) in house · \(motelData.reservedBookings.count) reserved",
                    icon: "calendar.badge.plus",
                    color: Color(red: 0.18, green: 0.27, blue: 0.90)
                ) { showNewBooking = true }

                DashActionButton(
                    title: "Organizations",
                    subtitle: pendingCount > 0 ? "\(pendingCount) pending" : "All clear",
                    icon: "building.2.fill",
                    color: Color(red: 0.96, green: 0.65, blue: 0.14)
                ) { showOrganizations = true }
            }
            .padding(.horizontal, 16)
        }
    }

    // MARK: Today's Activity

    private var todayActivitySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Today's Activity")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                Spacer()
                Text(todayDateString)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 16)

            if todayActivity.isEmpty {
                HStack(spacing: 12) {
                    Image(systemName: "moon.zzz.fill")
                        .font(.system(size: 22))
                        .foregroundColor(.secondary.opacity(0.5))
                    Text("No activity today")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(20)
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color(UIColor.systemBackground))
                        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 3)
                )
                .padding(.horizontal, 16)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(todayActivity.enumerated()), id: \.element.id) { idx, booking in
                        ActivityRow(booking: booking)
                        if idx < todayActivity.count - 1 {
                            Divider().padding(.leading, 56)
                        }
                    }
                }
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color(UIColor.systemBackground))
                        .shadow(color: .black.opacity(0.06), radius: 10, x: 0, y: 4)
                )
                .padding(.horizontal, 16)
            }
        }
    }

    // MARK: Footer Links

    private var footerLinks: some View {
        VStack(spacing: 8) {
            Divider().padding(.horizontal, 32)
            HStack(spacing: 0) {
                Button { showPrivacyPolicy = true } label: {
                    Text("Privacy Policy")
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                }
                Text(" · ")
                    .font(.system(size: 11))
                    .foregroundColor(.secondary.opacity(0.4))
                Button { showContactSupport = true } label: {
                    Text("Support")
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                }
            }
            Text("New Journey · MotelR 2.0")
                .font(.system(size: 10))
                .foregroundColor(.secondary.opacity(0.5))
        }
        .padding(.bottom, 24)
    }

    // MARK: Helpers

    private var greetingText: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "Good morning"
        case 12..<17: return "Good afternoon"
        case 17..<21: return "Good evening"
        default:      return "Good night"
        }
    }
    private var greetingIcon: String {
        switch Calendar.current.component(.hour, from: Date()) {
        case 5..<12: return "sun.rise.fill"
        case 12..<17: return "sun.max.fill"
        case 17..<21: return "sun.set.fill"
        default:      return "moon.stars.fill"
        }
    }
    private var todayDateString: String {
        let f = DateFormatter(); f.dateFormat = "EEEE, MMM d"
        return f.string(from: Date())
    }
}

// MARK: - More Tab

private struct MoreTab: View {
    @EnvironmentObject private var motelData: MotelData

    @State private var showSettings         = false
    @State private var showPrivacyPolicy    = false
    @State private var showContactSupport   = false
    @State private var showTermsEditor      = false
    @State private var showWalkthrough      = false

    private var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "2.0"
    }

    var body: some View {
        NavigationStack {
            List {

                // MARK: Reports & Data
                Section {
                    MoreNavRow(title: "History",    icon: "clock.arrow.circlepath",   color: .purple,  destination: HistoryView().environmentObject(motelData))
                    MoreNavRow(title: "Analytics",  icon: "chart.bar.xaxis",          color: Color(red: 0.18, green: 0.27, blue: 0.90), destination: AnalyticsView().environmentObject(motelData))
                    MoreNavRow(title: "Reports",    icon: "doc.richtext.fill",         color: .indigo,  destination: ReportsView().environmentObject(motelData))
                } header: {
                    MoreSectionHeader(title: "Reports & Data")
                }

                // MARK: Management
                Section {
                    MoreNavRow(title: "Organizations", icon: "building.2.fill",               color: Color(red: 0.96, green: 0.65, blue: 0.14), destination: OrganizationsView().environmentObject(motelData))
                    MoreNavRow(title: "Incidents",     icon: "exclamationmark.triangle.fill",  color: .red,  destination: IncidentListView().environmentObject(motelData))
                } header: {
                    MoreSectionHeader(title: "Management")
                }

                // MARK: App
                Section {
                    MoreNavRow(title: "Terms & Conditions", icon: "doc.text.fill", color: .gray, destination: TermsAndConditionsEditorView())

                    Button {
                        showPrivacyPolicy = true
                    } label: {
                        MoreRowLabel(title: "Privacy Policy", icon: "lock.shield.fill", color: .blue)
                    }

                    Button {
                        showWalkthrough = true
                    } label: {
                        MoreRowLabel(title: "How MotelR Works", icon: "sparkles", color: .purple)
                    }

                    Button {
                        showContactSupport = true
                    } label: {
                        MoreRowLabel(title: "Contact Support", icon: "envelope.fill", color: .teal)
                    }

                    Button {
                        showSettings = true
                    } label: {
                        MoreRowLabel(title: "Settings", icon: "gearshape.fill", color: .secondary)
                    }
                } header: {
                    MoreSectionHeader(title: "App")
                }

                // MARK: About card
                Section {
                    VStack(spacing: 0) {
                        ZStack {
                            LinearGradient(
                                colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
                                startPoint: .topLeading, endPoint: .bottomTrailing
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                            // Decorative circles
                            Circle().fill(Color.white.opacity(0.07)).frame(width: 130).offset(x: 90, y: -30)
                            Circle().fill(Color.white.opacity(0.05)).frame(width: 80).offset(x: -80, y: 20)

                            HStack(spacing: 16) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color.white.opacity(0.15))
                                        .frame(width: 52, height: 52)
                                    Image(systemName: "building.2.crop.circle.fill")
                                        .font(.system(size: 26, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("MotelR 2.0")
                                        .font(.system(size: 18, weight: .bold, design: .rounded))
                                        .foregroundColor(.white)
                                    Text("by New Journey")
                                        .font(.system(size: 13, weight: .medium, design: .rounded))
                                        .foregroundColor(.white.opacity(0.7))
                                    Text("Version \(appVersion)")
                                        .font(.system(size: 11))
                                        .foregroundColor(.white.opacity(0.5))
                                }
                                Spacer()
                            }
                            .padding(18)
                        }
                    }
                    .listRowInsets(EdgeInsets(top: 4, leading: 16, bottom: 4, trailing: 16))
                    .listRowBackground(Color.clear)
                } header: {
                    MoreSectionHeader(title: "About")
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("More")
            .navigationBarTitleDisplayMode(.large)
        }
        .sheet(isPresented: $showSettings)       { SettingsView().environmentObject(motelData) }
        .sheet(isPresented: $showPrivacyPolicy)  {
            if let url = URL(string: "https://nishant-co.github.io/MotelR/privacy.html") {
                SafariView(url: url)
            }
        }
        .sheet(isPresented: $showContactSupport) {
            if let url = URL(string: "https://nishant-co.github.io/MotelR/support.html") {
                SafariView(url: url)
            }
        }
        .fullScreenCover(isPresented: $showWalkthrough) {
            OnboardingView { showWalkthrough = false }
        }
    }
}

// MARK: - SettingsView

struct SettingsView: View {
    @EnvironmentObject private var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    // Business
    @State private var businessNameField: String = ""

    // Tax
    @State private var taxRateValue: Double = 0.0

    // Check-out time
    @State private var checkOutTime: Date = UserDefaults.standard.object(forKey: "checkOutTime") as? Date ?? defaultCheckOutTimeDate()
    @State private var showCheckOutTimePicker = false

    // PIN
    @State private var showSetPIN    = false
    @State private var showChangePIN = false
    @State private var showRemovePIN = false
    @State private var showPINRemoveConfirm = false

    // Backup
    @AppStorage("autoBackupEnabled") private var autoBackupEnabled = false
    @State private var autoBackupTime: Date = UserDefaults.standard.object(forKey: "autoBackupTime") as? Date ?? Date()
    @State private var isExporting          = false
    @State private var showingExportSheet   = false
    @State private var showingImportPicker  = false
    @State private var exportURL: URL?
    @State private var showExportPasswordPrompt = false
    @State private var showImportPasswordPrompt = false
    @State private var pendingImportURL: URL?
    @State private var showImportReplaceWarning = false

    // Reset
    @State private var showDeleteAlert  = false
    @State private var showPINForDelete = false

    // Alerts
    @State private var alertTitle   = ""
    @State private var alertMessage = ""
    @State private var showAlert    = false

    private var hasPIN: Bool { SecurityManager.shared.pinExists() }

    @ViewBuilder private var listSections: some View {
                // MARK: Business
                Section {
                    HStack(spacing: 12) {
                        settingsIcon(icon: "building.2.fill", color: Color(red: 0.18, green: 0.27, blue: 0.90))
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Business Name")
                                .font(.system(size: 13))
                                .foregroundColor(.secondary)
                            TextField("Business name", text: $businessNameField)
                                .font(.system(size: 15, weight: .medium, design: .rounded))
                                .onSubmit { motelData.businessName = businessNameField.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Motel R" : businessNameField }
                        }
                    }
                } header: {
                    MoreSectionHeader(title: "Business")
                }

                // MARK: Tax
                Section {
                    HStack(spacing: 12) {
                        settingsIcon(icon: "percent", color: .green)
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text("Tax Rate")
                                    .font(.system(size: 15, weight: .medium, design: .rounded))
                                Spacer()
                                Text(String(format: "%.1f%%", taxRateValue))
                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                            }
                            Slider(value: $taxRateValue, in: 0...20, step: 0.5)
                                .tint(Color(red: 0.18, green: 0.27, blue: 0.90))
                                .onChange(of: taxRateValue) { _, newValue in
                                    motelData.taxRate = newValue / 100
                                }
                        }
                    }
                    .padding(.vertical, 4)

                    HStack(spacing: 12) {
                        settingsIcon(icon: "clock.fill", color: .blue)
                        Text("Check-Out Time")
                            .font(.system(size: 15, weight: .medium, design: .rounded))
                        Spacer()
                        Button {
                            showCheckOutTimePicker = true
                        } label: {
                            Text(checkOutTimeFormatted)
                                .font(.system(size: 14, weight: .semibold, design: .rounded))
                                .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.10))
                                .clipShape(Capsule())
                        }
                    }
                } header: {
                    MoreSectionHeader(title: "Tax & Check-Out")
                }

                // MARK: PIN Security
                Section {
                    if hasPIN {
                        // Change PIN
                        Button {
                            showChangePIN = true
                        } label: {
                            HStack(spacing: 12) {
                                settingsIcon(icon: "lock.rotation", color: .orange)
                                Text("Change PIN")
                                    .font(.system(size: 15, weight: .medium, design: .rounded))
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundColor(.secondary)
                            }
                        }
                        // Remove PIN
                        Button {
                            showPINRemoveConfirm = true
                        } label: {
                            HStack(spacing: 12) {
                                settingsIcon(icon: "lock.open.fill", color: .red)
                                Text("Remove PIN")
                                    .font(.system(size: 15, weight: .medium, design: .rounded))
                                    .foregroundColor(.red)
                                Spacer()
                            }
                        }
                    } else {
                        // Set PIN
                        Button {
                            showSetPIN = true
                        } label: {
                            HStack(spacing: 12) {
                                settingsIcon(icon: "lock.fill", color: Color(red: 0.18, green: 0.27, blue: 0.90))
                                Text("Set PIN")
                                    .font(.system(size: 15, weight: .medium, design: .rounded))
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundColor(.secondary)
                            }
                        }
                    }
                } header: {
                    MoreSectionHeader(title: "Security")
                }

                // MARK: Backup & Restore
                Section {
                    // Manual backup
                    Button { backupData() } label: {
                        HStack(spacing: 12) {
                            settingsIcon(icon: "arrow.clockwise.icloud.fill", color: .blue)
                            Text("Backup Now")
                                .font(.system(size: 15, weight: .medium, design: .rounded))
                                .foregroundColor(.primary)
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundColor(.secondary)
                        }
                    }

                    // Export
                    Button { showExportPasswordPrompt = true } label: {
                        HStack(spacing: 12) {
                            settingsIcon(icon: "square.and.arrow.up.fill", color: .green)
                            if isExporting {
                                Text("Exporting…")
                                    .font(.system(size: 15, weight: .medium, design: .rounded))
                                    .foregroundColor(.secondary)
                                Spacer()
                                ProgressView().scaleEffect(0.8)
                            } else {
                                Text("Export Backup")
                                    .font(.system(size: 15, weight: .medium, design: .rounded))
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundColor(.secondary)
                            }
                        }
                    }
                    .disabled(isExporting)

                    // Import
                    Button { showingImportPicker = true } label: {
                        HStack(spacing: 12) {
                            settingsIcon(icon: "square.and.arrow.down.fill", color: .orange)
                            Text("Import Backup")
                                .font(.system(size: 15, weight: .medium, design: .rounded))
                                .foregroundColor(.primary)
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundColor(.secondary)
                        }
                    }

                    // Auto backup toggle
                    HStack(spacing: 12) {
                        settingsIcon(icon: "icloud.fill", color: .indigo)
                        Toggle(isOn: $autoBackupEnabled) {
                            Text("Auto Backup")
                                .font(.system(size: 15, weight: .medium, design: .rounded))
                        }
                        .onChange(of: autoBackupEnabled) { _, newValue in
                            if newValue {
                                // Backups report their result via a notification, so ask here.
                                NotificationPermission.requestIfNeeded()
                                BackupScheduler.shared.scheduleBackup()
                            } else {
                                BackupScheduler.shared.cancelBackup()
                            }
                        }
                    }

                    if autoBackupEnabled {
                        HStack(spacing: 12) {
                            settingsIcon(icon: "clock.badge.checkmark.fill", color: .teal)
                            DatePicker("Backup Time", selection: $autoBackupTime, displayedComponents: .hourAndMinute)
                                .font(.system(size: 15, weight: .medium, design: .rounded))
                                .onChange(of: autoBackupTime) { _, newValue in
                                    UserDefaults.standard.set(newValue, forKey: "autoBackupTime")
                                    if autoBackupEnabled { BackupScheduler.shared.scheduleBackup() }
                                }
                        }
                        Text("Data will be backed up daily at the selected time.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                } header: {
                    MoreSectionHeader(title: "Backup & Restore")
                }

                // MARK: Danger Zone
                Section {
                    Button {
                        showDeleteAlert = true
                    } label: {
                        HStack(spacing: 12) {
                            settingsIcon(icon: "trash.fill", color: .red)
                            Text("Reset All Data")
                                .font(.system(size: 15, weight: .semibold, design: .rounded))
                                .foregroundColor(.red)
                            Spacer()
                        }
                    }
                } header: {
                    MoreSectionHeader(title: "Danger Zone")
                }

                // MARK: Footer
                Section {
                    HStack {
                        Spacer()
                        VStack(spacing: 4) {
                            Text("MotelR 2.0")
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundColor(.secondary)
                            Text("by New Journey")
                                .font(.system(size: 11))
                                .foregroundColor(.secondary.opacity(0.6))
                        }
                        Spacer()
                    }
                    .listRowBackground(Color.clear)
                }
    }

    var body: some View {
        NavigationStack {
            List { listSections }
            .listStyle(.insetGrouped)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        // Commit business name on Done
                        let trimmed = businessNameField.trimmingCharacters(in: .whitespacesAndNewlines)
                        motelData.businessName = trimmed.isEmpty ? "Motel R" : trimmed
                        dismiss()
                    }
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                }
            }
        }
        .onAppear {
            businessNameField = motelData.businessName
            taxRateValue      = motelData.taxRate * 100
            if let saved = UserDefaults.standard.object(forKey: "autoBackupTime") as? Date {
                autoBackupTime = saved
            }
        }
        // Sheets
        .sheet(isPresented: $showCheckOutTimePicker) { CheckOutTimePickerView().environmentObject(motelData) }
        .sheet(isPresented: $showingExportSheet) {
            if let url = exportURL { SharedActivityView(activityItems: [url]) }
        }
        .sheet(isPresented: $showingImportPicker) {
            BackupDocumentPicker { result in
                switch result {
                case .success(let url):
                    pendingImportURL = url
                    // Warn before replacing anything, once the picker has finished dismissing.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        showImportReplaceWarning = true
                    }
                case .failure(let err):
                    alertTitle   = "Import Failed"
                    alertMessage = err.localizedDescription
                    showAlert    = true
                }
            }
        }
        .sheet(isPresented: $showExportPasswordPrompt) {
            BackupPasswordPrompt(mode: .export, isPresented: $showExportPasswordPrompt) { password in
                exportBackup(password: password)
            }
        }
        .sheet(isPresented: $showImportPasswordPrompt) {
            BackupPasswordPrompt(mode: .restore, isPresented: $showImportPasswordPrompt) { password in
                guard let url = pendingImportURL else { return }
                importBackup(from: url, password: password)
            }
        }
        // PIN overlays
        .overlay {
            if showSetPIN {
                SetPINView(isPresented: $showSetPIN) { pin in
                    do {
                        try SecurityManager.shared.setPin(pin)
                        alertTitle   = "PIN Set"
                        alertMessage = "Your PIN has been set successfully."
                        showAlert    = true
                    } catch {
                        alertTitle   = "Error"
                        alertMessage = "Could not set PIN: \(error.localizedDescription)"
                        showAlert    = true
                    }
                }
            }
            if showChangePIN {
                ChangePINView(isPresented: $showChangePIN) { newPIN in
                    do {
                        try SecurityManager.shared.setPin(newPIN)
                        alertTitle   = "PIN Updated"
                        alertMessage = "Your PIN has been changed."
                        showAlert    = true
                    } catch {
                        alertTitle   = "Error"
                        alertMessage = "Could not update PIN: \(error.localizedDescription)"
                        showAlert    = true
                    }
                }
            }
        }
        .confirmationDialog("Remove PIN", isPresented: $showRemovePIN, titleVisibility: .visible) {
            Button("Remove PIN", role: .destructive) { removePIN() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Your PIN will be removed.") }
        .confirmationDialog("Reset All Data", isPresented: $showPINForDelete, titleVisibility: .visible) {
            Button("Delete Everything", role: .destructive) { deleteAllData() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("This cannot be undone.") }
        // Alerts
        .alert("Replace All Data?", isPresented: $showImportReplaceWarning) {
            Button("Replace Everything", role: .destructive) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    showImportPasswordPrompt = true
                }
            }
            Button("Cancel", role: .cancel) { pendingImportURL = nil }
        } message: {
            Text(RestoreWarning.message)
        }
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
        .alert("Reset All Data", isPresented: $showDeleteAlert) {
            Button("Reset", role: .destructive) {
                if SecurityManager.shared.pinExists() {
                    showPINForDelete = true
                } else {
                    deleteAllData()
                }
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("This will permanently delete all rooms, bookings, history, and incidents — on this device and on every other iPhone or iPad signed in to the same iCloud account. We strongly recommend exporting a backup first.")
        }
        .confirmationDialog("Remove PIN", isPresented: $showPINRemoveConfirm, titleVisibility: .visible) {
            Button("Remove PIN", role: .destructive) {
                if SecurityManager.shared.pinExists() {
                    showRemovePIN = true
                } else {
                    removePIN()
                }
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("Your PIN will be removed and the app will no longer require authentication.")
        }
    }

    // MARK: Settings Helpers

    private func settingsIcon(icon: String, color: Color) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7)
                .fill(color.opacity(0.15))
                .frame(width: 30, height: 30)
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(color)
        }
    }

    private var checkOutTimeFormatted: String {
        let f = DateFormatter(); f.timeStyle = .short
        return f.string(from: checkOutTime)
    }

    private func backupData() {
        do {
            try BackupManager.shared.createBackup(motelData: motelData)
            alertTitle   = "Backup Successful"
            alertMessage = "Your data has been backed up successfully."
            showAlert    = true
        } catch {
            alertTitle   = "Backup Failed"
            alertMessage = error.localizedDescription
            showAlert    = true
        }
    }

    private func exportBackup(password: String) {
        isExporting = true
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let url = try BackupUtils.shared.exportBackup(password: password)
                DispatchQueue.main.async {
                    isExporting    = false
                    exportURL      = url
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        showingExportSheet = true
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    isExporting  = false
                    alertTitle   = "Export Failed"
                    alertMessage = error.localizedDescription
                    showAlert    = true
                }
            }
        }
    }

    private func importBackup(from url: URL, password: String) {
        isExporting = true
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try BackupUtils.shared.importBackup(from: url, password: password)
                // Actually put the backup's data in place. Before, the import only
                // replaced the backup file and sent the owner back to the setup screen,
                // where tapping "Start Fresh" left their data unrestored.
                _ = try CoreDataManager.shared.performAndWait { _ in
                    try BackupManager.shared.restoreFromBackup()
                }
                DispatchQueue.main.async {
                    isExporting  = false
                    motelData.fetchAllData()
                    motelData.businessName = UserDefaults.standard.string(forKey: "businessName") ?? "Motel R"
                    motelData.taxRate      = UserDefaults.standard.double(forKey: "taxRate")
                    businessNameField = motelData.businessName
                    taxRateValue      = motelData.taxRate
                    alertTitle   = "Import Successful"
                    alertMessage = "Your backup has been restored."
                    showAlert    = true
                }
            } catch {
                DispatchQueue.main.async {
                    isExporting  = false
                    alertTitle   = "Import Failed"
                    alertMessage = error.localizedDescription
                    showAlert    = true
                }
            }
        }
    }

    private func removePIN() {
        do {
            try SecurityManager.shared.resetPin()
            alertTitle   = "PIN Removed"
            alertMessage = "Your PIN has been removed successfully."
            showAlert    = true
        } catch {
            alertTitle   = "Error"
            alertMessage = "Could not remove PIN: \(error.localizedDescription)"
            showAlert    = true
        }
    }

    private func deleteAllData() {
        motelData.deleteAllData()
        UserDefaults.standard.set(false, forKey: "hasCompletedSetup")
        UserDefaults.standard.synchronize()
        NotificationCenter.default.post(name: NSNotification.Name("RestartApp"), object: nil)
        dismiss()
    }
}

// MARK: - Set PIN View

private struct SetPINView: View {
    @Binding var isPresented: Bool
    let onSet: (String) -> Void

    @State private var pin        = ""
    @State private var confirmPIN = ""
    @State private var step: Int  = 1
    @State private var shakeAttempts: CGFloat = 0
    @State private var cardScale: CGFloat  = 0.85
    @State private var cardOpacity: Double = 0

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea().opacity(cardOpacity)
            Color.black.opacity(cardOpacity * 0.38).ignoresSafeArea().allowsHitTesting(false)

            VStack(spacing: 22) {
                // Icon
                ZStack {
                    Circle().fill(Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.14)).frame(width: 80, height: 80)
                    Image(systemName: "lock.fill")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                }
                Text(step == 1 ? "Set PIN" : "Confirm PIN")
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                Text(step == 1 ? "Enter a 6-digit PIN to secure your app" : "Re-enter your PIN to confirm")
                    .font(.system(size: 13))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)

                // Dots
                HStack(spacing: 14) {
                    ForEach(0..<6, id: \.self) { i in
                        let filled = i < (step == 1 ? pin.count : confirmPIN.count)
                        ZStack {
                            Circle()
                                .stroke(filled ? Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.7) : Color.gray.opacity(0.3), lineWidth: 1.5)
                                .frame(width: 18, height: 18)
                            if filled {
                                Circle()
                                    .fill(Color(red: 0.18, green: 0.27, blue: 0.90))
                                    .frame(width: 12, height: 12)
                                    .transition(.scale.combined(with: .opacity))
                            }
                        }
                        .animation(.spring(response: 0.28, dampingFraction: 0.56), value: filled)
                    }
                }

                // Keypad
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
                    ForEach(1...9, id: \.self) { n in
                        Button { addDigit("\(n)") } label: {
                            Text("\(n)")
                                .font(.system(size: 24, weight: .light, design: .rounded))
                                .frame(width: 64, height: 64)
                        }
                        .buttonStyle(AppLockButtonStyle(isSpecial: false))
                    }
                    Button { clearEntry() } label: {
                        Text("AC").font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundColor(.red).frame(width: 64, height: 64)
                    }.buttonStyle(AppLockButtonStyle(isSpecial: true))

                    Button { addDigit("0") } label: {
                        Text("0").font(.system(size: 24, weight: .light, design: .rounded)).frame(width: 64, height: 64)
                    }.buttonStyle(AppLockButtonStyle(isSpecial: false))

                    Button { deleteDigit() } label: {
                        Image(systemName: "delete.left.fill").font(.system(size: 18, weight: .medium))
                            .foregroundColor(.red).frame(width: 64, height: 64)
                    }.buttonStyle(AppLockButtonStyle(isSpecial: true))
                }

                Button("Cancel") { dismiss() }
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.secondary)
            }
            .padding(28)
            .background(
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.35), radius: 48, x: 0, y: 22)
            )
            .padding(.horizontal, 26)
            .scaleEffect(cardScale)
            .opacity(cardOpacity)
            .modifier(ShakeEffect(animatableData: shakeAttempts))
        }
        .onAppear {
            withAnimation(.spring(response: 0.48, dampingFraction: 0.72)) {
                cardScale = 1.0; cardOpacity = 1.0
            }
        }
    }

    private func addDigit(_ d: String) {
        if step == 1 {
            guard pin.count < 6 else { return }
            withAnimation(.spring(response: 0.26, dampingFraction: 0.55)) { pin += d }
            if pin.count == 6 { DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { step = 2 } }
        } else {
            guard confirmPIN.count < 6 else { return }
            withAnimation(.spring(response: 0.26, dampingFraction: 0.55)) { confirmPIN += d }
            if confirmPIN.count == 6 { DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { validate() } }
        }
    }

    private func deleteDigit() {
        if step == 1 { if !pin.isEmpty { _ = withAnimation { pin.removeLast() } } }
        else         { if !confirmPIN.isEmpty { _ = withAnimation { confirmPIN.removeLast() } } }
    }

    private func clearEntry() {
        if step == 1 { withAnimation { pin = "" } }
        else         { withAnimation { confirmPIN = "" } }
    }

    private func validate() {
        if pin == confirmPIN {
            dismiss()
            onSet(pin)
        } else {
            withAnimation(.linear(duration: 0.38)) { shakeAttempts += 1 }
            withAnimation(.spring(response: 0.28, dampingFraction: 0.56)) { confirmPIN = "" }
        }
    }

    private func dismiss() {
        withAnimation(.spring(response: 0.36, dampingFraction: 0.78)) {
            cardScale = 0.86; cardOpacity = 0
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.32) { isPresented = false }
    }
}

// MARK: - Change PIN View

private struct ChangePINView: View {
    @Binding var isPresented: Bool
    let onChanged: (String) -> Void

    @State private var step: Int  = 0   // 0=verify current, 1=new, 2=confirm new
    @State private var currentPIN = ""
    @State private var newPIN     = ""
    @State private var confirmPIN = ""
    @State private var errorMsg   = ""
    @State private var shakeAttempts: CGFloat = 0
    @State private var cardScale: CGFloat  = 0.85
    @State private var cardOpacity: Double = 0

    private var activeEntry: String {
        switch step {
        case 0: return currentPIN
        case 1: return newPIN
        default: return confirmPIN
        }
    }
    private var titleText: String {
        switch step {
        case 0: return "Enter Current PIN"
        case 1: return "Enter New PIN"
        default: return "Confirm New PIN"
        }
    }

    var body: some View {
        ZStack {
            Rectangle().fill(.ultraThinMaterial).ignoresSafeArea().opacity(cardOpacity)
            Color.black.opacity(cardOpacity * 0.38).ignoresSafeArea().allowsHitTesting(false)

            VStack(spacing: 22) {
                ZStack {
                    Circle().fill(Color.orange.opacity(0.14)).frame(width: 80, height: 80)
                    Image(systemName: "lock.rotation")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundColor(.orange)
                }
                Text(titleText)
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                if !errorMsg.isEmpty {
                    Text(errorMsg)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }

                // Dots
                HStack(spacing: 14) {
                    ForEach(0..<6, id: \.self) { i in
                        let filled = i < activeEntry.count
                        ZStack {
                            Circle()
                                .stroke(filled ? Color.orange.opacity(0.7) : Color.gray.opacity(0.3), lineWidth: 1.5)
                                .frame(width: 18, height: 18)
                            if filled {
                                Circle().fill(Color.orange).frame(width: 12, height: 12)
                                    .transition(.scale.combined(with: .opacity))
                            }
                        }
                        .animation(.spring(response: 0.28, dampingFraction: 0.56), value: filled)
                    }
                }

                // Keypad
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
                    ForEach(1...9, id: \.self) { n in
                        Button { addDigit("\(n)") } label: {
                            Text("\(n)").font(.system(size: 24, weight: .light, design: .rounded)).frame(width: 64, height: 64)
                        }.buttonStyle(AppLockButtonStyle(isSpecial: false))
                    }
                    Button { clearEntry() } label: {
                        Text("AC").font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundColor(.red).frame(width: 64, height: 64)
                    }.buttonStyle(AppLockButtonStyle(isSpecial: true))

                    Button { addDigit("0") } label: {
                        Text("0").font(.system(size: 24, weight: .light, design: .rounded)).frame(width: 64, height: 64)
                    }.buttonStyle(AppLockButtonStyle(isSpecial: false))

                    Button { deleteDigit() } label: {
                        Image(systemName: "delete.left.fill").font(.system(size: 18, weight: .medium))
                            .foregroundColor(.red).frame(width: 64, height: 64)
                    }.buttonStyle(AppLockButtonStyle(isSpecial: true))
                }

                Button("Cancel") { dismissView() }
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.secondary)
            }
            .padding(28)
            .background(
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(.regularMaterial)
                    .shadow(color: .black.opacity(0.35), radius: 48, x: 0, y: 22)
            )
            .padding(.horizontal, 26)
            .scaleEffect(cardScale)
            .opacity(cardOpacity)
            .modifier(ShakeEffect(animatableData: shakeAttempts))
        }
        .onAppear {
            withAnimation(.spring(response: 0.48, dampingFraction: 0.72)) {
                cardScale = 1.0; cardOpacity = 1.0
            }
        }
    }

    private func addDigit(_ d: String) {
        withAnimation(.spring(response: 0.26, dampingFraction: 0.55)) {
            switch step {
            case 0:
                guard currentPIN.count < 6 else { return }
                currentPIN += d
                if currentPIN.count == 6 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { verifyCurrentPIN() }
                }
            case 1:
                guard newPIN.count < 6 else { return }
                newPIN += d
                if newPIN.count == 6 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { step = 2 }
                }
            default:
                guard confirmPIN.count < 6 else { return }
                confirmPIN += d
                if confirmPIN.count == 6 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { confirmNewPIN() }
                }
            }
        }
    }

    private func deleteDigit() {
        withAnimation {
            switch step {
            case 0: if !currentPIN.isEmpty { currentPIN.removeLast() }
            case 1: if !newPIN.isEmpty     { newPIN.removeLast()     }
            default: if !confirmPIN.isEmpty { confirmPIN.removeLast() }
            }
        }
    }

    private func clearEntry() {
        withAnimation {
            switch step {
            case 0: currentPIN = ""
            case 1: newPIN = ""
            default: confirmPIN = ""
            }
        }
    }

    private func verifyCurrentPIN() {
        // Same lockout as the lock screen, so Change PIN can't be used to guess the PIN.
        guard !SecurityManager.shared.isLockedOut() else {
            let secs = SecurityManager.shared.lockoutSecondsRemaining()
            withAnimation {
                currentPIN = ""
                errorMsg = "Too many failed attempts. Try again in \(secs / 60):\(String(format: "%02d", secs % 60))."
            }
            return
        }
        let entered = currentPIN
        SecurityManager.shared.verifyPinAsync(entered) { isCorrect in
            if isCorrect {
                SecurityManager.shared.resetFailedAttempts()
                withAnimation { step = 1; errorMsg = "" }
            } else {
                SecurityManager.shared.recordFailedAttempt()
                withAnimation(.linear(duration: 0.38)) { shakeAttempts += 1 }
                withAnimation(.spring(response: 0.28, dampingFraction: 0.56)) {
                    currentPIN = ""
                    errorMsg = "Incorrect PIN. Please try again."
                }
            }
        }
    }

    private func confirmNewPIN() {
        if newPIN == confirmPIN {
            dismissView()
            onChanged(newPIN)
        } else {
            withAnimation(.linear(duration: 0.38)) { shakeAttempts += 1 }
            withAnimation(.spring(response: 0.28, dampingFraction: 0.56)) {
                confirmPIN = ""
                errorMsg = "PINs do not match. Try again."
            }
        }
    }

    private func dismissView() {
        withAnimation(.spring(response: 0.36, dampingFraction: 0.78)) {
            cardScale = 0.86; cardOpacity = 0
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.32) { isPresented = false }
    }
}

// MARK: - SafariView

struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        let vc = SFSafariViewController(url: url)
        vc.preferredBarTintColor = UIColor(Color(red: 0.05, green: 0.12, blue: 0.65))
        vc.preferredControlTintColor = .white
        return vc
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}

// MARK: - Dashboard Helper Views

private struct DashStatTile: View {
    let value: String
    let label: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
                .minimumScaleFactor(0.55)
                .lineLimit(1)
            Text(label)
                .font(.system(size: 9, weight: .medium))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }
}

private struct DashActionButton: View {
    let title: String
    let subtitle: String
    let icon: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11)
                        .fill(color.opacity(0.13))
                        .frame(width: 44, height: 44)
                    Image(systemName: icon)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(color)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundColor(.primary)
                    Text(subtitle)
                        .font(.system(size: 11))
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color(UIColor.systemBackground))
                    .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
            )
        }
        .buttonStyle(DashScaleButton())
    }
}

private struct ActivityRow: View {
    let booking: CDBooking

    private var isCheckIn: Bool {
        Calendar.current.isDateInToday(booking.checkInDate)
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(badgeColor.opacity(0.14))
                    .frame(width: 40, height: 40)
                Image(systemName: isCheckIn ? "arrow.right.circle.fill" : "arrow.left.circle.fill")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(badgeColor)
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(booking.customerName)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .lineLimit(1)
                Text(booking.room.name.isEmpty ? "Room \(booking.room.number)" : booking.room.name)
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text(isCheckIn ? "Check In" : "Check Out")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(badgeColor)
                    .clipShape(Capsule())
                Text(timeString(for: isCheckIn ? booking.checkInDate : booking.checkOutDate))
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }

    private var badgeColor: Color {
        isCheckIn ? .green : .red
    }

    private func timeString(for date: Date) -> String {
        let f = DateFormatter(); f.timeStyle = .short
        return f.string(from: date)
    }
}

private struct DashScaleButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.96 : 1.0)
            .animation(.spring(response: 0.22, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

// MARK: - More Tab Helper Views

private struct MoreNavRow<D: View>: View {
    let title: String
    let icon: String
    let color: Color
    let destination: D

    var body: some View {
        NavigationLink(destination: destination) {
            MoreRowLabel(title: title, icon: icon, color: color)
        }
    }
}

private struct MoreRowLabel: View {
    let title: String
    let icon: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 7)
                    .fill(color.opacity(0.15))
                    .frame(width: 30, height: 30)
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(color)
            }
            Text(title)
                .font(.system(size: 15, weight: .medium, design: .rounded))
                .foregroundColor(.primary)
        }
    }
}

private struct MoreSectionHeader: View {
    let title: String
    var body: some View {
        Text(title)
            .font(.system(size: 12, weight: .semibold))
            .foregroundColor(.secondary)
            .textCase(nil)
    }
}

// MARK: - Supporting Views (re-exported for backward compatibility)

struct CheckOutTimePickerView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss
    @State private var checkOutTime: Date = UserDefaults.standard.object(forKey: "checkOutTime") as? Date ?? defaultCheckOutTimeDate()
    @State private var saved = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 28) {
                ZStack {
                    Circle()
                        .fill(Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.12))
                        .frame(width: 80, height: 80)
                    Image(systemName: "clock.fill")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                }
                .padding(.top, 16)

                Text("Set Check-Out Time")
                    .font(.system(size: 22, weight: .bold, design: .rounded))

                DatePicker("", selection: $checkOutTime, displayedComponents: .hourAndMinute)
                    .datePickerStyle(.wheel)
                    .labelsHidden()
                    .frame(maxWidth: .infinity)

                if saved {
                    Label("Check-out time saved", systemImage: "checkmark.circle.fill")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.green)
                        .transition(.opacity.combined(with: .move(edge: .bottom)))
                }

                Button {
                    SettingsSync.shared.set(checkOutTime, forKey: "checkOutTime")
                    // Move every pending reminder to the new time.
                    rescheduleCheckoutReminders(for: motelData.bookings)
                    withAnimation { saved = true }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { dismiss() }
                } label: {
                    Text("Save")
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(
                            LinearGradient(
                                colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
                                startPoint: .leading, endPoint: .trailing
                            )
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                }
                .padding(.horizontal, 20)

                Spacer()
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.foregroundColor(.secondary)
                }
            }
        }
    }
}

// (Unused screens — the old side drawer, today's check-outs sheet and quick-access
//  tiles — were removed in the 2.0 clean-up; nothing in the app showed them.)

// MARK: - Preview

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
            .environmentObject(MotelData())
    }
}

// MARK: - iPad Layout

/// Caps content width and centres it. Without this an iPhone-sized layout is
/// stretched across the full width of an iPad, leaving huge empty rows.
struct ReadableWidth: ViewModifier {
    var maxWidth: CGFloat

    func body(content: Content) -> some View {
        content
            .frame(maxWidth: maxWidth)
            .frame(maxWidth: .infinity)
    }
}

extension View {
    /// Constrains a screen's content to a comfortable reading width on iPad.
    func readableWidth(_ maxWidth: CGFloat = 760) -> some View {
        modifier(ReadableWidth(maxWidth: maxWidth))
    }
}

// MARK: - Backup Password Prompt

/// Collects the password that protects an exported backup file.
///
/// Exports are encrypted with a key derived from this password and nothing else, so
/// there is no recovery path — the copy shown when creating one is deliberate.
struct BackupPasswordPrompt: View {
    enum Mode {
        case export
        case restore

        var title: String {
            switch self {
            case .export:  return "Protect This Backup"
            case .restore: return "Enter Backup Password"
            }
        }

        var explanation: String {
            switch self {
            case .export:
                return "Your backup contains guest details and licence photos. Choose a password to encrypt it.\n\nWrite it down — without it the backup cannot be opened, and it cannot be reset."
            case .restore:
                return "Enter the password that was set when this backup file was exported."
            }
        }

        var actionTitle: String {
            switch self {
            case .export:  return "Export Backup"
            case .restore: return "Restore"
            }
        }
    }

    let mode: Mode
    @Binding var isPresented: Bool
    let onSubmit: (String) -> Void

    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var errorMessage: String?
    @FocusState private var focused: Bool

    private var isValid: Bool {
        guard password.count >= 6 else { return false }
        return mode == .restore || password == confirmPassword
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text(mode.explanation)
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(.secondary)
                }

                Section {
                    SecureField("Password", text: $password)
                        .textContentType(.password)
                        .focused($focused)
                    if mode == .export {
                        SecureField("Confirm password", text: $confirmPassword)
                            .textContentType(.password)
                    }
                } footer: {
                    if let errorMessage {
                        Text(errorMessage).foregroundStyle(.red)
                    } else if password.isEmpty {
                        Text("At least 6 characters.")
                    } else if password.count < 6 {
                        Text("Too short — use at least 6 characters.").foregroundStyle(.red)
                    } else if mode == .export && !confirmPassword.isEmpty && password != confirmPassword {
                        Text("Passwords do not match.").foregroundStyle(.red)
                    }
                }

                Section {
                    Button(mode.actionTitle) {
                        isPresented = false
                        onSubmit(password)
                    }
                    .disabled(!isValid)
                }
            }
            .navigationTitle(mode.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { isPresented = false }
                }
            }
            .onAppear { focused = true }
        }
    }
}
