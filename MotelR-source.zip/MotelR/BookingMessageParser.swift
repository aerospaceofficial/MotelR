//
//  BookingMessageParser.swift
//  MotelR 2.0 — by New Journey
//
//  Reads one message from the manager with plain rules — no AI. It understands
//  the answers people actually give at a front desk, spoken or typed:
//
//    "2" / "two nights" / "a week" / "just tonight"
//    "room 12" / "the 12" / "rm #7"
//    "89" / "$89.50" / "eighty-nine dollars" / "89 plus tax" / "total is 240"
//    "cash" / "visa" / "paying by check" / "check number 1042" / "acme, bill them later"
//    "tomorrow" / "friday" / "nov 15" / "11/15"
//    "555 123 4567" / "(217) 859-1242"
//    "yes" / "looks good" / "no, someone else" / "start over" / "scan" / "which rooms are free"
//
//  Number words are turned into digits first ("eighty-nine" → 89), because that's
//  how speech recognition often writes them.
//
//  Care is taken with words that mean two things: "check in Jane" is not a check
//  payment, and "George Card" is a name, not a card payment.
//
//  The booking assistant also uses this to double-check what the AI model read:
//  a value is only accepted if it really appears in the manager's words.
//

#if canImport(FoundationModels)
import Foundation

struct BookingMessageParser {
    let raw: String
    /// Lower-cased, hyphens between words split, number words turned into digits.
    let normalized: String

    // Details found
    private(set) var nights: Int?
    private(set) var room: Int?
    private(set) var rate: Double?
    private(set) var total: Double?
    private(set) var plusTax = false
    private(set) var noTax = false
    private(set) var payment: PaymentMethod?
    private(set) var cardType: String?
    private(set) var checkNumber: String?
    private(set) var phone: String?
    private(set) var checkIn: Date?
    /// Departure day, from "checking out Sunday", "until Nov 15", "leaving tomorrow".
    private(set) var departure: Date?
    private(set) var license: String?
    private(set) var billLater = false
    private(set) var paidNow = false
    /// A plain name answer to "Who's checking in?".
    private(set) var bareName: String?
    /// A short answer like "Acme Corp" (used for "Which company is paying?").
    private(set) var shortAnswer: String?
    /// The company in an organization booking said in passing: "…, acme corp, bill later".
    private(set) var organizationName: String?
    /// Parts of a home address, read when the address was asked for.
    private(set) var addressStreet: String?
    private(set) var addressCity: String?
    private(set) var addressState: String?
    private(set) var addressZip: String?

    // What the manager wants
    /// Starts like a question or ends with "?".
    private(set) var isQuestion = false
    /// The name was clearly meant as a guest's name (capitalised or introduced).
    private(set) var nameIsIntentional = false
    private(set) var isYes = false
    private(set) var isNo = false
    private(set) var wantsStartOver = false
    private(set) var wantsScan = false
    private(set) var wantsFreeRooms = false

    var hasAnyDetail: Bool {
        nights != nil || room != nil || rate != nil || total != nil || payment != nil ||
        phone != nil || checkIn != nil || departure != nil || cardType != nil || checkNumber != nil || license != nil ||
        addressStreet != nil || addressCity != nil || addressZip != nil
    }

    // MARK: Reading

    init(text: String, pending: AssistantField?, today: Date = Date()) {
        raw = text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "\u{2019}", with: "'")
        normalized = Self.normalize(raw)
        let t = normalized
        let cal = Calendar.current
        let todayStart = cal.startOfDay(for: today)

        // Phone first, so its digits aren't mistaken for prices or rooms.
        var rest = t
        if let m = Self.match(#"(?<!\d)(?:\+?1[\s.-]?)?\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})(?!\d)"#, in: t) {
            phone = m.groups[1] + m.groups[2] + m.groups[3]
            rest = (t as NSString).replacingCharacters(in: m.range, with: " ")
        }

        // Dates. "checking out Sunday" / "until the 15th" is the departure day, not check-in.
        if let m = Self.match(#"\b(?:check(?:s|ing)?\s*out|leaving|leaves|until|till|through|departing)\s+(?:on\s+)?"#, in: rest) {
            let before = (rest as NSString).substring(to: m.range.location)
            let after = (rest as NSString).substring(from: m.range.location + m.range.length)
            departure = Self.findDate(in: after, today: todayStart)
            checkIn = Self.findDate(in: before, today: todayStart)
        } else {
            checkIn = Self.findDate(in: rest, today: todayStart)
        }

        // Nights
        if let m = Self.match(#"\b(\d{1,3})\s*(?:nights?|nites?|days?)\b"#, in: rest) { nights = Int(m.groups[1]) }
        if let m = Self.match(#"\b(\d{1,2})\s*weeks?\b"#, in: rest), let w = Int(m.groups[1]) {
            nights = w * 7
        } else if Self.has(#"\ba week\b"#, rest) {
            nights = 7
        }
        if nights == nil && Self.has(#"\b(just|only) tonight\b|\btonight only\b"#, rest) { nights = 1 }

        // Room and check number
        if let m = Self.match(#"\b(?:room|rm|unit)\s*(?:number|no\.?)?\s*#?\s*(\d{1,4})\b"#, in: rest) { room = Int(m.groups[1]) }
        if let m = Self.match(#"\b(?:check|cheque)\s*(?:number|no\.?|num)?\s*#?\s*(\d{2,8})\b"#, in: rest) {
            checkNumber = m.groups[1]
        } else if room == nil, let m = Self.match(#"#\s*(\d{1,4})\b"#, in: rest) {
            room = Int(m.groups[1])
        }

        // Money
        let num = #"(\d+(?:\.\d{1,2})?)"#
        if let m = Self.match(#"\btotal\s*(?:is|of|comes to|=)?\s*\$?\s*"# + num, in: rest)
            ?? Self.match(#"\$?\s*"# + num + #"\s*(?:dollars?\s*)?(?:in\s+)?total\b"#, in: rest) {
            total = Double(m.groups[1])
        }
        let ratePatterns = [
            #"\$\s*"# + num,
            num + #"\s*(?:dollars?|bucks)\b"#,
            num + #"\s*(?:\+|plus)\s*tax\b"#,
            num + #"\s*(?:a|per|each|/)\s*night"#,
            #"\b(?:rate|price)\s*(?:is|of|at)?\s*\$?\s*"# + num
        ]
        for pattern in ratePatterns {
            if let m = Self.match(pattern, in: rest), let value = Double(m.groups[1]) {
                if value != total { rate = value }
                break
            }
        }
        plusTax = Self.has(#"\bplus tax\b|\+\s*tax\b|\bbefore tax\b"#, rest)
        noTax = Self.has(#"\bno tax\b|\btax\s*(free|exempt)\b|\bwithout tax\b"#, rest)

        // A name said with capitals ("George Card") is a name, not a payment.
        let rawTokens = raw.split(separator: " ")
        let looksLikeName = pending == .name && (2...4).contains(rawTokens.count)
            && rawTokens.allSatisfy { $0.first?.isUppercase ?? false }
            && !raw.contains(where: \.isNumber)
        // Questions are never names ("how's business looking this week").
        isQuestion = Self.has(#"^(who|whos|who's|what|whats|what's|which|how|hows|how's|when|where|why|is|are|any|anyone|anybody|do|does|did|can|could|should|will|would|tell|show|list|give|has|have)\b"#, t)
            || raw.hasSuffix("?")
        // A name the manager clearly meant as one: capitalised, or introduced ("book Tom Lee").
        nameIsIntentional = looksLikeName
            || Self.has(#"^(book|booking|reserve|check(ing)? in|walk ?in|new guest|guest( name)? is|guest|name is|the name is|it'?s|this is)\b"#, t)

        // Payment
        if !looksLikeName { payment = Self.payment(in: rest) }
        let brands: [(String, String)] = [("Visa", #"\bvisa\b"#), ("Mastercard", #"\bmaster\s*card\b"#),
                                          ("Amex", #"\b(amex|american express)\b"#), ("Discover", #"\bdiscover\b"#)]
        if !looksLikeName {
            for (brand, pattern) in brands where Self.has(pattern, rest) { cardType = brand }
        }
        billLater = Self.has(#"\bbill (them |it )?later\b|\binvoice (them|it|later)\b|\bpay later\b"#, rest)
        paidNow = Self.has(#"\b(paid|paying|pays) (now|today|upfront|already)\b|\balready paid\b"#, rest)

        // Bare answers to the question that was asked ("2", "the 12", "89").
        if let m = Self.match(#"^(?:for |the |number |it'?s |its |make it |change (?:it )?to )?\$?\s*(\d+(?:\.\d{1,2})?)\s*(?:dollars?|bucks|nights?)?[.!]?$"#, in: t) {
            let value = m.groups[1]
            let whole = !value.contains(".")
            switch pending {
            case .some(.nights) where nights == nil && whole:           nights = Int(value)
            case .some(.room) where room == nil && whole:               room = Int(value)
            case .some(.rate) where rate == nil && total == nil:        rate = Double(value)
            case .some(.checkNumber) where checkNumber == nil && whole: checkNumber = value
            default: break
            }
        }
        if pending == .license {
            let stripped = Self.replace(#"^(?:(?:it'?s|its|license|licence|number|is|the)\s*)+"#, in: t, with: "")
            let tokens = Self.replace(#"[^a-z0-9 ]"#, in: stripped, with: "").split(separator: " ").map(String.init)
            let joined = tokens.joined()
            if !tokens.isEmpty, (4...20).contains(joined.count), joined.contains(where: \.isNumber),
               tokens.count == 1 || tokens.allSatisfy({ $0.count <= 4 }) {
                license = joined.uppercased()
            }
        }

        // Intents
        isYes = Self.has(#"^(yes|yeah|yep|yup|ya|sure|ok|okay|correct|right|confirm(ed)?|looks good|sounds good|that'?s (right|correct)|go ahead|book it|do it|perfect|great|sign|same guest|same person|same one)\b"#, t)
        isNo = Self.has(#"^(no|nope|nah|not (her|him|them|the same)|different|someone else|wrong)\b"#, t)
        wantsStartOver = Self.has(#"^(start over|start again|new guest|reset|cancel( it| this| that| the booking)?)[.!]?$"#, t)
        wantsScan = Self.has(#"\bscan\b"#, t)
        wantsFreeRooms = Self.has(#"\b(free|available|open|empty|vacant) rooms?\b|\b(what|which) rooms?\b|\bany rooms?\b|\bvacanc(y|ies)\b|\bwhat'?s free\b|\bwhat is free\b|\bshow (me )?(the )?rooms\b"#, t)

        // A plain name: "jane smith", "It's John O'Neil", "walk-in for Maria Garcia".
        let namePrefix = #"^(?:(?:it'?s|its|name'?s|the name is|name is|this is|guest is|guest name is|guest name|checking in|check in|walk[- ]in(?: for)?|book(?:ing)?(?: a room)?(?: for)?|reserve(?: a room)?(?: for)?|new guest|for|hi|hello|hey|mr|mrs|ms|miss)[\s,.]+)+"#
        if pending == .name && !isQuestion {
            let lowered = Self.replace(namePrefix, in: t, with: "").trimmingCharacters(in: CharacterSet(charactersIn: " .,!"))
            let tokens = lowered.split(separator: " ").map(String.init)
            let allWords = tokens.allSatisfy { Self.has(#"^[a-z][a-z'.]*$"#, $0) }
            if (1...4).contains(tokens.count), allWords,
               looksLikeName || !tokens.contains(where: { Self.keywords.contains($0) }) {
                let original = Self.replace(namePrefix, in: raw, with: "")
                    .trimmingCharacters(in: CharacterSet(charactersIn: " .,!"))
                bareName = original.filter(\.isUppercase).count > 1 ? original : Self.titleCase(original.lowercased())
            }
        }
        // A name inside a longer message: "jane smith 2 nights cash", "2 nights for jane smith".
        if pending == .name && bareName == nil && !isQuestion {
            let stripped = Self.replace(namePrefix, in: t, with: "")
            func isNameWord(_ word: String) -> Bool {
                Self.has(#"^[a-z][a-z'.]*$"#, word) && !Self.keywords.contains(word) && !Self.filler.contains(word)
            }
            var leading: [String] = []
            for token in stripped.split(separator: " ").map({ $0.trimmingCharacters(in: CharacterSet(charactersIn: ",.!")) }) {
                guard isNameWord(token) else { break }
                leading.append(token)
            }
            var found: [String] = (2...4).contains(leading.count) ? leading : []
            if found.isEmpty, let m = Self.match(#"\bfor ([a-z][a-z'.]*(?: [a-z][a-z'.]*){1,3})[.!]?$"#, in: t) {
                let words = m.groups[1].split(separator: " ").map(String.init)
                if words.allSatisfy(isNameWord) { found = words }
            }
            if !found.isEmpty {
                bareName = Self.restoreCase(found.joined(separator: " "), from: raw)
            }
        }

        if pending == .address { readAddress() }

        // Company name for organization bookings: a comma-separated part that is just
        // a name ("acme corp"), or "billed to Acme Corp" / "company is Acme".
        if payment == .organization || pending == .organization {
            if let m = Self.match(#"\b(?:bill(?:ed)? to|company(?: is)?|organi[sz]ation(?: is)?|charge(?: it)? to)\s+([a-z][a-z&'. ]{1,40}?)\s*(?:,|$|\bbill\b|\bpay)"#, in: t) {
                organizationName = m.groups[1].trimmingCharacters(in: .whitespaces)
            } else {
                let segments = t.components(separatedBy: CharacterSet(charactersIn: ",;")).map { $0.trimmingCharacters(in: .whitespaces) }
                for segment in segments.reversed() {
                    let words = segment.split(separator: " ").map(String.init)
                    guard (1...4).contains(words.count),
                          words.allSatisfy({ Self.has(#"^[a-z][a-z&'.]*$"#, $0) }),
                          !words.contains(where: { Self.keywords.contains($0) || Self.filler.contains($0) || $0 == "bill" || $0 == "later" }) else { continue }
                    if let name = bareName, name.lowercased() == segment { continue }
                    organizationName = segment
                    break
                }
            }
            organizationName = organizationName.map { Self.restoreCase($0, from: raw) }
        }

        // A short free-text answer ("Acme Corp", "Acme, bill them later").
        let firstPart = raw.components(separatedBy: CharacterSet(charactersIn: ",;")).first ?? raw
        let cleaned = Self.replace(#"^(?:(?:it'?s|its|billed to|bill to|paid by|company is|the company is|company)\s+)+"#,
                                   in: firstPart.trimmingCharacters(in: .whitespaces), with: "")
            .trimmingCharacters(in: CharacterSet(charactersIn: " .!"))
        let cleanedWords = cleaned.split(separator: " ")
        if (1...5).contains(cleanedWords.count), !cleaned.contains(where: \.isNumber),
           !Self.has(#"^(yes|no|ok|okay|cash|card|check)$"#, cleaned.lowercased()) {
            shortAnswer = cleaned.contains(where: \.isUppercase) ? cleaned : Self.titleCase(cleaned)
        }
    }

    /// "100 Oak St, Chicago, IL 60601", "2500 N Lake Shore Drive Springfield Illinois 62704",
    /// or just part of it ("Chicago IL 60601"). A backup for when the AI misses it.
    private mutating func readAddress() {
        var rest = raw.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: " ,."))

        if let m = Self.match(#"(\d{5})(?:-\d{4})?\s*\.?$"#, in: rest) {
            addressZip = m.groups[1]
            rest = (rest as NSString).substring(to: m.range.location).trimmingCharacters(in: CharacterSet(charactersIn: " ,."))
        }
        let stateAlternatives = (Self.stateNames.keys.sorted { $0.count > $1.count }
            + Self.stateNames.values.map { $0.lowercased() }).joined(separator: "|")
        if let m = Self.match(#"(?:^|[\s,])("# + stateAlternatives + #")$"#, in: rest) {
            let found = m.groups[1]
            addressState = Self.stateNames[found] ?? found.uppercased()
            let start = (rest as NSString).range(of: found, options: .backwards).location
            if start != NSNotFound {
                rest = (rest as NSString).substring(to: start).trimmingCharacters(in: CharacterSet(charactersIn: " ,."))
            }
        }
        let suffix = #"(?:street|st|avenue|ave|road|rd|drive|dr|lane|ln|boulevard|blvd|way|court|ct|place|pl|circle|cir|parkway|pkwy|highway|hwy|terrace|ter|trail|trl)\.?"#
        if let m = Self.match(#"^(\d+[a-z]?\s+.*?\b"# + suffix + #")(?:[\s,]+(.*))?$"#, in: rest) {
            addressStreet = m.groups[1]
            let city = m.groups[2].trimmingCharacters(in: CharacterSet(charactersIn: " ,."))
            if !city.isEmpty { addressCity = city }
        } else {
            let parts = rest.components(separatedBy: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
            if let first = parts.first, Self.has(#"^\d+[a-z]?\s+\S"#, first) {
                addressStreet = first
                if parts.count > 1 { addressCity = parts[1] }
            } else if let last = parts.last, !last.contains(where: \.isNumber), addressState != nil || addressZip != nil {
                addressCity = last
            }
        }
        // Keep the manager's own capitals where they typed them.
        let original = raw
        addressStreet = addressStreet.map { Self.restoreCase($0, from: original) }
        addressCity = addressCity.map { Self.restoreCase($0, from: original) }
    }

    /// Keeps capitals the manager typed on purpose ("McDonald"), otherwise title-cases.
    private static func restoreCase(_ lowered: String, from raw: String) -> String {
        let range = (raw.lowercased() as NSString).range(of: lowered)
        if range.location != NSNotFound {
            let original = (raw as NSString).substring(with: range)
            // Only trust the typed capitals if more than the very first letter is capitalised
            // (iOS capitalises the first letter of every message by itself).
            let capitals = original.filter(\.isUppercase).count
            if capitals > 1 { return original }
        }
        return titleCase(lowered)
    }

    /// Whether the AI model needs to read this message. Skipped when the rules
    /// explain every word, which keeps simple answers instant.
    func needsModel(pendingField pending: AssistantField?) -> Bool {
        let leftover = Self.matches(#"[a-z']+"#, in: normalized).filter { !Self.filler.contains($0) }
        if leftover.isEmpty { return false }
        let words = normalized.split(separator: " ").count
        if pending == .name && bareName != nil { return false }
        if (isYes || isNo) && words <= 3 { return false }
        if pending == .license && license != nil { return false }
        if hasAnyDetail && words <= 3 { return false }
        return true
    }

    // MARK: Checking what the AI read

    /// Every part of the name appears in the message.
    func mentionsName(_ name: String) -> Bool {
        let parts = Self.matches(#"[a-z']+"#, in: name.lowercased()).filter { $0.count >= 2 }
        guard !parts.isEmpty, parts.count <= 5, !name.contains(where: \.isNumber) else { return false }
        return parts.allSatisfy { Self.has(#"\b"# + NSRegularExpression.escapedPattern(for: $0) + #"\b"#, normalized) }
    }

    /// A code (licence, ZIP, phone) appears in the message, ignoring spaces and dashes.
    func mentionsCode(_ code: String) -> Bool {
        let wanted = code.lowercased().filter { $0.isLetter || $0.isNumber }
        guard !wanted.isEmpty else { return false }
        return normalized.filter { $0.isLetter || $0.isNumber }.contains(wanted)
    }

    /// Most words (and every number) of a phrase appear in the message.
    /// Lenient so "St" said / "Street" read still counts.
    func mentionsWords(_ phrase: String) -> Bool {
        let parts = Self.matches(#"[a-z0-9']+"#, in: Self.normalize(phrase))
        guard !parts.isEmpty else { return false }
        let found = parts.filter { Self.has(#"\b"# + NSRegularExpression.escapedPattern(for: $0) + #"\b"#, normalized) }
        let numbersFound = parts.filter { $0.allSatisfy(\.isNumber) }.allSatisfy { found.contains($0) }
        return numbersFound && Double(found.count) >= Double(parts.count) * 0.6
    }

    func mentionsState(_ code: String) -> Bool {
        if Self.has(#"\b"# + code.lowercased() + #"\b"#, normalized) { return true }
        return Self.stateNames.contains { $0.value == code && normalized.contains($0.key) }
    }

    func mentionsNumber(_ n: Int) -> Bool {
        Self.has(#"(?<!\d)"# + String(n) + #"(?:\.\d+)?(?!\d)"#, normalized)
    }

    var mentionsDate: Bool {
        Self.has(#"\d{1,2}/\d{1,2}|\b(today|tonight|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)"#, normalized)
    }

    var mentionsNightWord: Bool { Self.has(#"\bnights?\b|\bnites?\b|\bdays?\b|\bweeks?\b"#, normalized) }
    var mentionsRoomWord: Bool { Self.has(#"\broom\b|\brm\b|#"#, normalized) }
    var mentionsMoneyWord: Bool { Self.has(#"\$|dollar|bucks|\brate\b|\bprice\b|a night|per night|each night|nightly"#, normalized) }

    // MARK: Shared helpers

    static func payment(in text: String) -> PaymentMethod? {
        let patterns: [(PaymentMethod, String)] = [
            (.cash, #"\bcash\b"#),
            (.card, #"\b(card|credit|debit|visa|mastercard|master card|amex|american express|discover)\b"#),
            (.check, #"\b(cheque|check)\b(?!\s*(in|out)\b)"#),   // "check in" isn't a payment
            (.organization, #"\b(organi[sz]ation|company|corporate|business account|invoice|direct bill|on account|bill (it |them )?(to|later))\b"#)
        ]
        var best: (PaymentMethod, Int)?
        for (method, pattern) in patterns {
            if let m = match(pattern, in: text), best == nil || m.range.location < best!.1 {
                best = (method, m.range.location)
            }
        }
        return best?.0
    }

    static func stateCode(_ raw: String) -> String? {
        let value = raw.trimmingCharacters(in: .whitespaces)
        if value.count == 2, stateNames.values.contains(value.uppercased()) { return value.uppercased() }
        return stateNames[value.lowercased()]
    }

    static func parseISODate(_ text: String) -> Date? {
        let lower = text.lowercased()
        let today = Calendar.current.startOfDay(for: Date())
        if lower.contains("today") || lower.contains("tonight") { return today }
        if lower.contains("tomorrow") { return Calendar.current.date(byAdding: .day, value: 1, to: today) }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        guard let date = f.date(from: text) else { return nil }
        let day = Calendar.current.startOfDay(for: date)
        return day >= today ? day : nil   // no check-ins in the past
    }

    static func normalize(_ text: String) -> String {
        var t = text.lowercased().replacingOccurrences(of: "\u{2019}", with: "'")
        t = replace(#"([a-z])-([a-z])"#, in: t, with: "$1 $2")
        t = replace(#"\s+"#, in: t, with: " ").trimmingCharacters(in: .whitespaces)
        return wordsToDigits(t)
    }

    /// "eighty nine" → "89", "one hundred twenty" → "120", "two" → "2".
    static func wordsToDigits(_ text: String) -> String {
        let units: [String: Int] = ["zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
                                    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12,
                                    "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16,
                                    "seventeen": 17, "eighteen": 18, "nineteen": 19]
        let tens: [String: Int] = ["twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
                                   "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90]
        var out: [String] = []
        var current: Int?
        func flush() {
            if let c = current { out.append(String(c)); current = nil }
        }
        for token in text.split(separator: " ").map(String.init) {
            let bare = token.trimmingCharacters(in: CharacterSet(charactersIn: ".,!?;:"))
            if let u = units[bare] {
                if let c = current, c >= 20, c % 10 == 0 { current = c + u } else { flush(); current = u }
            } else if let t = tens[bare] {
                if let c = current, c >= 100, c % 100 == 0 { current = c + t } else { flush(); current = t }
            } else if bare == "hundred" {
                if let c = current, c < 10 { current = c * 100 }
                else if current == nil { current = 100 }
                else { flush(); current = 100 }
            } else if bare == "and", let c = current, c >= 100 {
                continue
            } else {
                flush()
                out.append(token)
            }
        }
        flush()
        return out.joined(separator: " ")
    }

    /// "o'neil" → "O'Neil", "mary-jane watson" → "Mary-Jane Watson".
    static func titleCase(_ text: String) -> String {
        var result = ""
        var upperNext = true
        for ch in text {
            if upperNext && ch.isLetter { result += ch.uppercased() } else { result.append(ch) }
            upperNext = ch == " " || ch == "'" || ch == "-"
        }
        return result
    }

    /// The first date mentioned: today/tonight, tomorrow, a weekday, "Nov 15", "11/15".
    static func findDate(in text: String, today: Date) -> Date? {
        let cal = Calendar.current
        var found: Date?
        if has(#"\b(today|tonight)\b"#, text) { found = today }
        if has(#"\btomorrow\b"#, text) { found = cal.date(byAdding: .day, value: 1, to: today) }
        let weekdays = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
        for (index, day) in weekdays.enumerated() where has(#"\b"# + day + #"\b"#, text) {
            let todayWeekday = cal.component(.weekday, from: today) - 1   // 0 = Sunday
            let ahead = (index - todayWeekday + 7) % 7
            found = cal.date(byAdding: .day, value: ahead, to: today)
        }
        let months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
        if let m = match(#"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?\b"#, in: text),
           let monthIndex = months.firstIndex(of: String(m.groups[1].prefix(3))),
           let day = Int(m.groups[2]) {
            found = upcomingDate(month: monthIndex + 1, day: day, year: nil, today: today)
        }
        if let m = match(#"(?<![\d/])(\d{1,2})/(\d{1,2})(?:/(\d{2,4}))?(?![\d/])"#, in: text),
           let month = Int(m.groups[1]), let day = Int(m.groups[2]) {
            var year = Int(m.groups[3])
            if let y = year, y < 100 { year = y + 2000 }
            if let date = upcomingDate(month: month, day: day, year: year, today: today) { found = date }
        }
        // "the 15th" — this month, or next month if it has passed.
        if found == nil, let m = match(#"\bthe\s+(\d{1,2})(?:st|nd|rd|th)\b"#, in: text), let day = Int(m.groups[1]) {
            let comps = cal.dateComponents([.year, .month], from: today)
            if let thisMonth = cal.date(from: DateComponents(year: comps.year, month: comps.month, day: day)),
               cal.component(.day, from: thisMonth) == day {
                found = thisMonth >= today ? thisMonth : cal.date(byAdding: .month, value: 1, to: thisMonth)
            }
        }
        return found
    }

    private static func upcomingDate(month: Int, day: Int, year: Int?, today: Date) -> Date? {
        let cal = Calendar.current
        let thisYear = cal.component(.year, from: today)
        guard (1...12).contains(month), (1...31).contains(day),
              let date = cal.date(from: DateComponents(year: year ?? thisYear, month: month, day: day)),
              cal.component(.day, from: date) == day else { return nil }
        if date >= today { return date }
        if year == nil { return cal.date(from: DateComponents(year: thisYear + 1, month: month, day: day)) }
        return nil
    }

    // MARK: Regex helpers

    private struct Match {
        let range: NSRange
        let groups: [String]
    }

    private static func regex(_ pattern: String) -> NSRegularExpression? {
        try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive])
    }

    private static func match(_ pattern: String, in text: String) -> Match? {
        guard let re = regex(pattern),
              let m = re.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) else { return nil }
        let groups = (0..<m.numberOfRanges).map { i -> String in
            guard let r = Range(m.range(at: i), in: text) else { return "" }
            return String(text[r])
        }
        return Match(range: m.range, groups: groups)
    }

    private static func has(_ pattern: String, _ text: String) -> Bool {
        match(pattern, in: text) != nil
    }

    private static func matches(_ pattern: String, in text: String) -> [String] {
        guard let re = regex(pattern) else { return [] }
        return re.matches(in: text, range: NSRange(text.startIndex..., in: text)).compactMap {
            Range($0.range, in: text).map { String(text[$0]) }
        }
    }

    private static func replace(_ pattern: String, in text: String, with template: String) -> String {
        guard let re = regex(pattern) else { return text }
        return re.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: template)
    }

    // MARK: Word lists

    /// Words that are never part of a guest's name on their own.
    private static let keywords: Set<String> = Set("""
    night nights nite nites day days week weeks room rm cash card check cheque visa mastercard amex discover \
    yes no yeah nope scan today tomorrow tonight the a for and please walk in guest checking hi hello hey ok \
    okay organization company total tax dollars bucks rate per paying pay by free available book booking reserve
    """.split(separator: " ").map(String.init))

    /// Words the rules already understand; anything else means the AI should read the message.
    private static let filler: Set<String> = Set("""
    for at a an the and by with per night nights nite nites day days week weeks room rm unit cash card check \
    cheque paying pay pays paid dollars dollar bucks plus tax it is make change to please ok okay yes yeah no \
    total rate price just only tonight today tomorrow monday tuesday wednesday thursday friday saturday sunday \
    jan feb mar apr may jun jul aug sep sept oct nov dec january february march april june july august \
    september october november december visa mastercard master amex american express discover credit debit \
    in on of from starting staying stay i they she he will be want wants number num that this one all set \
    sure right correct actually instead
    """.split(separator: " ").map(String.init))

    static let stateNames: [String: String] = [
        "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR", "california": "CA",
        "colorado": "CO", "connecticut": "CT", "delaware": "DE", "florida": "FL", "georgia": "GA",
        "hawaii": "HI", "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA",
        "kansas": "KS", "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD",
        "massachusetts": "MA", "michigan": "MI", "minnesota": "MN", "mississippi": "MS", "missouri": "MO",
        "montana": "MT", "nebraska": "NE", "nevada": "NV", "new hampshire": "NH", "new jersey": "NJ",
        "new mexico": "NM", "new york": "NY", "north carolina": "NC", "north dakota": "ND", "ohio": "OH",
        "oklahoma": "OK", "oregon": "OR", "pennsylvania": "PA", "rhode island": "RI", "south carolina": "SC",
        "south dakota": "SD", "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT",
        "virginia": "VA", "washington": "WA", "west virginia": "WV", "wisconsin": "WI", "wyoming": "WY",
        "district of columbia": "DC"
    ]
}

#endif
