//
//  CameraPermissionManager.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 6/16/25.
//

import SwiftUI
import AVFoundation
import Photos

class CameraPermissionManager: ObservableObject {
    @Published var showAlert = false
    @Published var alertMessage = ""
    @Published var showSettings = false
    
    func requestCameraPermission(completion: @escaping (Bool) -> Void) {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            DispatchQueue.main.async {
                completion(true)
            }
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    completion(granted)
                    if !granted {
                        self.showCameraPermissionAlert()
                    }
                }
            }
        case .denied, .restricted:
            DispatchQueue.main.async {
                self.showCameraPermissionAlert()
                completion(false)
            }
        @unknown default:
            DispatchQueue.main.async {
                completion(false)
            }
        }
    }
    
    func requestPhotoLibraryPermission(completion: @escaping (Bool) -> Void) {
        switch PHPhotoLibrary.authorizationStatus() {
        case .authorized, .limited:
            DispatchQueue.main.async {
                completion(true)
            }
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { status in
                DispatchQueue.main.async {
                    let granted = status == .authorized || status == .limited
                    completion(granted)
                    if !granted {
                        self.showPhotoLibraryPermissionAlert()
                    }
                }
            }
        case .denied, .restricted:
            DispatchQueue.main.async {
                self.showPhotoLibraryPermissionAlert()
                completion(false)
            }
        @unknown default:
            DispatchQueue.main.async {
                completion(false)
            }
        }
    }
    
    private func showCameraPermissionAlert() {
        alertMessage = "Camera access is required to take photos of driving licenses. Please enable camera access in Settings."
        showAlert = true
        showSettings = true
    }
    
    private func showPhotoLibraryPermissionAlert() {
        alertMessage = "Photo library access is required to select photos. Please enable photo library access in Settings."
        showAlert = true
        showSettings = true
    }
    
    func openSettings() {
        if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(settingsUrl)
        }
    }
}

// Updated ImagePicker with better permission handling
struct ImprovedImagePicker: UIViewControllerRepresentable {
    @Binding var imageData: Data
    @Binding var isPresented: Bool
    var sourceType: UIImagePickerController.SourceType
    var onComplete: (() -> Void)?
    @StateObject private var permissionManager = CameraPermissionManager()
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        
        // Additional camera setup
        if sourceType == .camera {
            picker.cameraDevice = .rear
            picker.cameraCaptureMode = .photo
            picker.allowsEditing = false
        }
        
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImprovedImagePicker
        
        init(_ parent: ImprovedImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                // Compress image properly
                if let compressedData = uiImage.jpegData(compressionQuality: 0.8) {
                    parent.imageData = compressedData
                    parent.onComplete?()
                }
            }
            parent.isPresented = false
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.isPresented = false
        }
    }
}

// Updated PhotoSourcePicker with better permission handling
struct ImprovedPhotoSourcePicker: View {
    @Binding var showImagePicker: Bool
    @Binding var isPresented: Bool
    @Binding var photoSource: UIImagePickerController.SourceType
    @StateObject private var permissionManager = CameraPermissionManager()
    
    var body: some View {
        NavigationView {
            List {
                Section("Choose Photo Source") {
                    Button(action: {
                        permissionManager.requestCameraPermission { granted in
                            if granted {
                                photoSource = .camera
                                showImagePicker = true
                                isPresented = false
                            }
                        }
                    }) {
                        HStack {
                            Image(systemName: "camera.fill")
                                .foregroundColor(.blue)
                                .frame(width: 30)
                            Text("Take Photo")
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                                .font(.caption)
                        }
                        .padding(.vertical, 8)
                    }
                    
                    Button(action: {
                        permissionManager.requestPhotoLibraryPermission { granted in
                            if granted {
                                photoSource = .photoLibrary
                                showImagePicker = true
                                isPresented = false
                            }
                        }
                    }) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                                .foregroundColor(.blue)
                                .frame(width: 30)
                            Text("Choose from Library")
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                                .font(.caption)
                        }
                        .padding(.vertical, 8)
                    }
                }
            }
            .navigationTitle("Select Photo Source")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cancel") {
                        isPresented = false
                    }
                }
            }
        }
        .alert("Permission Required", isPresented: $permissionManager.showAlert) {
            if permissionManager.showSettings {
                Button("Settings") {
                    permissionManager.openSettings()
                    isPresented = false
                }
                Button("Cancel", role: .cancel) {
                    isPresented = false
                }
            } else {
                Button("OK") {
                    isPresented = false
                }
            }
        } message: {
            Text(permissionManager.alertMessage)
        }
    }
}
