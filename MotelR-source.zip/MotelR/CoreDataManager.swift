//
//  CoreDataManager.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/13/24.
//

import CoreData
import Foundation

extension Notification.Name {
    static let coreDataSaveFailed     = Notification.Name("coreDataSaveFailed")
    static let cloudKitSyncDidChange  = Notification.Name("cloudKitSyncDidChange")
}

class CoreDataManager {
    static let shared = CoreDataManager()

    /// Non-nil if the persistent store failed to load. Check this at app launch
    /// and show a user-facing error instead of crashing.
    private(set) var loadError: Error?

    private init() {}

    // MARK: - Core Data + CloudKit stack

    lazy var persistentContainer: NSPersistentCloudKitContainer = {
        let container = NSPersistentCloudKitContainer(name: "MotelR")

        guard let description = container.persistentStoreDescriptions.first else {
            self.loadError = NSError(
                domain: "CoreDataManager",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "No persistent store descriptions found."]
            )
            return container
        }

        // Point to your specific CloudKit container
        description.cloudKitContainerOptions =
            NSPersistentCloudKitContainerOptions(containerIdentifier: "iCloud.Nishant.Co.MotelR")

        // Required for CloudKit sync: persistent history tracking lets
        // NSPersistentCloudKitContainer know what changed and when.
        description.setOption(true as NSNumber,
                              forKey: NSPersistentHistoryTrackingKey)

        // Post a local notification whenever CloudKit pushes remote changes
        // so MotelData can refresh its published arrays automatically.
        description.setOption(true as NSNumber,
                              forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)

        container.loadPersistentStores { _, error in
            if let error = error {
                self.loadError = error
            }
        }

        // Automatically merge remote CloudKit changes into the view context.
        container.viewContext.automaticallyMergesChangesFromParent = true

        // Last-write-wins: if the same field was changed on two devices,
        // the most recent save wins without throwing a conflict error.
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy

        return container
    }()

    // MARK: - Store Reset (last resort recovery)

    func resetStore() {
        guard let storeURL = persistentContainer.persistentStoreDescriptions.first?.url else { return }
        let coordinator = persistentContainer.persistentStoreCoordinator
        for store in coordinator.persistentStores {
            try? coordinator.remove(store)
        }
        let fileManager = FileManager.default
        for suffix in ["", "-wal", "-shm"] {
            let url = URL(fileURLWithPath: storeURL.path + suffix)
            try? fileManager.removeItem(at: url)
        }
    }

    var context: NSManagedObjectContext {
        persistentContainer.viewContext
    }

    // MARK: - Bulk Delete

    /// Removes every Room, Booking and IncidentReport.
    ///
    /// Deliberately fetch-and-delete rather than `NSBatchDeleteRequest`: batch deletes
    /// bypass the managed object context, so with `NSPersistentCloudKitContainer` the
    /// deletions never reach other devices and the view context is left holding rows
    /// that no longer exist in the store.
    func deleteAllObjects(in context: NSManagedObjectContext) throws {
        // Bookings first so no booking is briefly left without its room.
        for entityName in ["Booking", "IncidentReport", "Room"] {
            let request = NSFetchRequest<NSManagedObject>(entityName: entityName)
            request.includesPropertyValues = false
            for object in try context.fetch(request) {
                context.delete(object)
            }
        }
        if context.hasChanges {
            try context.save()
        }
    }

    /// Runs `work` on the context's own queue and rethrows anything it throws.
    /// Backup and restore are kicked off from background queues, and the view context
    /// may only be touched from the main queue.
    func performAndWait<T>(_ work: @escaping (NSManagedObjectContext) throws -> T) throws -> T {
        var result: Result<T, Error>!
        context.performAndWait {
            result = Result { try work(context) }
        }
        return try result.get()
    }

    // MARK: - Core Data Saving

    func save() {
        guard context.hasChanges else { return }
        do {
            try context.save()
        } catch {
            print("CoreData save error: \(error)")
            NotificationCenter.default.post(name: .coreDataSaveFailed, object: nil)
        }
    }
}
