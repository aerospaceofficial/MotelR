//  OrganizationsView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Design Tokens (file-private)
private let orgPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let orgGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let orgGold   = Color(red: 0.96, green: 0.65, blue: 0.14)
private let orgGreen  = Color(red: 0.20, green: 0.78, blue: 0.35)
private let orgRed    = Color(red: 1.0,  green: 0.23, blue: 0.19)

// MARK: - OrganizationsView
struct OrganizationsView: View {
    @EnvironmentObject var motelData: MotelData
    @State private var showingPaid = false
    @State private var bookingToMarkPaid: CDBooking?
    @State private var showMarkPaidConfirmation = false
    @State private var shareItems: [Any] = []
    @State private var showingShareSheet = false

    // MARK: Derived data
    private var pendingOrgBookings: [CDBooking] {
        motelData.pendingBookings
            .filter { !($0.organizationName ?? "").trimmingCharacters(in: .whitespaces).isEmpty }
    }

    private var paidOrgBookings: [CDBooking] {
        (motelData.bookings + motelData.history)
            .filter {
                $0.paymentMethodEnum == .organization &&
                $0.paymentStatusEnum == .paid &&
                !($0.organizationName ?? "").trimmingCharacters(in: .whitespaces).isEmpty
            }
    }

    private var groupedPending: [(key: String, value: [CDBooking])] {
        Dictionary(grouping: pendingOrgBookings) { $0.organizationName ?? "Unknown" }
            .sorted { $0.key < $1.key }
    }

    private var groupedPaid: [(key: String, value: [CDBooking])] {
        Dictionary(grouping: paidOrgBookings) { $0.organizationName ?? "Unknown" }
            .sorted { $0.key < $1.key }
    }

    private var totalPendingAmount: Double {
        pendingOrgBookings.reduce(0) { $0 + $1.prizeAmount }
    }

    private var paidThisMonth: Double {
        let cal = Calendar.current
        let now = Date()
        return paidOrgBookings
            .filter { cal.isDate($0.checkOutDate, equalTo: now, toGranularity: .month) }
            .reduce(0) { $0 + $1.prizeAmount }
    }

    private var totalOrgsCount: Int {
        Set((pendingOrgBookings + paidOrgBookings).compactMap { $0.organizationName }).count
    }

    // MARK: Body
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    statsHeader
                        .padding(.top, 8)
                    tabToggle
                    if showingPaid {
                        paidSection
                    } else {
                        pendingSection
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 32)
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Organizations")
            .navigationBarTitleDisplayMode(.large)
        }
        .confirmationDialog(
            "Mark as Paid",
            isPresented: $showMarkPaidConfirmation,
            titleVisibility: .visible
        ) {
            Button("Mark Paid", role: .none) {
                if let booking = bookingToMarkPaid {
                    motelData.markBookingAsPaid(booking)
                }
                bookingToMarkPaid = nil
            }
            Button("Cancel", role: .cancel) { bookingToMarkPaid = nil }
        } message: {
            if let b = bookingToMarkPaid {
                Text("Mark \(b.customerName)'s booking as paid?")
            }
        }
        .sheet(isPresented: $showingShareSheet) {
            SharedActivityView(activityItems: shareItems)
        }
    }

    // MARK: Stats Header
    private var statsHeader: some View {
        HStack(spacing: 12) {
            OrgStatCard(
                title: "Organizations",
                value: "\(totalOrgsCount)",
                icon: "building.2.fill",
                gradient: orgGradient
            )
            OrgStatCard(
                title: "Total Pending",
                value: String(format: "$%.0f", totalPendingAmount),
                icon: "clock.fill",
                gradient: LinearGradient(
                    colors: [orgGold, Color(red: 0.85, green: 0.50, blue: 0.05)],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
            )
            OrgStatCard(
                title: "Paid / Month",
                value: String(format: "$%.0f", paidThisMonth),
                icon: "checkmark.seal.fill",
                gradient: LinearGradient(
                    colors: [orgGreen, Color(red: 0.10, green: 0.60, blue: 0.25)],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
            )
        }
    }

    // MARK: Tab Toggle
    private var tabToggle: some View {
        HStack(spacing: 0) {
            orgTabButton(title: "Pending", isSelected: !showingPaid) { showingPaid = false }
            orgTabButton(title: "Paid History", isSelected: showingPaid) { showingPaid = true }
        }
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func orgTabButton(title: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(isSelected ? .white : .secondary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(
                    isSelected
                        ? orgGradient
                        : LinearGradient(colors: [.clear, .clear], startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }

    // MARK: Pending Section
    @ViewBuilder
    private var pendingSection: some View {
        if groupedPending.isEmpty {
            orgEmptyState(
                icon: "building.2",
                title: "No Pending Invoices",
                subtitle: "All organization accounts are settled."
            )
        } else {
            ForEach(groupedPending, id: \.key) { orgName, bookings in
                OrgSectionCard(
                    orgName: orgName,
                    bookings: bookings,
                    isPaid: false,
                    onMarkPaid: { booking in
                        bookingToMarkPaid = booking
                        showMarkPaidConfirmation = true
                    },
                    onShare: { booking in
                        generateAndShare(booking: booking)
                    }
                )
            }
        }
    }

    // MARK: Paid Section
    @ViewBuilder
    private var paidSection: some View {
        if groupedPaid.isEmpty {
            orgEmptyState(
                icon: "checkmark.seal",
                title: "No Paid Records",
                subtitle: "Paid organization bookings will appear here."
            )
        } else {
            ForEach(groupedPaid, id: \.key) { orgName, bookings in
                OrgSectionCard(
                    orgName: orgName,
                    bookings: bookings,
                    isPaid: true,
                    onMarkPaid: { _ in },
                    onShare: { booking in generateAndShare(booking: booking) }
                )
            }
        }
    }

    // MARK: Helpers
    private func generateAndShare(booking: CDBooking) {
        let data = EnhancedPDFReceiptGenerator.generateProfessionalReceipt(
            booking: booking,
            businessName: motelData.businessName,
            taxRate: motelData.taxRate
        )
        let name = booking.customerName.replacingOccurrences(of: " ", with: "_")
        let tempURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("Receipt_\(name).pdf")
        try? data.write(to: tempURL)
        shareItems = [tempURL]
        showingShareSheet = true
    }

    private func orgEmptyState(icon: String, title: String, subtitle: String) -> some View {
        VStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundStyle(orgPrimary.opacity(0.35))
            Text(title)
                .font(.system(.headline, design: .rounded))
            Text(subtitle)
                .font(.system(.subheadline, design: .rounded))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(40)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }
}

// MARK: - Stat Card
private struct OrgStatCard: View {
    let title: String
    let value: String
    let icon: String
    let gradient: LinearGradient

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
            Spacer()
            Text(value)
                .font(.system(.title3, design: .rounded).weight(.bold))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.65)
            Text(title)
                .font(.system(.caption2, design: .rounded))
                .foregroundStyle(.white.opacity(0.85))
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .aspectRatio(1.0, contentMode: .fit)
        .background(gradient)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.10), radius: 8, y: 4)
    }
}

// MARK: - Org Section Card
private struct OrgSectionCard: View {
    let orgName: String
    let bookings: [CDBooking]
    let isPaid: Bool
    let onMarkPaid: (CDBooking) -> Void
    let onShare: (CDBooking) -> Void

    private var totalOwed: Double {
        bookings.reduce(0) { $0 + $1.prizeAmount }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(orgGradient)
                        .frame(width: 44, height: 44)
                    Text(String(orgName.prefix(1)).uppercased())
                        .font(.system(.headline, design: .rounded).weight(.bold))
                        .foregroundStyle(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(orgName)
                        .font(.system(.headline, design: .rounded).weight(.semibold))
                    Text(
                        isPaid
                            ? "\(bookings.count) paid booking\(bookings.count == 1 ? "" : "s")"
                            : String(format: "Total owed: $%.2f", totalOwed)
                    )
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(isPaid ? .secondary : orgGold)
                }
                Spacer()
                if !isPaid {
                    Text(String(format: "$%.2f", totalOwed))
                        .font(.system(.title3, design: .rounded).weight(.bold))
                        .foregroundStyle(orgRed)
                }
            }
            .padding(16)

            Divider().padding(.horizontal, 16)

            ForEach(Array(bookings.enumerated()), id: \.element.id) { idx, booking in
                OrgBookingRow(
                    booking: booking,
                    isPaid: isPaid,
                    onMarkPaid: { onMarkPaid(booking) },
                    onShare: { onShare(booking) }
                )
                if idx < bookings.count - 1 {
                    Divider().padding(.leading, 16)
                }
            }
        }
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }
}

// MARK: - Org Booking Row
private struct OrgBookingRow: View {
    let booking: CDBooking
    let isPaid: Bool
    let onMarkPaid: () -> Void
    let onShare: () -> Void

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .short
        return f
    }()

    private var daysOverdue: Int {
        guard !isPaid else { return 0 }
        let diff = Calendar.current.dateComponents([.day], from: booking.checkOutDate, to: Date()).day ?? 0
        return max(0, diff)
    }

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(booking.customerName)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
                HStack(spacing: 6) {
                    Label("Room \(booking.room.number)", systemImage: "bed.double.fill")
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                    Text("·")
                        .foregroundStyle(.tertiary)
                    Text("\(Self.dateFormatter.string(from: booking.checkInDate)) – \(Self.dateFormatter.string(from: booking.checkOutDate))")
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                }
                if !isPaid && daysOverdue > 7 {
                    Text("\(daysOverdue)d overdue")
                        .font(.system(.caption2, design: .rounded).weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(daysOverdue > 30 ? orgRed : orgGold)
                        .clipShape(Capsule())
                }
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 6) {
                Text(booking.prize)
                    .font(.system(.subheadline, design: .rounded).weight(.bold))
                    .foregroundStyle(isPaid ? orgGreen : .primary)
                HStack(spacing: 8) {
                    Button(action: onShare) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(orgPrimary)
                    }
                    .buttonStyle(.plain)
                    if !isPaid {
                        Button(action: onMarkPaid) {
                            Text("Mark Paid")
                                .font(.system(.caption, design: .rounded).weight(.semibold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(orgGreen)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .swipeActions(edge: .leading, allowsFullSwipe: false) {
            if !isPaid {
                Button(action: onMarkPaid) {
                    Label("Mark Paid", systemImage: "checkmark.circle.fill")
                }
                .tint(orgGreen)
            }
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            Button(action: onShare) {
                Label("Share", systemImage: "square.and.arrow.up")
            }
            .tint(orgPrimary)
        }
    }
}
