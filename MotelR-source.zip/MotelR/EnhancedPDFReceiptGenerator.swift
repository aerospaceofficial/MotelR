//
//  EnhancedPDFReceiptGenerator.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 6/21/25.
//

import UIKit
import SwiftUI
import CoreImage
import CoreImage.CIFilterBuiltins

class EnhancedPDFReceiptGenerator {
    
    // MARK: - Constants
    private struct Layout {
        static let pageWidth: CGFloat = 8.5 * 72.0  // Letter size
        static let pageHeight: CGFloat = 11 * 72.0
        static let margin: CGFloat = 54.0  // 0.75 inch margins
        static let contentWidth: CGFloat = pageWidth - (2 * margin)
        static let headerHeight: CGFloat = 120.0
        static let footerHeight: CGFloat = 80.0
        static let lineSpacing: CGFloat = 8.0
        static let sectionSpacing: CGFloat = 24.0
    }
    
    private struct Colors {
        static let primary = UIColor(red: 0.2, green: 0.4, blue: 0.8, alpha: 1.0)  // Professional blue
        static let secondary = UIColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1.0)  // Gray
        static let accent = UIColor(red: 0.0, green: 0.6, blue: 0.3, alpha: 1.0)  // Green for amounts
        static let background = UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.0)  // Light gray
        static let text = UIColor.black
    }
    
    private struct Fonts {
        static let businessName = UIFont.boldSystemFont(ofSize: 28)
        static let title = UIFont.boldSystemFont(ofSize: 20)
        static let sectionHeader = UIFont.boldSystemFont(ofSize: 16)
        static let body = UIFont.systemFont(ofSize: 12)
        static let bodyBold = UIFont.boldSystemFont(ofSize: 12)
        static let caption = UIFont.systemFont(ofSize: 10)
        static let amount = UIFont.boldSystemFont(ofSize: 14)
        static let totalAmount = UIFont.boldSystemFont(ofSize: 18)
    }
    
    // MARK: - Main Generation Function
    static func generateProfessionalReceipt(
        booking: CDBooking,
        businessName: String,
        taxRate: Double = 0.0,
        includeSignature: Bool = true,
        includeQRCode: Bool = true,
        receiptStyle: ReceiptStyle = .modern
    ) -> Data {
        
        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: Layout.pageWidth, height: Layout.pageHeight))
        
        return renderer.pdfData { context in
            context.beginPage()
            
            var currentY: CGFloat = Layout.margin
            
            // Header Section
            currentY = drawHeader(
                context: context.cgContext,
                businessName: businessName,
                startY: currentY,
                style: receiptStyle
            )
            
            // Receipt Information
            currentY = drawReceiptInfo(
                context: context.cgContext,
                booking: booking,
                startY: currentY + Layout.sectionSpacing
            )
            
            // Customer Details
            currentY = drawCustomerSection(
                context: context.cgContext,
                booking: booking,
                startY: currentY + Layout.sectionSpacing
            )
            
            // Booking Details
            currentY = drawBookingSection(
                context: context.cgContext,
                booking: booking,
                startY: currentY + Layout.sectionSpacing
            )
            
            // Payment Summary
            currentY = drawPaymentSummary(
                context: context.cgContext,
                booking: booking,
                taxRate: taxRate,
                startY: currentY + Layout.sectionSpacing
            )
            
            // Signature Section (if available)
            if includeSignature, let signatureData = booking.signatureImageData {
                currentY = drawSignatureSection(
                    context: context.cgContext,
                    signatureData: signatureData,
                    signatureDate: booking.signatureDate,
                    startY: currentY + Layout.sectionSpacing
                )
            }
            
            // QR Code (if enabled)
            if includeQRCode {
                currentY = drawQRCode(
                    context: context.cgContext,
                    booking: booking,
                    startY: currentY + Layout.sectionSpacing
                )
            }
            
            // Terms & Conditions Summary
            currentY = drawTermsSummary(
                context: context.cgContext,
                startY: currentY + Layout.sectionSpacing
            )
            
            // Footer
            _ = drawFooter(
                context: context.cgContext,
                businessName: businessName,
                startY: Layout.pageHeight - Layout.footerHeight
            )
        }
    }
    
    // MARK: - Header Section
    private static func drawHeader(
        context: CGContext,
        businessName: String,
        startY: CGFloat,
        style: ReceiptStyle
    ) -> CGFloat {
        
        var currentY = startY
        
        // Business Name with styling
        let businessNameRect = CGRect(
            x: Layout.margin,
            y: currentY,
            width: Layout.contentWidth,
            height: 40
        )
        
        // Background for business name
        context.setFillColor(Colors.primary.cgColor)
        let headerBackground = CGRect(
            x: Layout.margin - 10,
            y: currentY - 5,
            width: Layout.contentWidth + 20,
            height: 50
        )
        context.fill(headerBackground)
        
        // Business name text
        let businessNameAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.businessName,
            .foregroundColor: UIColor.white
        ]
        
        let businessNameString = NSAttributedString(string: businessName, attributes: businessNameAttributes)
        businessNameString.draw(in: businessNameRect)
        
        currentY += 60
        
        // Receipt title
        let receiptTitle = "OFFICIAL RECEIPT"
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.title,
            .foregroundColor: Colors.primary
        ]
        
        let titleSize = receiptTitle.size(withAttributes: titleAttributes)
        let titleRect = CGRect(
            x: Layout.margin + (Layout.contentWidth - titleSize.width) / 2,
            y: currentY,
            width: titleSize.width,
            height: titleSize.height
        )
        
        receiptTitle.draw(in: titleRect, withAttributes: titleAttributes)
        
        // Decorative line
        currentY += titleSize.height + 10
        context.setStrokeColor(Colors.primary.cgColor)
        context.setLineWidth(2)
        context.move(to: CGPoint(x: Layout.margin, y: currentY))
        context.addLine(to: CGPoint(x: Layout.pageWidth - Layout.margin, y: currentY))
        context.strokePath()
        
        return currentY + 15
    }
    
    // MARK: - Receipt Information
    private static func drawReceiptInfo(
        context: CGContext,
        booking: CDBooking,
        startY: CGFloat
    ) -> CGFloat {
        
        var currentY = startY
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .full
        dateFormatter.timeStyle = .short
        
        let receiptInfo = [
            ("Receipt #:", booking.id.uuidString.prefix(8).uppercased()),
            ("Issue Date:", dateFormatter.string(from: Date())),
            ("Room Number:", "Room \(booking.room.number)"),
            ("Guest ID:", booking.drivingLicenseNumber)
        ]
        
        // Create a nice info box
        let infoBoxRect = CGRect(
            x: Layout.margin,
            y: currentY,
            width: Layout.contentWidth,
            height: CGFloat(receiptInfo.count * 20 + 20)
        )
        
        context.setFillColor(Colors.background.cgColor)
        context.fill(infoBoxRect)
        context.setStrokeColor(Colors.secondary.cgColor)
        context.setLineWidth(1)
        context.stroke(infoBoxRect)
        
        currentY += 10
        
        for info in receiptInfo {
            drawInfoRow(
                context: context,
                label: String(info.0),
                value: String(info.1),
                y: currentY,
                labelFont: Fonts.bodyBold,
                valueFont: Fonts.body
            )
            currentY += 20
        }
        
        return currentY + 10
    }
    
    // MARK: - Customer Section
    private static func drawCustomerSection(
        context: CGContext,
        booking: CDBooking,
        startY: CGFloat
    ) -> CGFloat {
        
        var currentY = startY
        
        // Section header
        currentY = drawSectionHeader(context: context, title: "CUSTOMER INFORMATION", y: currentY)
        
        let customerInfo = [
            ("Name:", booking.customerName),
            ("Phone:", booking.phoneNumber),
            ("Address:", "\(booking.address)"),
            ("City, State:", "\(booking.city), \(booking.state) \(booking.zipCode)"),
            ("License #:", booking.drivingLicenseNumber)
        ]
        
        for info in customerInfo {
            currentY = drawDetailRow(context: context, label: info.0, value: info.1, y: currentY)
        }
        
        return currentY
    }
    
    // MARK: - Booking Section
    private static func drawBookingSection(
        context: CGContext,
        booking: CDBooking,
        startY: CGFloat
    ) -> CGFloat {
        
        var currentY = startY
        
        currentY = drawSectionHeader(context: context, title: "BOOKING DETAILS", y: currentY)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        
        let bookingInfo = [
            ("Check-in:", dateFormatter.string(from: booking.checkInDate)),
            ("Check-out:", dateFormatter.string(from: booking.checkOutDate)),
            ("Duration:", "\(booking.numberOfDays) day\(booking.numberOfDays == 1 ? "" : "s")"),
            ("Room Type:", "\(booking.room.members) Guest Room"),
            ("Room Number:", "Room \(booking.room.number)")
        ]
        
        for info in bookingInfo {
            currentY = drawDetailRow(context: context, label: info.0, value: info.1, y: currentY)
        }
        
        return currentY
    }
    
    // MARK: - Payment Summary
    private static func drawPaymentSummary(
        context: CGContext,
        booking: CDBooking,
        taxRate: Double,
        startY: CGFloat
    ) -> CGFloat {
        
        var currentY = startY
        
        currentY = drawSectionHeader(context: context, title: "PAYMENT SUMMARY", y: currentY)
        
        // Payment details box
        let summaryBoxRect = CGRect(
            x: Layout.margin,
            y: currentY,
            width: Layout.contentWidth,
            height: 120
        )
        
        context.setFillColor(UIColor.white.cgColor)
        context.fill(summaryBoxRect)
        context.setStrokeColor(Colors.primary.cgColor)
        context.setLineWidth(2)
        context.stroke(summaryBoxRect)
        
        currentY += 15
        
        // Calculate amounts
        let totalAmount = Double(booking.prize.replacingOccurrences(of: "$", with: "")) ?? 0.0
        
        if booking.isTaxed {
            let rate = taxRate > 0 ? taxRate : 0.0
            let baseAmount = rate > 0 ? totalAmount / (1 + rate) : totalAmount
            let taxAmount = totalAmount - baseAmount
            let taxPercent = Int((rate * 100).rounded())

            currentY = drawAmountRow(context: context, label: "Base Amount:", amount: baseAmount, y: currentY)
            currentY = drawAmountRow(context: context, label: "Tax (\(taxPercent)%):", amount: taxAmount, y: currentY)
            
            // Separator line
            context.setStrokeColor(Colors.secondary.cgColor)
            context.setLineWidth(1)
            context.move(to: CGPoint(x: Layout.margin + 10, y: currentY + 5))
            context.addLine(to: CGPoint(x: Layout.pageWidth - Layout.margin - 10, y: currentY + 5))
            context.strokePath()
            currentY += 15
        }
        
        // Total amount (highlighted)
        let totalRect = CGRect(
            x: Layout.margin + 10,
            y: currentY,
            width: Layout.contentWidth - 20,
            height: 25
        )
        
        context.setFillColor(Colors.accent.withAlphaComponent(0.1).cgColor)
        context.fill(totalRect)
        
        let totalAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.totalAmount,
            .foregroundColor: Colors.accent
        ]
        
        "TOTAL AMOUNT:".draw(
            in: CGRect(x: Layout.margin + 15, y: currentY + 5, width: 200, height: 20),
            withAttributes: totalAttributes
        )
        
        let totalAmountString = String(format: "$%.2f", totalAmount)
        let totalAmountSize = totalAmountString.size(withAttributes: totalAttributes)
        totalAmountString.draw(
            in: CGRect(
                x: Layout.pageWidth - Layout.margin - totalAmountSize.width - 15,
                y: currentY + 5,
                width: totalAmountSize.width,
                height: 20
            ),
            withAttributes: totalAttributes
        )
        
        currentY += 35
        
        // Payment method
        let paymentMethodText = "Payment Method: \(booking.paymentMethodEnum.rawValue)"
        let paymentAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.body,
            .foregroundColor: Colors.text
        ]
        
        paymentMethodText.draw(
            in: CGRect(x: Layout.margin + 15, y: currentY, width: Layout.contentWidth - 30, height: 15),
            withAttributes: paymentAttributes
        )
        
        currentY += 25
        
        // Payment status
        let statusText = "Status: \(booking.paymentStatusEnum.rawValue.uppercased())"
        let statusColor = booking.paymentStatusEnum == .paid ? Colors.accent : UIColor.orange
        let statusAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.bodyBold,
            .foregroundColor: statusColor
        ]
        
        statusText.draw(
            in: CGRect(x: Layout.margin + 15, y: currentY, width: Layout.contentWidth - 30, height: 15),
            withAttributes: statusAttributes
        )
        
        return currentY + 35
    }
    
    // MARK: - Signature Section
    private static func drawSignatureSection(
        context: CGContext,
        signatureData: Data,
        signatureDate: Date?,
        startY: CGFloat
    ) -> CGFloat {
        
        var currentY = startY
        
        currentY = drawSectionHeader(context: context, title: "CUSTOMER SIGNATURE", y: currentY)
        
        if let signatureImage = UIImage(data: signatureData) {
            let signatureRect = CGRect(
                x: Layout.margin,
                y: currentY,
                width: 300,
                height: 100
            )
            
            // Background for signature
            context.setFillColor(UIColor.white.cgColor)
            context.fill(signatureRect)
            context.setStrokeColor(Colors.secondary.cgColor)
            context.setLineWidth(1)
            context.stroke(signatureRect)
            
            // Draw signature
            signatureImage.draw(in: signatureRect)
            
            // Signature date
            if let date = signatureDate {
                let dateFormatter = DateFormatter()
                dateFormatter.dateStyle = .medium
                dateFormatter.timeStyle = .short
                
                let dateText = "Signed on: \(dateFormatter.string(from: date))"
                let dateAttributes: [NSAttributedString.Key: Any] = [
                    .font: Fonts.caption,
                    .foregroundColor: Colors.secondary
                ]
                
                dateText.draw(
                    in: CGRect(x: Layout.margin, y: currentY + 110, width: 300, height: 15),
                    withAttributes: dateAttributes
                )
                
                currentY += 125
            } else {
                currentY += 110
            }
        }
        
        return currentY
    }
    
    // MARK: - QR Code
    private static func drawQRCode(
        context: CGContext,
        booking: CDBooking,
        startY: CGFloat
    ) -> CGFloat {
        
        let qrData = "MOTELR-\(booking.id.uuidString)-\(booking.room.number)-\(booking.customerName.replacingOccurrences(of: " ", with: ""))"
        
        if let qrImage = generateQRCode(from: qrData) {
            let qrSize: CGFloat = 80
            let qrRect = CGRect(
                x: Layout.pageWidth - Layout.margin - qrSize - 20,
                y: startY,
                width: qrSize,
                height: qrSize
            )
            
            qrImage.draw(in: qrRect)
            
            let qrLabel = "Scan for verification"
            let qrLabelAttributes: [NSAttributedString.Key: Any] = [
                .font: Fonts.caption,
                .foregroundColor: Colors.secondary
            ]
            
            qrLabel.draw(
                in: CGRect(x: qrRect.minX - 20, y: qrRect.maxY + 5, width: qrSize + 40, height: 15),
                withAttributes: qrLabelAttributes
            )
        }
        
        return startY + 100
    }
    
    // MARK: - Terms Summary
    private static func drawTermsSummary(
        context: CGContext,
        startY: CGFloat
    ) -> CGFloat {
        
        let currentY = startY
        
        let termsText = "By accepting this receipt, guest acknowledges agreement to all terms and conditions of stay."
        let termsAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.caption,
            .foregroundColor: Colors.secondary
        ]
        
        let termsRect = CGRect(
            x: Layout.margin,
            y: currentY,
            width: Layout.contentWidth,
            height: 30
        )
        
        termsText.draw(in: termsRect, withAttributes: termsAttributes)
        
        return currentY + 35
    }
    
    // MARK: - Footer
    private static func drawFooter(
        context: CGContext,
        businessName: String,
        startY: CGFloat
    ) -> CGFloat {
        
        // Footer background
        let footerRect = CGRect(
            x: 0,
            y: startY,
            width: Layout.pageWidth,
            height: Layout.footerHeight
        )
        
        context.setFillColor(Colors.primary.withAlphaComponent(0.1).cgColor)
        context.fill(footerRect)
        
        let thankYouText = "Thank you for choosing \(businessName)!"
        let thankYouAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.sectionHeader,
            .foregroundColor: Colors.primary
        ]
        
        let thankYouSize = thankYouText.size(withAttributes: thankYouAttributes)
        let thankYouRect = CGRect(
            x: Layout.margin + (Layout.contentWidth - thankYouSize.width) / 2,
            y: startY + 15,
            width: thankYouSize.width,
            height: thankYouSize.height
        )
        
        thankYouText.draw(in: thankYouRect, withAttributes: thankYouAttributes)
        
        // Contact info
        let contactText = "For questions or support, please contact the front desk"
        let contactAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.body,
            .foregroundColor: Colors.text
        ]
        
        let contactSize = contactText.size(withAttributes: contactAttributes)
        let contactRect = CGRect(
            x: Layout.margin + (Layout.contentWidth - contactSize.width) / 2,
            y: startY + 40,
            width: contactSize.width,
            height: contactSize.height
        )
        
        contactText.draw(in: contactRect, withAttributes: contactAttributes)
        
        return startY + Layout.footerHeight
    }
    
    // MARK: - Helper Functions
    private static func drawSectionHeader(context: CGContext, title: String, y: CGFloat) -> CGFloat {
        let headerAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.sectionHeader,
            .foregroundColor: Colors.primary
        ]
        
        title.draw(
            in: CGRect(x: Layout.margin, y: y, width: Layout.contentWidth, height: 20),
            withAttributes: headerAttributes
        )
        
        // Underline
        context.setStrokeColor(Colors.primary.cgColor)
        context.setLineWidth(1)
        context.move(to: CGPoint(x: Layout.margin, y: y + 22))
        context.addLine(to: CGPoint(x: Layout.pageWidth - Layout.margin, y: y + 22))
        context.strokePath()
        
        return y + 35
    }
    
    private static func drawDetailRow(context: CGContext, label: String, value: String, y: CGFloat) -> CGFloat {
        let labelAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.bodyBold,
            .foregroundColor: Colors.secondary
        ]
        
        let valueAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.body,
            .foregroundColor: Colors.text
        ]
        
        label.draw(
            in: CGRect(x: Layout.margin + 10, y: y, width: 120, height: 15),
            withAttributes: labelAttributes
        )
        
        value.draw(
            in: CGRect(x: Layout.margin + 140, y: y, width: Layout.contentWidth - 150, height: 15),
            withAttributes: valueAttributes
        )
        
        return y + 20
    }
    
    private static func drawAmountRow(context: CGContext, label: String, amount: Double, y: CGFloat) -> CGFloat {
        let labelAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.body,
            .foregroundColor: Colors.text
        ]
        
        let amountAttributes: [NSAttributedString.Key: Any] = [
            .font: Fonts.amount,
            .foregroundColor: Colors.text
        ]
        
        label.draw(
            in: CGRect(x: Layout.margin + 15, y: y, width: 200, height: 15),
            withAttributes: labelAttributes
        )
        
        let amountString = String(format: "$%.2f", amount)
        let amountSize = amountString.size(withAttributes: amountAttributes)
        amountString.draw(
            in: CGRect(
                x: Layout.pageWidth - Layout.margin - amountSize.width - 15,
                y: y,
                width: amountSize.width,
                height: 15
            ),
            withAttributes: amountAttributes
        )
        
        return y + 20
    }
    
    private static func drawInfoRow(
        context: CGContext,
        label: String,
        value: String,
        y: CGFloat,
        labelFont: UIFont,
        valueFont: UIFont
    ) {
        let labelAttributes: [NSAttributedString.Key: Any] = [
            .font: labelFont,
            .foregroundColor: Colors.secondary
        ]
        
        let valueAttributes: [NSAttributedString.Key: Any] = [
            .font: valueFont,
            .foregroundColor: Colors.text
        ]
        
        label.draw(
            in: CGRect(x: Layout.margin + 10, y: y, width: 100, height: 15),
            withAttributes: labelAttributes
        )
        
        value.draw(
            in: CGRect(x: Layout.margin + 120, y: y, width: Layout.contentWidth - 130, height: 15),
            withAttributes: valueAttributes
        )
    }
    
    private static func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                let context = CIContext()
                if let cgImage = context.createCGImage(output, from: output.extent) {
                    return UIImage(cgImage: cgImage)
                }
            }
        }
        
        return nil
    }
}

// MARK: - Receipt Style Enum
enum ReceiptStyle {
    case modern
    case classic
    case minimal
    case luxury
}

