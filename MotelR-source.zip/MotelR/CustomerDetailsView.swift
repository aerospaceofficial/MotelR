//  CustomerDetailsView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import UIKit
import CoreImage
import CoreImage.CIFilterBuiltins

// MARK: - Design Tokens (private to this file)

private let kPrimary      = Color(red: 0.18, green: 0.27, blue: 0.90)
private let kPrimaryDark  = Color(red: 0.05, green: 0.12, blue: 0.65)
private let kGold         = Color(red: 0.96, green: 0.65, blue: 0.14)
private let kGreen        = Color(red: 0.20, green: 0.78, blue: 0.35)
private let kRed          = Color(red: 1.0,  green: 0.23, blue: 0.19)

// MARK: - DetailCard (used across this file)

struct DetailCard: View {
    let title: String
    let content: String
    let icon: String
    let color: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .foregroundColor(color)
                .frame(width: 32, height: 32)
                .background(color.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 8))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
                    .textCase(.uppercase)
                Text(content)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundColor(.primary)
            }
            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.04), radius: 4, x: 0, y: 2)
    }
}

// MARK: - CustomerDetailsView

struct CustomerDetailsView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.presentationMode) var presentationMode

    // Core booking (most recent for this customer)
    var booking: CDBooking
    // All bookings from CustomersView if available; falls back to MotelData search
    var allCustomerBookings: [CDBooking]
    var isHistorical: Bool

    // Local init state
    @State private var actualCheckOutDate: Date
    @State private var isHistoricalBooking: Bool

    // Sheets / alerts
    @State private var showShareSheet       = false
    @State private var shareItems: [Any]    = []
    @State private var isGeneratingPDF      = false
    @State private var showingImage         = false
    @State private var showingReactivationAlert = false
    @State private var showingErrorAlert    = false
    @State private var showingIncidentForm  = false
    @State private var showingPaymentEditor = false
    @State private var showingPaymentConfirmation = false
    @State private var showingBusinessNameEditor  = false
    @State private var tempBusinessName           = ""
    @State private var updatedAmount: Double      = 0.0
    @State private var updatedTaxStatus: Bool     = false
    @State private var customerIncidents: [CDIncidentReport] = []

    // License full-screen
    @State private var showingFullLicense = false

    init(booking: CDBooking, allCustomerBookings: [CDBooking] = [], isHistorical: Bool = false) {
        self.booking              = booking
        self.allCustomerBookings  = allCustomerBookings
        self.isHistorical         = isHistorical
        _actualCheckOutDate       = State(initialValue: booking.checkOutDate)
        _isHistoricalBooking      = State(initialValue: isHistorical)
    }

    // MARK: - Derived

    private var allBookings: [CDBooking] {
        if !allCustomerBookings.isEmpty { return allCustomerBookings }
        let key = booking.drivingLicenseNumber
        return (motelData.bookings + motelData.history)
            .filter { $0.drivingLicenseNumber == key }
            .sorted { $0.checkInDate > $1.checkInDate }
    }

    private var totalStays: Int      { allBookings.count }
    private var totalNights: Int     { allBookings.map { Int($0.numberOfDays) }.reduce(0, +) }
    private var avgStay: Double      { totalStays > 0 ? Double(totalNights) / Double(totalStays) : 0 }
    private var totalRevenue: Double { allBookings.reduce(0) { $0 + $1.prizeAmount } }

    private var firstVisit: Date? { allBookings.min(by: { $0.checkInDate < $1.checkInDate })?.checkInDate }
    private var lastVisit: Date?  { allBookings.max(by: { $0.checkInDate < $1.checkInDate })?.checkInDate }

    private var isVIP: Bool { totalStays >= 3 }

    private var licenseImage: UIImage? {
        booking.licensePhotoData.flatMap { UIImage(data: $0) }
    }

    // MARK: - Body

    @ViewBuilder private var mainContent: some View {
        heroHeader
        contactInfoCard
        statsCard
        bookingHistorySection
        incidentsSection
        if licenseImage != nil { licensePhotoCard }
        if let sigData = booking.signatureImageData,
           let sigImage = UIImage(data: sigData) {
            signatureCard(sigImage)
        }
        bottomActionButtons
    }

    var body: some View {
        scrollContent
            .sheet(isPresented: $showShareSheet) {
                if !shareItems.isEmpty { SharedActivityView(activityItems: shareItems) }
            }
            .sheet(isPresented: $showingIncidentForm) {
                IncidentFormView()
                    .environmentObject(motelData)
            }
            .sheet(isPresented: $showingPaymentEditor) {
                PaymentEditorView(booking: booking, motelData: motelData,
                    isPresented: $showingPaymentEditor,
                    showConfirmation: $showingPaymentConfirmation,
                    updatedTotalAmount: $updatedAmount, updatedTaxStatus: $updatedTaxStatus)
            }
            .sheet(isPresented: $showingBusinessNameEditor) { businessNameEditorSheet }
            .alert("Confirm Payment Update", isPresented: $showingPaymentConfirmation) {
                Button("Cancel", role: .cancel) {}
                Button("Update") { commitPaymentUpdate() }
            } message: { Text("Update payment to \(String(format: "$%.2f", updatedAmount))?") }
            .alert("Reactivate Booking?", isPresented: $showingReactivationAlert) {
                Button("Cancel", role: .cancel) { actualCheckOutDate = booking.checkOutDate }
                Button("Reactivate") { reactivateBooking() }
            } message: { Text("This will move the booking back to active and mark the room as occupied.") }
            .alert("Room Not Available", isPresented: $showingErrorAlert) {
                Button("OK", role: .cancel) { actualCheckOutDate = booking.checkOutDate }
            } message: { Text("The room is not available for these dates. Please choose different dates.") }
            .onAppear { loadIncidents() }
            .onChange(of: showingIncidentForm) { _, newVal in if !newVal { loadIncidents() } }
    }

    private var scrollContent: some View {
        ScrollView {
            VStack(spacing: 20) { mainContent }
                .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 40)
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Customer Details")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar { toolbarContent }
    }

    // MARK: - Hero Header

    private var heroHeader: some View {
        ZStack(alignment: .bottomLeading) {
            // Gradient background
            LinearGradient(
                colors: [kPrimary, kPrimaryDark],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .cornerRadius(20)
            .frame(maxWidth: .infinity)

            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 16) {
                    // Large avatar
                    ZStack {
                        Circle()
                            .fill(Color.white.opacity(0.18))
                            .frame(width: 72, height: 72)
                        Text(initials(from: booking.customerName))
                            .font(.system(size: 26, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }

                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 8) {
                            Text(booking.customerName)
                                .font(.system(size: 20, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            if isVIP {
                                HStack(spacing: 3) {
                                    Image(systemName: "star.fill")
                                        .font(.system(size: 9, weight: .bold))
                                    Text("VIP")
                                        .font(.system(size: 9, weight: .black, design: .rounded))
                                }
                                .foregroundColor(.white)
                                .padding(.horizontal, 7)
                                .padding(.vertical, 3)
                                .background(kGold)
                                .clipShape(Capsule())
                            }
                        }
                        Text(booking.phoneNumber)
                            .font(.system(size: 14, design: .rounded))
                            .foregroundColor(.white.opacity(0.80))
                        Text("\(totalStays) total \(totalStays == 1 ? "stay" : "stays")")
                            .font(.system(size: 13, weight: .medium, design: .rounded))
                            .foregroundColor(.white.opacity(0.70))
                    }
                    Spacer()
                }

                // Status chips
                HStack(spacing: 8) {
                    chipView(
                        label: isHistoricalBooking ? "Past Guest" : "Active Guest",
                        color: isHistoricalBooking ? .white.opacity(0.60) : kGreen,
                        icon: isHistoricalBooking ? "clock" : "checkmark.circle.fill"
                    )
                    chipView(
                        label: "Room \(booking.room.number)",
                        color: .white.opacity(0.75),
                        icon: "door.left.hand.open"
                    )
                }
            }
            .padding(20)
        }
    }

    private func chipView(label: String, color: Color, icon: String) -> some View {
        HStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 10, weight: .semibold))
            Text(label)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
        }
        .foregroundColor(color)
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .background(Color.white.opacity(0.15))
        .clipShape(Capsule())
    }

    // MARK: - Contact Info Card

    private var contactInfoCard: some View {
        sectionCard(title: "Contact Information", icon: "person.text.rectangle.fill", iconColor: kPrimary) {
            VStack(spacing: 8) {
                DetailCard(title: "Full Name",       content: booking.customerName,         icon: "person.fill",          color: kPrimary)
                DetailCard(title: "Phone",           content: booking.phoneNumber,          icon: "phone.fill",           color: kGreen)
                DetailCard(title: "License Number",  content: booking.drivingLicenseNumber, icon: "creditcard.fill",      color: .purple)
                DetailCard(title: "Address",         content: booking.address,              icon: "house.fill",           color: .orange)
                if !booking.city.isEmpty {
                    DetailCard(title: "City / State / ZIP",
                               content: "\(booking.city), \(booking.state) \(booking.zipCode)",
                               icon: "mappin.circle.fill", color: kRed)
                }
            }
        }
    }

    // MARK: - Stats Card

    private var statsCard: some View {
        sectionCard(title: "Stay Statistics", icon: "chart.bar.fill", iconColor: kGreen) {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                statTile(value: "\(totalStays)",
                         label: "Total Stays",
                         icon: "bed.double.fill",
                         color: kPrimary)
                statTile(value: "\(totalNights)",
                         label: "Total Nights",
                         icon: "moon.stars.fill",
                         color: .indigo)
                statTile(value: String(format: "$%.0f", totalRevenue),
                         label: "Revenue Paid",
                         icon: "dollarsign.circle.fill",
                         color: kGreen)
                statTile(value: String(format: "%.1f nights", avgStay),
                         label: "Avg Stay",
                         icon: "calendar.badge.clock",
                         color: .orange)
            }
            if let first = firstVisit, let last = lastVisit {
                Divider().padding(.vertical, 4)
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("First Visit")
                            .font(.system(size: 11, design: .rounded))
                            .foregroundColor(.secondary)
                        Text(formatDate(first))
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Last Visit")
                            .font(.system(size: 11, design: .rounded))
                            .foregroundColor(.secondary)
                        Text(formatDate(last))
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                    }
                }
                .padding(.horizontal, 4)
            }
        }
    }

    private func statTile(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
            Text(label)
                .font(.system(size: 11, design: .rounded))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(14)
        .background(color.opacity(0.08))
        .cornerRadius(14)
    }

    // MARK: - Booking History Section

    private var bookingHistorySection: some View {
        sectionCard(title: "Booking History", icon: "calendar.badge.clock", iconColor: .purple) {
            if allBookings.isEmpty {
                emptyRow(message: "No bookings found.")
            } else {
                VStack(spacing: 10) {
                    ForEach(allBookings, id: \.id) { b in
                        BookingHistoryCard(booking: b)
                    }
                }
            }
        }
    }

    // MARK: - Incidents Section

    private var incidentsSection: some View {
        sectionCard(title: "Incident History", icon: "exclamationmark.triangle.fill", iconColor: kRed) {
            HStack {
                Spacer()
                Button(action: { showingIncidentForm = true }) {
                    Label("Report Incident", systemImage: "plus.circle.fill")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundColor(kPrimary)
                }
            }
            .padding(.bottom, 4)

            if customerIncidents.isEmpty {
                emptyRow(message: "No incidents reported for this guest.")
            } else {
                VStack(spacing: 10) {
                    ForEach(customerIncidents, id: \.id) { incident in
                        IncidentRowCard(incident: incident)
                    }
                }
            }
        }
    }

    // MARK: - License Photo Card

    private var licensePhotoCard: some View {
        sectionCard(title: "License Photo", icon: "creditcard.and.123", iconColor: .teal) {
            if let img = licenseImage {
                Button(action: { showingFullLicense = true }) {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 180)
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color(.systemGray4), lineWidth: 1)
                        )
                }
                .sheet(isPresented: $showingFullLicense) {
                    ZStack {
                        Color.black.ignoresSafeArea()
                        VStack {
                            HStack {
                                Spacer()
                                Button("Done") { showingFullLicense = false }
                                    .foregroundColor(.white)
                                    .font(.system(size: 16, weight: .semibold))
                                    .padding()
                            }
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFit()
                                .padding()
                            Spacer()
                        }
                    }
                }
            }
        }
    }

    // MARK: - Signature Card

    private func signatureCard(_ signatureImage: UIImage) -> some View {
        sectionCard(title: "Customer Signature", icon: "signature", iconColor: .teal) {
            VStack(alignment: .leading, spacing: 10) {
                Image(uiImage: signatureImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 110)
                    .background(Color.white)
                    .cornerRadius(8)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color(.systemGray4), lineWidth: 1)
                    )
                if let signatureDate = booking.signatureDate {
                    DetailCard(title: "Signed On", content: formatDate(signatureDate),
                               icon: "calendar", color: kGreen)
                }
                if let termsVersion = booking.termsVersion {
                    DetailCard(title: "Terms Version", content: termsVersion,
                               icon: "doc.text", color: kPrimary)
                }
            }
        }
    }

    // MARK: - Bottom Action Buttons

    private var bottomActionButtons: some View {
        VStack(spacing: 10) {
            if !isHistoricalBooking {
                Button(action: { showingPaymentEditor = true }) {
                    Label("Update Payment", systemImage: "dollarsign.circle.fill")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(kGreen)
                        .foregroundColor(.white)
                        .cornerRadius(14)
                }
            }
            Button(action: generateAndShare) {
                HStack(spacing: 8) {
                    if isGeneratingPDF {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .scaleEffect(0.85)
                    } else {
                        Image(systemName: "square.and.arrow.up")
                    }
                    Text(isGeneratingPDF ? "Generating Receipt..." : "Share Receipt / Details")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    LinearGradient(colors: [kPrimary, kPrimaryDark],
                                   startPoint: .leading, endPoint: .trailing)
                )
                .foregroundColor(.white)
                .cornerRadius(14)
            }
            .disabled(isGeneratingPDF)
        }
    }

    // MARK: - Toolbar

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .navigationBarTrailing) {
            Button(action: generateAndShare) {
                if isGeneratingPDF {
                    ProgressView()
                        .progressViewStyle(CircularProgressViewStyle(tint: kPrimary))
                        .scaleEffect(0.85)
                } else {
                    Image(systemName: "square.and.arrow.up")
                        .font(.system(size: 15, weight: .semibold))
                }
            }
            .disabled(isGeneratingPDF)
        }
    }

    // MARK: - Business Name Editor Sheet

    private var businessNameEditorSheet: some View {
        NavigationView {
            Form {
                Section(header: Text("Business Name")) {
                    TextField("Enter Business Name", text: $tempBusinessName)
                        .autocapitalization(.words)
                    Text("Appears on all receipts and documents.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Edit Business Name")
            .navigationBarItems(
                leading: Button("Cancel") { showingBusinessNameEditor = false },
                trailing: Button("Save") {
                    if !tempBusinessName.isEmpty { motelData.businessName = tempBusinessName }
                    showingBusinessNameEditor = false
                }
            )
        }
        .presentationDetents([.height(200)])
    }

    // MARK: - Helpers

    private func sectionCard<Content: View>(title: String, icon: String, iconColor: Color, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(iconColor)
                Text(title)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)
            }
            content()
        }
        .padding(16)
        .background(Color(.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }

    private func emptyRow(message: String) -> some View {
        Text(message)
            .font(.system(size: 14, design: .rounded))
            .foregroundColor(.secondary)
            .frame(maxWidth: .infinity, alignment: .center)
            .padding(.vertical, 10)
    }

    private func formatDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateStyle = .medium
        return f.string(from: date)
    }

    private func initials(from name: String) -> String {
        let parts = name.split(separator: " ")
        let f = parts.first?.prefix(1) ?? ""
        let l = parts.dropFirst().last?.prefix(1) ?? ""
        return "\(f)\(l)".uppercased()
    }

    private func loadIncidents() {
        customerIncidents = motelData.getIncidentsForCustomer(withID: booking.drivingLicenseNumber)
    }

    private func reactivateBooking() {
        booking.checkOutDate = actualCheckOutDate
        if motelData.reactivateBooking(booking) {
            isHistoricalBooking = false
            presentationMode.wrappedValue.dismiss()
        } else {
            showingErrorAlert = true
        }
    }

    private func commitPaymentUpdate() {
        guard updatedAmount > 0 else { return }
        booking.prize  = String(format: "$%.2f", updatedAmount)
        booking.isTaxed = updatedTaxStatus
        CoreDataManager.shared.save()
        motelData.fetchAllData()
    }

    private func generateAndShare() {
        // Rendered on the main queue: the booking belongs to the view context and
        // must not be read from a background thread.
        isGeneratingPDF = true
        let pdf = generatePDF()
        isGeneratingPDF = false
        shareItems = [pdf]
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            showShareSheet = true
        }
    }

    // MARK: - PDF Generation

    private func generatePDF() -> Data {
        let pageW: CGFloat = 8.5 * 72
        let pageH: CGFloat = 11  * 72
        let margin: CGFloat = 54
        let cW = pageW - 2 * margin

        let primaryUI = UIColor(red: 0.18, green: 0.27, blue: 0.90, alpha: 1)
        let accentUI  = UIColor(red: 0.20, green: 0.78, blue: 0.35, alpha: 1)
        let grayUI    = UIColor(red: 0.40, green: 0.40, blue: 0.40, alpha: 1)
        let lightBG   = UIColor(red: 0.96, green: 0.96, blue: 0.97, alpha: 1)

        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageW, height: pageH))

        return renderer.pdfData { ctx in
            ctx.beginPage()
            var y: CGFloat = margin

            func text(_ s: String, font: UIFont, color: UIColor = .black, x: CGFloat, atY: CGFloat, width: CGFloat = 0) {
                let attr: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color]
                s.draw(in: CGRect(x: x, y: atY, width: width > 0 ? width : cW, height: 200), withAttributes: attr)
            }

            func lineHeight(_ s: String, font: UIFont) -> CGFloat {
                (s as NSString).size(withAttributes: [.font: font]).height
            }

            // Header block
            let headerRect = CGRect(x: 0, y: 0, width: pageW, height: 70)
            ctx.cgContext.setFillColor(primaryUI.cgColor)
            ctx.cgContext.fill(headerRect)
            let bizFont = UIFont.boldSystemFont(ofSize: 22)
            text(motelData.businessName, font: bizFont, color: .white, x: margin, atY: 18)
            text("OFFICIAL RECEIPT", font: UIFont.boldSystemFont(ofSize: 11), color: UIColor.white.withAlphaComponent(0.75), x: margin, atY: 44)
            y = 90

            // Receipt meta box
            let metaItems: [(String, String)] = [
                ("Receipt #:", String(booking.id.uuidString.prefix(8).uppercased())),
                ("Date:",      DateFormatter.localizedString(from: Date(), dateStyle: .full, timeStyle: .short)),
                ("Room:",      "Room \(booking.room.number)"),
                ("Guest ID:",  booking.drivingLicenseNumber)
            ]
            let metaH = CGFloat(metaItems.count * 20 + 20)
            ctx.cgContext.setFillColor(lightBG.cgColor)
            ctx.cgContext.fill(CGRect(x: margin, y: y, width: cW, height: metaH))
            var my = y + 10
            for (lbl, val) in metaItems {
                text(lbl, font: UIFont.boldSystemFont(ofSize: 10), color: grayUI, x: margin + 8, atY: my, width: 120)
                text(val, font: UIFont.systemFont(ofSize: 10), x: margin + 130, atY: my, width: cW - 140)
                my += 20
            }
            y = my + 16

            // Section helper
            func section(_ title: String) {
                let f = UIFont.boldSystemFont(ofSize: 13)
                text(title, font: f, color: primaryUI, x: margin, atY: y)
                y += lineHeight(title, font: f) + 4
                ctx.cgContext.setStrokeColor(primaryUI.withAlphaComponent(0.4).cgColor)
                ctx.cgContext.setLineWidth(1)
                ctx.cgContext.move(to: CGPoint(x: margin, y: y))
                ctx.cgContext.addLine(to: CGPoint(x: pageW - margin, y: y))
                ctx.cgContext.strokePath()
                y += 10
            }

            func row(_ lbl: String, _ val: String) {
                text(lbl, font: UIFont.boldSystemFont(ofSize: 10), color: grayUI, x: margin + 8, atY: y, width: 120)
                text(val, font: UIFont.systemFont(ofSize: 10), x: margin + 130, atY: y, width: cW - 140)
                y += 18
            }

            section("CUSTOMER INFORMATION")
            row("Name:",        booking.customerName)
            row("Phone:",       booking.phoneNumber)
            row("Address:",     "\(booking.address), \(booking.city), \(booking.state) \(booking.zipCode)")
            row("License #:",   booking.drivingLicenseNumber)
            y += 8

            section("BOOKING DETAILS")
            let df = DateFormatter(); df.dateStyle = .medium
            row("Check-in:",  df.string(from: booking.checkInDate))
            row("Check-out:", df.string(from: booking.checkOutDate))
            row("Duration:",  "\(booking.numberOfDays) night\(booking.numberOfDays == 1 ? "" : "s")")
            row("Room:",      "Room \(booking.room.number)")
            y += 8

            section("PAYMENT SUMMARY")
            let amt = booking.prizeAmount
            if booking.isTaxed {
                let base = amt / (1 + motelData.taxRate)
                let tax  = amt - base
                row("Base Amount:", String(format: "$%.2f", base))
                row("Tax (\(String(format: "%.1f", motelData.taxRate * 100))%):", String(format: "$%.2f", tax))
            }
            // Total highlight
            let totalRect = CGRect(x: margin, y: y, width: cW, height: 24)
            ctx.cgContext.setFillColor(accentUI.withAlphaComponent(0.10).cgColor)
            ctx.cgContext.fill(totalRect)
            text("TOTAL:", font: UIFont.boldSystemFont(ofSize: 13), color: accentUI, x: margin + 8, atY: y + 4)
            let totalStr = String(format: "$%.2f", amt)
            let ts = (totalStr as NSString).size(withAttributes: [.font: UIFont.boldSystemFont(ofSize: 13)])
            text(totalStr, font: UIFont.boldSystemFont(ofSize: 13), color: accentUI, x: pageW - margin - ts.width - 8, atY: y + 4)
            y += 30
            row("Payment Method:", booking.paymentMethodEnum.rawValue)
            row("Status:", booking.paymentStatusEnum.rawValue.uppercased())
            y += 8

            // Signature block
            if let sigData = booking.signatureImageData, let sigImg = UIImage(data: sigData) {
                section("CUSTOMER SIGNATURE")
                let sigRect = CGRect(x: margin, y: y, width: 260, height: 80)
                ctx.cgContext.setFillColor(UIColor.white.cgColor)
                ctx.cgContext.fill(sigRect)
                ctx.cgContext.setStrokeColor(grayUI.withAlphaComponent(0.4).cgColor)
                ctx.cgContext.setLineWidth(0.5)
                ctx.cgContext.stroke(sigRect)
                sigImg.draw(in: sigRect)
                y = sigRect.maxY + 8
            }

            // Footer
            let footY = pageH - 50
            ctx.cgContext.setFillColor(primaryUI.withAlphaComponent(0.07).cgColor)
            ctx.cgContext.fill(CGRect(x: 0, y: footY, width: pageW, height: 50))
            let thankFont = UIFont.boldSystemFont(ofSize: 12)
            let thankStr  = "Thank you for choosing \(motelData.businessName)!"
            let thankSize = (thankStr as NSString).size(withAttributes: [.font: thankFont])
            text(thankStr, font: thankFont, color: primaryUI, x: (pageW - thankSize.width) / 2, atY: footY + 10, width: thankSize.width + 10)
            let capFont = UIFont.systemFont(ofSize: 9)
            let capStr  = "For questions, please contact the front desk"
            let capSize = (capStr as NSString).size(withAttributes: [.font: capFont])
            text(capStr, font: capFont, color: grayUI, x: (pageW - capSize.width) / 2, atY: footY + 28, width: capSize.width + 10)
        }
    }
}

// MARK: - BookingHistoryCard

struct BookingHistoryCard: View {
    let booking: CDBooking
    @State private var isExpanded = false

    private var primaryColor: Color { Color(red: 0.18, green: 0.27, blue: 0.90) }
    private var greenColor: Color   { Color(red: 0.20, green: 0.78, blue: 0.35) }
    private var redColor: Color     { Color(red: 1.0, green: 0.23, blue: 0.19) }

    private var dateRange: String {
        let f = DateFormatter(); f.dateStyle = .short
        return "\(f.string(from: booking.checkInDate)) → \(f.string(from: booking.checkOutDate))"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button(action: { withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) { isExpanded.toggle() } }) {
                HStack(spacing: 12) {
                    // Room badge
                    Text("Rm \(booking.room.number)")
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(booking.isHistory ? Color(.systemGray3) : primaryColor)
                        .clipShape(Capsule())

                    VStack(alignment: .leading, spacing: 2) {
                        Text(dateRange)
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundColor(.primary)
                        Text("\(booking.numberOfDays) nights  •  \(booking.prize)")
                            .font(.system(size: 11, design: .rounded))
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                    // Payment status badge
                    Text(booking.paymentStatusEnum.rawValue)
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundColor(booking.paymentStatusEnum == .paid ? greenColor : .orange)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background((booking.paymentStatusEnum == .paid ? greenColor : Color.orange).opacity(0.12))
                        .clipShape(Capsule())

                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.secondary)
                }
                .padding(12)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(12)
            }
            .buttonStyle(.plain)

            if isExpanded {
                VStack(alignment: .leading, spacing: 6) {
                    Divider()
                    infoRow("Payment Method", booking.paymentMethodEnum.rawValue)
                    infoRow("Tax Applied",    booking.isTaxed ? "Yes" : "No")
                    if let card = booking.cardType, !card.isEmpty      { infoRow("Card Type", card) }
                    if let check = booking.checkNumber, !check.isEmpty  { infoRow("Check #", check) }
                    if let org = booking.organizationName, !org.isEmpty { infoRow("Organization", org) }
                }
                .padding(.horizontal, 14)
                .padding(.bottom, 10)
                .background(Color(.secondarySystemBackground))
                .cornerRadius(12)
            }
        }
    }

    private func infoRow(_ lbl: String, _ val: String) -> some View {
        HStack {
            Text(lbl)
                .font(.system(size: 12, design: .rounded))
                .foregroundColor(.secondary)
            Spacer()
            Text(val)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundColor(.primary)
        }
    }
}

// MARK: - IncidentRowCard

struct IncidentRowCard: View {
    let incident: CDIncidentReport

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: incident.severityLevel.icon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(incident.severityLevel.color)
                Text(incident.severityLevel.rawValue)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundColor(incident.severityLevel.color)
                Spacer()
                Text(DateFormatter.localizedString(from: incident.incidentDate, dateStyle: .medium, timeStyle: .none))
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
                if incident.isResolved {
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 13))
                        .foregroundColor(Color(red: 0.20, green: 0.78, blue: 0.35))
                }
            }
            Text(incident.incidentDescription)
                .font(.system(size: 13, design: .rounded))
                .foregroundColor(.primary)
                .lineLimit(3)
            if incident.isResolved {
                Text("Resolved")
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.20, green: 0.78, blue: 0.35))
            }
        }
        .padding(12)
        .background(incident.severityLevel.color.opacity(0.06))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(incident.severityLevel.color.opacity(0.20), lineWidth: 1)
        )
    }
}

// MARK: - Supporting Views (PaymentEditorView, ShareManager, etc.)

class ShareManager: ObservableObject {
    @Published var isPresenting = false
    @Published var shareItems: [Any] = []

    func share(items: [Any]) {
        DispatchQueue.main.async {
            self.shareItems = items
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { self.isPresenting = true }
        }
    }
}

struct PaymentEditorView: View {
    let booking: CDBooking
    let motelData: MotelData
    @Binding var isPresented: Bool
    @Binding var showConfirmation: Bool
    @Binding var updatedTotalAmount: Double
    @Binding var updatedTaxStatus: Bool

    @State private var additionalAmount = ""
    @State private var isTaxed: Bool
    @State private var newTotalAmount: Double = 0.0

    init(booking: CDBooking, motelData: MotelData,
         isPresented: Binding<Bool>, showConfirmation: Binding<Bool>,
         updatedTotalAmount: Binding<Double>, updatedTaxStatus: Binding<Bool>) {
        self.booking = booking; self.motelData = motelData
        self._isPresented = isPresented; self._showConfirmation = showConfirmation
        self._updatedTotalAmount = updatedTotalAmount; self._updatedTaxStatus = updatedTaxStatus
        self._isTaxed = State(initialValue: booking.isTaxed)
        self._newTotalAmount = State(initialValue: booking.prizeAmount)
    }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Current Payment")) {
                    HStack {
                        Text("Current Amount:")
                        Spacer()
                        Text(booking.prize).bold()
                    }
                    if booking.isTaxed {
                        Text("Tax Rate: \(String(format: "%.1f", motelData.taxRate * 100))%")
                    }
                }
                Section(header: Text("Additional Amount")) {
                    HStack {
                        Text("$")
                        TextField("0.00", text: $additionalAmount)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                    }
                    Toggle("Apply Tax", isOn: $isTaxed)
                }
                Section(header: Text("New Total")) {
                    HStack {
                        Text("New Total Amount:")
                        Spacer()
                        Text("$\(newTotalAmount, specifier: "%.2f")").bold().foregroundColor(.blue)
                    }
                }
                Button("Update Payment") {
                    updatedTotalAmount = newTotalAmount
                    updatedTaxStatus   = isTaxed
                    isPresented        = false
                    showConfirmation   = true
                }
                .frame(maxWidth: .infinity)
                .multilineTextAlignment(.center)
            }
            .navigationTitle("Update Payment")
            .navigationBarItems(trailing: Button("Cancel") { isPresented = false })
            .onChange(of: additionalAmount) { _, _ in recalculate() }
            .onChange(of: isTaxed)         { _, _ in recalculate() }
        }
    }

    private func recalculate() {
        let base  = booking.prizeAmount
        let extra = Double(additionalAmount) ?? 0
        newTotalAmount = base + (isTaxed ? extra * (1 + motelData.taxRate) : extra)
    }
}

// MARK: - Date formatter (shared within file)

private let shortDateFormatter: DateFormatter = {
    let f = DateFormatter(); f.dateStyle = .short; return f
}()

// MARK: - Preview

struct CustomerDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        let ctx     = CoreDataManager.shared.context
        let room    = CDRoom(context: ctx, number: 101, name: "Standard", members: "2")
        let booking = CDBooking(context: ctx, room: room, customerName: "Jane Smith",
                                phoneNumber: "555-123-4567", drivingLicenseNumber: "IL12345",
                                address: "100 Oak St", city: "Chicago", state: "IL", zipCode: "60601",
                                licenseImageFileName: nil, paymentMethodEnum: .card,
                                cardType: "Visa", checkNumber: nil, organizationName: nil,
                                prize: "$150.00", numberOfDays: 2, checkInDate: Date(),
                                checkOutDate: Date().addingTimeInterval(2 * 86400), isTaxed: true)
        return NavigationView {
            CustomerDetailsView(booking: booking, allCustomerBookings: [booking], isHistorical: false)
                .environmentObject(MotelData())
        }
    }
}
