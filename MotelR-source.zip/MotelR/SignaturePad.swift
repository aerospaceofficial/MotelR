import SwiftUI
import UIKit

// MARK: - Full Screen Signature View
struct FullScreenSignatureView: View {
    @Binding var signatureImage: UIImage?
    @Binding var hasSignature: Bool
    @Binding var isPresented: Bool
    let customerName: String
    
    @State private var currentSignatureImage: UIImage?
    @State private var showingBackAlert = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Background
                Color.white
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Top instruction bar
                    topInstructionBar
                    
                    // Full screen signature canvas
                    FullScreenSignatureCanvas(
                        signatureImage: $currentSignatureImage,
                        hasSignature: .constant(currentSignatureImage != nil)
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.white)
                    
                    // Bottom action bar
                    bottomActionBar
                }
            }
        }
        .navigationBarHidden(true)
        .statusBarHidden(true) // Hide status bar for full screen experience
        .onAppear {
            currentSignatureImage = signatureImage
        }
        .alert("Discard Signature?", isPresented: $showingBackAlert) {
            Button("Keep Editing", role: .cancel) { }
            Button("Discard", role: .destructive) {
                currentSignatureImage = nil
                isPresented = false
            }
        } message: {
            Text("Are you sure you want to go back? Your signature will be lost.")
        }
    }
    
    private var topInstructionBar: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Digital Signature")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Spacer()
                
                Text("for \(customerName)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Text("Please sign in the area below using your finger")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(Color(UIColor.systemGray6))
    }
    
    private var bottomActionBar: some View {
        HStack(spacing: 20) {
            // Back Button
            Button(action: {
                if currentSignatureImage != nil {
                    showingBackAlert = true
                } else {
                    isPresented = false
                }
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color(UIColor.systemGray5))
                .foregroundColor(.primary)
                .cornerRadius(12)
            }
            
            // Clear Button
            Button(action: {
                currentSignatureImage = nil
            }) {
                HStack {
                    Image(systemName: "trash")
                    Text("Clear")
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.red.opacity(0.1))
                .foregroundColor(.red)
                .cornerRadius(12)
            }
            .disabled(currentSignatureImage == nil)
            .opacity(currentSignatureImage == nil ? 0.5 : 1.0)
            
            // Submit Button
            Button(action: {
                if let signature = currentSignatureImage {
                    signatureImage = signature
                    hasSignature = true
                    isPresented = false
                }
            }) {
                HStack {
                    Image(systemName: "checkmark")
                    Text("Submit")
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(currentSignatureImage != nil ? Color.green : Color(UIColor.systemGray5))
                .foregroundColor(currentSignatureImage != nil ? .white : .secondary)
                .cornerRadius(12)
            }
            .disabled(currentSignatureImage == nil)
        }
        .padding()
        .background(Color(UIColor.systemGray6))
    }
}

// MARK: - Full Screen Signature Canvas
struct FullScreenSignatureCanvas: UIViewRepresentable {
    @Binding var signatureImage: UIImage?
    @Binding var hasSignature: Bool
    
    func makeUIView(context: Context) -> FullScreenCanvasView {
        let canvas = FullScreenCanvasView()
        canvas.delegate = context.coordinator
        return canvas
    }
    
    func updateUIView(_ uiView: FullScreenCanvasView, context: Context) {
        // Handle external clear
        if signatureImage == nil && uiView.hasSignature {
            uiView.clearSignature()
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, FullScreenCanvasDelegate {
        let parent: FullScreenSignatureCanvas
        
        init(_ parent: FullScreenSignatureCanvas) {
            self.parent = parent
        }
        
        func signatureUpdated(_ image: UIImage?) {
            DispatchQueue.main.async {
                self.parent.signatureImage = image
                self.parent.hasSignature = image != nil
            }
        }
    }
}

// MARK: - Full Screen Canvas Delegate
protocol FullScreenCanvasDelegate: AnyObject {
    func signatureUpdated(_ image: UIImage?)
}

// MARK: - Full Screen Canvas View
class FullScreenCanvasView: UIView {
    weak var delegate: FullScreenCanvasDelegate?
    
    private var path = UIBezierPath()
    private var previousPoint = CGPoint.zero
    private var strokeWidth: CGFloat = 4.0
    private var strokeColor = UIColor.black
    var hasSignature = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        backgroundColor = UIColor.white
        isMultipleTouchEnabled = false
        
        // Add a subtle border to show the drawing area
        layer.borderColor = UIColor.systemGray4.cgColor
        layer.borderWidth = 1
        
        // Add instruction overlay
        addInstructionOverlay()
    }
    
    private func addInstructionOverlay() {
        let instructionLabel = UILabel()
        instructionLabel.text = "Touch and drag to sign here"
        instructionLabel.textAlignment = .center
        instructionLabel.font = UIFont.systemFont(ofSize: 24, weight: .light)
        instructionLabel.textColor = UIColor.systemGray3
        instructionLabel.tag = 999
        
        addSubview(instructionLabel)
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            instructionLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            instructionLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    private func removeInstructionOverlay() {
        if let label = viewWithTag(999) {
            UIView.animate(withDuration: 0.3) {
                label.alpha = 0
            } completion: { _ in
                label.removeFromSuperview()
            }
        }
    }
    
    override func draw(_ rect: CGRect) {
        // Draw the signature path
        strokeColor.setStroke()
        path.lineWidth = strokeWidth
        path.lineCapStyle = .round
        path.lineJoinStyle = .round
        path.stroke()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        // Remove instruction overlay on first touch
        removeInstructionOverlay()
        
        previousPoint = touch.location(in: self)
        path.move(to: previousPoint)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let currentPoint = touch.location(in: self)
        
        // Calculate midpoint for smoother lines
        let midPoint = CGPoint(
            x: (currentPoint.x + previousPoint.x) / 2,
            y: (currentPoint.y + previousPoint.y) / 2
        )
        
        // Draw smooth curve
        path.addQuadCurve(to: midPoint, controlPoint: previousPoint)
        previousPoint = currentPoint
        
        setNeedsDisplay()
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        
        let currentPoint = touch.location(in: self)
        path.addLine(to: currentPoint)
        
        hasSignature = true
        
        // Generate and send the signature image
        let signatureImage = generateSignatureImage()
        delegate?.signatureUpdated(signatureImage)
        
        setNeedsDisplay()
    }
    
    func clearSignature() {
        path.removeAllPoints()
        hasSignature = false
        
        // Re-add instruction overlay
        addInstructionOverlay()
        
        setNeedsDisplay()
        delegate?.signatureUpdated(nil)
    }
    
    private func generateSignatureImage() -> UIImage? {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { context in
            // White background
            UIColor.white.setFill()
            context.fill(bounds)
            
            // Draw the signature
            strokeColor.setStroke()
            path.lineWidth = strokeWidth
            path.stroke()
        }
    }
}

// MARK: - Updated Signature Step View
struct SignatureStepView: View {
    @Binding var signatureImage: UIImage?
    @Binding var hasSignature: Bool
    let customerName: String
    
    @StateObject private var termsManager = TermsAndConditionsManager.shared
    @State private var showingFullScreenSignature = false
    
    var body: some View {
        VStack(spacing: 20) {
            // Header
            VStack(spacing: 8) {
                Image(systemName: "signature")
                    .font(.system(size: 40))
                    .foregroundColor(.blue)
                
                Text("Terms & Conditions")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text("Please review and sign below")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            // Terms and Conditions Text
            ScrollView {
                Text(termsManager.currentTerms)
                    .font(.system(size: 12))
                    .padding()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(UIColor.systemGray6))
                    .cornerRadius(12)
            }
            .frame(height: 200)
            
            // Customer Info
            VStack(alignment: .leading, spacing: 8) {
                Text("Customer Information")
                    .font(.headline)
                
                HStack {
                    Text("Name:")
                        .fontWeight(.medium)
                    Text(customerName)
                    Spacer()
                    Text("Date:")
                        .fontWeight(.medium)
                    Text(Date(), style: .date)
                }
                .padding()
                .background(Color(UIColor.systemBackground))
                .cornerRadius(8)
            }
            
            // Signature Section
            VStack(alignment: .leading, spacing: 16) {
                Text("Customer Signature")
                    .font(.headline)
                
                if hasSignature {
                    // Show captured signature
                    VStack(spacing: 12) {
                        if let signatureImage = signatureImage {
                            Image(uiImage: signatureImage)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 100)
                                .background(Color.white)
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.green, lineWidth: 2)
                                )
                        }
                        
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                            Text("Signature captured successfully")
                                .font(.subheadline)
                            
                            Spacer()
                            
                            Button("Re-sign") {
                                showingFullScreenSignature = true
                            }
                            .foregroundColor(.blue)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                        }
                        .padding()
                        .background(Color.green.opacity(0.1))
                        .cornerRadius(8)
                    }
                } else {
                    // Show sign button
                    VStack(spacing: 12) {
                        Button(action: {
                            showingFullScreenSignature = true
                        }) {
                            VStack(spacing: 12) {
                                Image(systemName: "hand.draw")
                                    .font(.system(size: 40))
                                    .foregroundColor(.blue)
                                
                                Text("Tap to Sign")
                                    .font(.headline)
                                    .foregroundColor(.blue)
                                
                                Text("Opens full-screen signature pad")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(30)
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color.blue, lineWidth: 2)
                            )
                        }
                        
                        HStack {
                            Image(systemName: "exclamationmark.circle")
                                .foregroundColor(.orange)
                            Text("Customer signature required to proceed")
                                .font(.subheadline)
                        }
                        .padding()
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(8)
                    }
                }
            }
            
            Spacer()
        }
        .padding()
        .onAppear {
            termsManager.loadTerms()
        }
        .fullScreenCover(isPresented: $showingFullScreenSignature) {
            FullScreenSignatureView(
                signatureImage: $signatureImage,
                hasSignature: $hasSignature,
                isPresented: $showingFullScreenSignature,
                customerName: customerName
            )
        }
    }
}
