//
//  MotelRApp.swift
//  MotelR 2.0 — by New Journey
//

import SwiftUI
import BackgroundTasks
import UserNotifications

// MARK: - App Entry Point

@main
struct MotelRApp: App {

    @State private var showLaunchScreen  = true
    @AppStorage("hasCompletedSetup") private var hasCompletedSetup = false
    @AppStorage("hasSeenWalkthrough") private var hasSeenWalkthrough = false
    @State private var isLocked          = true
    @StateObject private var motelData   = MotelData()
    @State private var restartTrigger    = false
    @State private var showCoreDataError = false
    @State private var showSaveErrorBanner = false
    @Environment(\.scenePhase) private var scenePhase

    init() {
        // Business name, tax rate, terms, check-out time and housekeeping status
        // are shared between the owner's devices through iCloud.
        SettingsSync.shared.start()
        configureBackgroundTasks()
        // Only the delegate is installed at launch. The permission prompt itself is
        // deferred until the user turns on a feature that sends notifications —
        // asking on the very first launch, before any UI is shown, gets declined.
        UNUserNotificationCenter.current().delegate = MotelRNotificationDelegate.shared
        if !SecurityManager.shared.pinExists() {
            SecurityManager.shared.resetFailedAttempts()
        }
    }

    // MARK: Scene

    var body: some Scene {
        WindowGroup {
            ZStack {
                contentStack
                    .onAppear {
                        if CoreDataManager.shared.loadError != nil {
                            showCoreDataError = true
                        }
                    }
                    .onReceive(
                        NotificationCenter.default.publisher(for: .coreDataSaveFailed)
                    ) { _ in
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                            showSaveErrorBanner = true
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                            withAnimation { showSaveErrorBanner = false }
                        }
                    }
                    .overlay(alignment: .top) { saveErrorBanner }
                    .alert("Database Error", isPresented: $showCoreDataError) {
                        Button("Reset All Data", role: .destructive) {
                            CoreDataManager.shared.resetStore()
                            NotificationCenter.default.post(
                                name: NSNotification.Name("RestartApp"), object: nil
                            )
                        }
                        // Apple rejects apps that quit themselves, so offer help instead.
                        Button("Contact Support", role: .cancel) {
                            if let url = URL(string: "https://nishant-co.github.io/MotelR/support.html") {
                                UIApplication.shared.open(url)
                            }
                        }
                    } message: {
                        Text("MotelR 2.0 could not load its database. This may be due to corrupted data or low storage.\n\nReset all data to recover (you can restore an exported backup afterwards), or contact support.")
                    }
                    .onReceive(
                        NotificationCenter.default.publisher(
                            for: NSNotification.Name("RestartApp")
                        )
                    ) { _ in
                        showLaunchScreen = true
                        hasCompletedSetup = false
                        isLocked         = true
                        restartTrigger.toggle()
                    }
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .background {
                if SecurityManager.shared.pinExists() {
                    isLocked = true
                }
            }
        }
    }

    // MARK: - Content routing

    @ViewBuilder
    private var contentStack: some View {
        if showLaunchScreen {
            LaunchScreenView {
                withAnimation(.easeInOut(duration: 0.45)) {
                    showLaunchScreen = false
                }
            }
            .transition(.opacity)
            .id("launch-\(restartTrigger)")

        } else if !hasSeenWalkthrough {
            // Shown once, before anything else, so a brand-new user understands what
            // the app is for instead of landing on an empty dashboard.
            OnboardingView {
                withAnimation(.easeInOut(duration: 0.4)) { hasSeenWalkthrough = true }
            }
            .transition(.opacity)

        } else if !hasCompletedSetup {
            RestoreView()
                .environmentObject(motelData)
                .transition(.opacity)

        } else if isLocked && SecurityManager.shared.pinExists() {
            AppLockView {
                withAnimation(.easeInOut(duration: 0.38)) { isLocked = false }
            }
            .transition(.opacity)

        } else {
            MainView()
                .environmentObject(motelData)
                .transition(.opacity)
        }
    }

    // MARK: - Save-error banner

    @ViewBuilder
    private var saveErrorBanner: some View {
        if showSaveErrorBanner {
            HStack(spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundColor(.white)
                Text("Changes could not be saved. Please try again.")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(.white)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 13)
            .background(
                Capsule()
                    .fill(Color.red.gradient)
                    .shadow(color: .black.opacity(0.28), radius: 8, x: 0, y: 4)
            )
            .padding(.top, 10)
            .transition(.move(edge: .top).combined(with: .opacity))
            .zIndex(999)
        }
    }

    // MARK: - Setup helpers

    private func configureBackgroundTasks() {
        BackupScheduler.shared.registerBackgroundTasks()
        if UserDefaults.standard.bool(forKey: "autoBackupEnabled") {
            BackupScheduler.shared.scheduleBackup()
        }
    }

}

// MARK: - Notification permission (requested in context, not at launch)

enum NotificationPermission {
    /// Asks for notification permission at the moment the user enables something
    /// that needs it (auto-backup, checkout reminders).
    static func requestIfNeeded() {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .notDetermined else { return }
            center.requestAuthorization(options: [.alert, .sound, .badge]) { _, error in
                if let error {
                    print("MotelR 2.0 — notification permission error: \(error)")
                }
            }
        }
    }
}

// MARK: - Notification Delegate (show banners while app is in foreground)

final class MotelRNotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = MotelRNotificationDelegate()

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        completionHandler([.banner, .sound, .badge])
    }
}

// MARK: - Schedule checkout reminder

/// The motel's check-out time as set in Settings (defaults to 11:00 AM).
func motelCheckOutTime() -> DateComponents {
    if let saved = UserDefaults.standard.object(forKey: "checkOutTime") as? Date {
        return Calendar.current.dateComponents([.hour, .minute], from: saved)
    }
    return DateComponents(hour: 11, minute: 0)
}

/// Default value for the check-out time pickers when nothing has been saved yet.
func defaultCheckOutTimeDate() -> Date {
    let parts = motelCheckOutTime()
    return Calendar.current.date(bySettingHour: parts.hour ?? 11, minute: parts.minute ?? 0, second: 0, of: Date()) ?? Date()
}

/// Reminds the front desk one hour before the motel's check-out time on the
/// guest's check-out day. (It used to fire at 8:00 AM whatever the check-out
/// time in Settings said.)
func scheduleCheckoutReminderNotification(booking: CDBooking) {
    NotificationPermission.requestIfNeeded()

    let identifier = "checkout-\(booking.id.uuidString)"
    let center = UNUserNotificationCenter.current()
    center.removePendingNotificationRequests(withIdentifiers: [identifier])

    let cal = Calendar.current
    let time = motelCheckOutTime()
    guard let checkOutMoment = cal.date(
        bySettingHour: time.hour ?? 11,
        minute: time.minute ?? 0,
        second: 0,
        of: booking.checkOutDate
    ) else { return }
    let remindAt = checkOutMoment.addingTimeInterval(-3600)
    guard remindAt > Date() else { return }   // nothing to remind about any more

    let timeFormatter = DateFormatter()
    timeFormatter.timeStyle = .short
    timeFormatter.dateStyle = .none

    let content = UNMutableNotificationContent()
    content.title = "Checkout Reminder"
    content.body  = "Room \(booking.room.number) — \(booking.customerName) checks out today at \(timeFormatter.string(from: checkOutMoment))."
    content.sound = .default

    let components = cal.dateComponents([.year, .month, .day, .hour, .minute], from: remindAt)
    let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
    center.add(UNNotificationRequest(identifier: identifier, content: content, trigger: trigger))
}

/// Re-times every pending checkout reminder, e.g. after the check-out time changes.
func rescheduleCheckoutReminders(for bookings: [CDBooking]) {
    for booking in bookings {
        scheduleCheckoutReminderNotification(booking: booking)
    }
}

// MARK: - AppLock Button Style

struct AppLockButtonStyle: ButtonStyle {
    var isSpecial: Bool = false
    var isActive: Bool  = true

    func makeBody(configuration: Configuration) -> some View {
        ZStack {
            Circle()
                .fill(
                    isSpecial
                        ? Color.white.opacity(configuration.isPressed ? 0.24 : (isActive ? 0.18 : 0.07))
                        : Color.white.opacity(configuration.isPressed ? 0.20 : 0.13)
                )
                .overlay(
                    Circle()
                        .stroke(Color.white.opacity(0.18), lineWidth: 1)
                )
                .frame(width: 74, height: 74)
                .shadow(
                    color: Color.black.opacity(0.32),
                    radius: configuration.isPressed ? 3 : 12,
                    x: 0,
                    y: configuration.isPressed ? 1 : 6
                )

            configuration.label
        }
        .scaleEffect(configuration.isPressed ? 0.86 : 1.0)
        .animation(.spring(response: 0.16, dampingFraction: 0.50), value: configuration.isPressed)
    }
}

// MARK: - AppLock View

struct AppLockView: View {

    let onUnlocked: () -> Void

    // PIN state
    @State private var pin              = ""
    @State private var showError        = false
    @State private var errorMessage     = ""
    @State private var lockoutRemaining = 0
    @State private var lockoutTimer: Timer?

    // Animations
    @State private var contentOpacity: Double  = 0
    @State private var contentOffset: CGFloat  = 36
    @State private var shakeAttempts: CGFloat  = 0
    @State private var dotsSuccess: Bool       = false
    @State private var exitOpacity: Double     = 1.0
    @State private var glowPulse: Bool         = false
    @State private var isVerifying: Bool       = false

    private let haptics = UIImpactFeedbackGenerator(style: .medium)

    // MARK: Body

    var body: some View {
        ZStack {

            // ── Background ────────────────────────────────────────────────
            LinearGradient(
                colors: [
                    Color(red: 0.04, green: 0.08, blue: 0.20),
                    Color(red: 0.07, green: 0.14, blue: 0.35),
                    Color(red: 0.10, green: 0.22, blue: 0.52),
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            // Radial glow — shifts green on success
            RadialGradient(
                colors: [
                    (dotsSuccess ? Color.green : Color(red: 0.25, green: 0.52, blue: 1.00))
                        .opacity(glowPulse ? 0.24 : 0.08),
                    Color.clear
                ],
                center: .center,
                startRadius: 10,
                endRadius: 320
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true), value: glowPulse)
            .animation(.spring(response: 0.45, dampingFraction: 0.70), value: dotsSuccess)

            // ── Main column ───────────────────────────────────────────────
            VStack(spacing: 0) {
                Spacer()
                brandingHeader
                    .padding(.bottom, 44)
                if lockoutRemaining > 0 {
                    lockoutCountdown
                } else {
                    pinEntrySection
                }
                Spacer()
            }
            .opacity(contentOpacity * exitOpacity)
            .offset(y: contentOffset)
        }
        .onAppear {
            withAnimation(.spring(response: 0.55, dampingFraction: 0.75)) {
                contentOpacity = 1.0
                contentOffset  = 0
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.50) { glowPulse = true }
            if SecurityManager.shared.isLockedOut() { startLockoutTimer() }
        }
    }

    // MARK: - Branding

    private var brandingHeader: some View {
        VStack(spacing: 20) {

            // Icon with pulsing ring
            ZStack {
                // Pulsing glow ring
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [
                                (dotsSuccess ? Color.green : Color(red: 0.18, green: 0.27, blue: 0.90))
                                    .opacity(glowPulse ? 0.38 : 0.14),
                                Color.clear
                            ],
                            center: .center,
                            startRadius: 0,
                            endRadius: 76
                        )
                    )
                    .frame(width: 150, height: 150)
                    .animation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true), value: glowPulse)

                // Gold outer ring
                Circle()
                    .stroke(
                        LinearGradient(
                            colors: [
                                Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.55),
                                Color(red: 0.96, green: 0.65, blue: 0.14).opacity(0.10),
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1.5
                    )
                    .frame(width: 118, height: 118)
                    .scaleEffect(glowPulse ? 1.05 : 1.0)
                    .animation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true), value: glowPulse)

                // Filled circle
                Circle()
                    .fill(
                        LinearGradient(
                            colors: dotsSuccess
                                ? [Color.green, Color.mint]
                                : [Color(red: 0.18, green: 0.27, blue: 0.90),
                                   Color(red: 0.05, green: 0.12, blue: 0.65)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 96, height: 96)
                    .shadow(
                        color: (dotsSuccess ? Color.green : Color(red: 0.18, green: 0.27, blue: 0.90))
                            .opacity(0.55),
                        radius: 24, x: 0, y: 8
                    )
                    .animation(.spring(response: 0.40, dampingFraction: 0.65), value: dotsSuccess)

                // Icon
                Image(systemName: dotsSuccess ? "checkmark" : "lock.shield.fill")
                    .font(.system(size: 42, weight: .medium))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [.white, Color(white: 0.88)],
                            startPoint: .top, endPoint: .bottom
                        )
                    )
                    .scaleEffect(glowPulse ? 1.06 : 1.0)
                    .animation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true), value: glowPulse)
                    .animation(.spring(response: 0.35, dampingFraction: 0.60), value: dotsSuccess)
            }

            // App title
            VStack(spacing: 5) {
                HStack(alignment: .top, spacing: 0) {
                    Text("Motel")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                    Text("R")
                        .font(.system(size: 36, weight: .black, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.55, green: 0.80, blue: 1.00),
                                    Color(red: 0.30, green: 0.62, blue: 1.00),
                                ],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                    Text("2.0")
                        .font(.system(size: 16, weight: .heavy, design: .rounded))
                        .foregroundStyle(
                            LinearGradient(
                                colors: [
                                    Color(red: 0.96, green: 0.65, blue: 0.14),
                                    Color(red: 0.88, green: 0.48, blue: 0.08),
                                ],
                                startPoint: .top, endPoint: .bottom
                            )
                        )
                        .offset(y: -13)
                        .padding(.leading, 3)
                }

                Text("by New Journey")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.48))
                    .tracking(2.4)
                    .padding(.top, 2)

                Text(
                    lockoutRemaining > 0
                        ? "Too many failed attempts"
                        : dotsSuccess
                            ? "Access granted"
                            : "Enter your PIN to continue"
                )
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.58))
                .padding(.top, 6)
                .animation(.easeInOut(duration: 0.25), value: dotsSuccess)
            }
        }
    }

    // MARK: - PIN entry

    private var pinEntrySection: some View {
        VStack(spacing: 30) {

            // Six-dot indicator
            HStack(spacing: 18) {
                ForEach(0..<6, id: \.self) { i in
                    ZStack {
                        Circle()
                            .stroke(
                                LinearGradient(
                                    colors: i < pin.count
                                        ? (dotsSuccess
                                            ? [Color.green, .mint]
                                            : [Color(red: 0.55, green: 0.80, blue: 1.00),
                                               Color(red: 0.30, green: 0.62, blue: 1.00)])
                                        : [Color.white.opacity(0.30), Color.white.opacity(0.14)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                ),
                                lineWidth: 1.8
                            )
                            .frame(width: 19, height: 19)

                        if i < pin.count {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: dotsSuccess
                                            ? [Color.green, .mint]
                                            : [Color(red: 0.55, green: 0.80, blue: 1.00),
                                               Color(red: 0.30, green: 0.62, blue: 1.00)],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 13, height: 13)
                                .transition(.scale(scale: 0).combined(with: .opacity))
                        }
                    }
                    .animation(.spring(response: 0.26, dampingFraction: 0.54), value: pin.count)
                    .animation(.spring(response: 0.35, dampingFraction: 0.65), value: dotsSuccess)
                }
            }
            .modifier(ShakeEffect(animatableData: shakeAttempts))

            // Error message
            if showError {
                Text(errorMessage)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.82))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 36)
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }

            // 3×4 keypad
            LazyVGrid(
                columns: Array(repeating: GridItem(.flexible(), spacing: 0), count: 3),
                spacing: 14
            ) {
                ForEach(1...9, id: \.self) { n in
                    Button { appendDigit("\(n)") } label: {
                        Text("\(n)")
                            .font(.system(size: 28, weight: .light, design: .rounded))
                            .foregroundColor(.white)
                            .frame(width: 74, height: 74)
                    }
                    .buttonStyle(AppLockButtonStyle())
                }

                // Delete
                Button { deleteDigit() } label: {
                    Image(systemName: "delete.left.fill")
                        .font(.system(size: 22, weight: .medium))
                        .foregroundColor(.white.opacity(0.85))
                        .frame(width: 74, height: 74)
                }
                .buttonStyle(AppLockButtonStyle(isSpecial: true))

                // 0
                Button { appendDigit("0") } label: {
                    Text("0")
                        .font(.system(size: 28, weight: .light, design: .rounded))
                        .foregroundColor(.white)
                        .frame(width: 74, height: 74)
                }
                .buttonStyle(AppLockButtonStyle())

                // Submit
                Button { submitPin() } label: {
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.system(size: 26, weight: .medium))
                        .foregroundColor(pin.count == 6 ? .white : .white.opacity(0.26))
                        .frame(width: 74, height: 74)
                }
                .buttonStyle(AppLockButtonStyle(isSpecial: true, isActive: pin.count == 6))
                .disabled(pin.count != 6)
                .scaleEffect(pin.count == 6 ? 1.06 : 1.0)
                .animation(.spring(response: 0.28, dampingFraction: 0.60), value: pin.count == 6)
            }
            .padding(.horizontal, 38)
            // Without a cap the three columns are flung to the screen edges on iPad.
            .frame(maxWidth: 320)
        }
    }

    // MARK: - Lockout countdown

    private var lockoutCountdown: some View {
        VStack(spacing: 12) {
            Image(systemName: "exclamationmark.shield.fill")
                .font(.system(size: 34))
                .foregroundStyle(
                    LinearGradient(
                        colors: [Color(red: 1.0, green: 0.30, blue: 0.25),
                                 Color(red: 0.85, green: 0.15, blue: 0.10)],
                        startPoint: .top, endPoint: .bottom
                    )
                )
                .padding(.bottom, 4)

            Text("Try again in")
                .font(.system(size: 14, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.58))

            Text(formatTime(lockoutRemaining))
                .font(.system(size: 58, weight: .bold, design: .monospaced))
                .foregroundStyle(
                    LinearGradient(
                        colors: [Color(red: 1.0, green: 0.35, blue: 0.30),
                                 Color(red: 0.88, green: 0.18, blue: 0.14)],
                        startPoint: .top, endPoint: .bottom
                    )
                )
                .contentTransition(.numericText())

            Text(lockoutReasonText)
                .font(.system(size: 12, weight: .regular, design: .rounded))
                .foregroundColor(.white.opacity(0.40))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .padding(.bottom, 32)
    }

    private var lockoutReasonText: String {
        let fails = SecurityManager.shared.failedAttempts
        switch fails {
        case ..<10: return "Locked for 1 minute after 5 failed attempts."
        case ..<15: return "Locked for 5 minutes after 10 failed attempts."
        default:    return "Locked for 30 minutes after 15+ failed attempts."
        }
    }

    // MARK: - PIN logic

    private func appendDigit(_ digit: String) {
        guard pin.count < 6, lockoutRemaining == 0, !isVerifying else { return }
        haptics.impactOccurred(intensity: 0.55)
        withAnimation(.spring(response: 0.26, dampingFraction: 0.54)) {
            pin      += digit
            showError = false
        }
        if pin.count == 6 { submitPin() }
    }

    private func deleteDigit() {
        guard !pin.isEmpty, !isVerifying else { return }
        haptics.impactOccurred(intensity: 0.40)
        withAnimation(.spring(response: 0.26, dampingFraction: 0.58)) {
            pin.removeLast()
            showError = false
        }
    }

    private func submitPin() {
        guard pin.count == 6, !isVerifying else { return }
        guard !SecurityManager.shared.isLockedOut() else {
            startLockoutTimer()
            return
        }

        isVerifying = true
        SecurityManager.shared.verifyPinAsync(pin) { isCorrect in
            isVerifying = false
            handlePinResult(isCorrect)
        }
    }

    private func handlePinResult(_ isCorrect: Bool) {
        if isCorrect {
            haptics.impactOccurred(intensity: 0.8)
            SecurityManager.shared.resetFailedAttempts()
            withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) { dotsSuccess = true }
            withAnimation(.easeIn(duration: 0.40).delay(0.44)) { exitOpacity = 0 }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.80) { onUnlocked() }
        } else {
            haptics.impactOccurred(intensity: 0.9)
            SecurityManager.shared.recordFailedAttempt()

            withAnimation(.linear(duration: 0.42)) { shakeAttempts += 1 }
            withAnimation(.spring(response: 0.26, dampingFraction: 0.58)) { pin = "" }

            if SecurityManager.shared.isLockedOut() {
                startLockoutTimer()
            } else {
                let fails = SecurityManager.shared.failedAttempts
                let nextThreshold = ((fails / 5) + 1) * 5
                let attemptsLeft = nextThreshold - fails
                withAnimation(.easeIn(duration: 0.18)) {
                    showError    = true
                    errorMessage = "Incorrect PIN. \(attemptsLeft) attempt\(attemptsLeft == 1 ? "" : "s") before lockout."
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
                    withAnimation { showError = false }
                }
            }
        }
    }

    private func startLockoutTimer() {
        lockoutRemaining = SecurityManager.shared.lockoutSecondsRemaining()
        pin       = ""
        showError = false
        lockoutTimer?.invalidate()
        let timer = Timer(timeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                lockoutRemaining = SecurityManager.shared.lockoutSecondsRemaining()
                if lockoutRemaining <= 0 {
                    lockoutTimer?.invalidate()
                    lockoutTimer = nil
                }
            }
        }
        RunLoop.main.add(timer, forMode: .common)
        lockoutTimer = timer
    }

    private func formatTime(_ seconds: Int) -> String {
        String(format: "%d:%02d", seconds / 60, seconds % 60)
    }
}
