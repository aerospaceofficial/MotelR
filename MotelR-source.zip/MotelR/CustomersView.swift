//  CustomersView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Customer Model

struct CustomerProfile: Identifiable {
    let id: String // drivingLicenseNumber
    let name: String
    let phone: String
    let licenseNumber: String
    let address: String
    let city: String
    let state: String
    let zipCode: String
    let stayCount: Int
    let lastBooking: CDBooking
    let allBookings: [CDBooking]

    var isVIP: Bool { stayCount >= 3 }
    var isReturning: Bool { stayCount >= 2 }

    var lastStayDate: Date { lastBooking.checkInDate }

    var initials: String {
        let parts = name.split(separator: " ")
        let first = parts.first?.prefix(1) ?? ""
        let last = parts.dropFirst().last?.prefix(1) ?? ""
        return "\(first)\(last)".uppercased()
    }

    var alphabetKey: String {
        String(name.prefix(1)).uppercased()
    }
}

// MARK: - CustomersView

struct CustomersView: View {
    @EnvironmentObject var motelData: MotelData
    @State private var searchText = ""
    @State private var isRefreshing = false

    // MARK: Derived Data

    private var allCustomers: [CustomerProfile] {
        let all = motelData.bookings + motelData.history
        var grouped: [String: [CDBooking]] = [:]
        for booking in all {
            let key = booking.drivingLicenseNumber.isEmpty ? booking.customerName : booking.drivingLicenseNumber
            grouped[key, default: []].append(booking)
        }
        return grouped.compactMap { licenseKey, bookings -> CustomerProfile? in
            guard let latest = bookings.sorted(by: { $0.checkInDate > $1.checkInDate }).first else { return nil }
            return CustomerProfile(
                id: licenseKey,
                name: latest.customerName,
                phone: latest.phoneNumber,
                licenseNumber: latest.drivingLicenseNumber,
                address: latest.address,
                city: latest.city,
                state: latest.state,
                zipCode: latest.zipCode,
                stayCount: bookings.count,
                lastBooking: latest,
                allBookings: bookings.sorted(by: { $0.checkInDate > $1.checkInDate })
            )
        }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    private var filteredCustomers: [CustomerProfile] {
        guard !searchText.isEmpty else { return allCustomers }
        let q = searchText.lowercased()
        return allCustomers.filter {
            $0.name.lowercased().contains(q) ||
            $0.phone.contains(q) ||
            $0.licenseNumber.lowercased().contains(q)
        }
    }

    private var groupedCustomers: [(String, [CustomerProfile])] {
        let dict = Dictionary(grouping: filteredCustomers) { $0.alphabetKey }
        return dict.sorted { $0.key < $1.key }
    }

    private var totalGuests: Int { allCustomers.count }
    private var returningGuests: Int { allCustomers.filter { $0.isReturning }.count }
    private var vipGuests: Int { allCustomers.filter { $0.isVIP }.count }

    // MARK: Body

    var body: some View {
        VStack(spacing: 0) {
            statsHeaderBar
            searchBarView
            if filteredCustomers.isEmpty {
                emptyStateView
            } else {
                customerList
            }
        }
        .navigationTitle("Guests")
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
    }

    // MARK: Stats Header

    private var statsHeaderBar: some View {
        HStack(spacing: 0) {
            statPill(value: "\(totalGuests)", label: "Total", icon: "person.2.fill", color: primaryColor)
            Divider().frame(height: 32)
            statPill(value: "\(returningGuests)", label: "Returning", icon: "arrow.clockwise", color: Color(red: 0.20, green: 0.78, blue: 0.35))
            Divider().frame(height: 32)
            statPill(value: "\(vipGuests)", label: "VIP", icon: "star.fill", color: goldColor)
        }
        .padding(.vertical, 12)
        .background(Color(.systemBackground))
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }

    private func statPill(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 2) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundColor(color)
                Text(value)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)
            }
            Text(label)
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: Search Bar

    private var searchBarView: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.secondary)
                .font(.system(size: 15, weight: .medium))
            TextField("Search by name, phone, or license...", text: $searchText)
                .font(.system(size: 15, design: .rounded))
            if !searchText.isEmpty {
                Button(action: { searchText = "" }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }

    // MARK: Customer List

    private var customerList: some View {
        List {
            ForEach(groupedCustomers, id: \.0) { letter, customers in
                Section(header:
                    Text(letter)
                        .font(.system(size: 13, weight: .bold, design: .rounded))
                        .foregroundColor(primaryColor)
                        .textCase(nil)
                ) {
                    ForEach(customers) { customer in
                        NavigationLink(destination:
                            CustomerDetailsView(
                                booking: customer.lastBooking,
                                allCustomerBookings: customer.allBookings,
                                isHistorical: customer.lastBooking.isHistory
                            )
                            .environmentObject(motelData)
                        ) {
                            CustomerRowCard(customer: customer)
                        }
                        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                        .listRowBackground(Color(.systemBackground))
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .refreshable {
            motelData.fetchAllData()
        }
    }

    // MARK: Empty State

    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "person.3.sequence.fill")
                .font(.system(size: 56))
                .foregroundStyle(
                    LinearGradient(
                        colors: [primaryColor.opacity(0.6), primaryColor.opacity(0.3)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Text(searchText.isEmpty ? "No Guests Yet" : "No Results Found")
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(.primary)
            Text(searchText.isEmpty
                 ? "Guests will appear here once you create bookings."
                 : "Try a different name, phone number, or license.")
                .font(.system(size: 15, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    // MARK: Design Constants

    private var primaryColor: Color { Color(red: 0.18, green: 0.27, blue: 0.90) }
    private var goldColor: Color { Color(red: 0.96, green: 0.65, blue: 0.14) }
}

// MARK: - Customer Row Card

struct CustomerRowCard: View {
    let customer: CustomerProfile

    private var primaryColor: Color { Color(red: 0.18, green: 0.27, blue: 0.90) }
    private var goldColor: Color { Color(red: 0.96, green: 0.65, blue: 0.14) }
    private var greenColor: Color { Color(red: 0.20, green: 0.78, blue: 0.35) }

    private var lastStayFormatted: String {
        let f = DateFormatter()
        f.dateStyle = .medium
        return f.string(from: customer.lastStayDate)
    }

    var body: some View {
        HStack(spacing: 14) {
            // Avatar
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [primaryColor, Color(red: 0.05, green: 0.12, blue: 0.65)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 48, height: 48)
                Text(customer.initials)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
            }

            // Content
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Text(customer.name)
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .foregroundColor(.primary)
                        .lineLimit(1)
                    if customer.isVIP {
                        Label("VIP", systemImage: "star.fill")
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(goldColor)
                            .clipShape(Capsule())
                    }
                }
                Text(customer.phone)
                    .font(.system(size: 13, design: .rounded))
                    .foregroundColor(.secondary)
            }

            Spacer()

            // Right column
            VStack(alignment: .trailing, spacing: 4) {
                HStack(spacing: 4) {
                    Image(systemName: "bed.double.fill")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(greenColor)
                    Text("\(customer.stayCount) \(customer.stayCount == 1 ? "stay" : "stays")")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundColor(greenColor)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background(greenColor.opacity(0.12))
                .clipShape(Capsule())

                Text(lastStayFormatted)
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}

// MARK: - Preview

struct CustomersView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            CustomersView()
                .environmentObject(MotelData())
        }
    }
}
