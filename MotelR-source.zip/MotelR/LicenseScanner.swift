//
//  LicenseScanner.swift
//  MotelR 2.0 — by New Journey
//
//  Reads the PDF417 barcode printed on the back of US and Canadian driver's licences
//  and fills in the guest form from it.
//
//  The barcode follows the AAMVA DL/ID Card Design Standard: a set of three-letter
//  element codes, one per line. Rather than parsing the header strictly — real-world
//  cards from different states are inconsistent about it — we scan for the element
//  codes we care about, which is far more tolerant of oddly-encoded cards.
//
//  Scanning is always optional. Anything it cannot read is simply left for the clerk
//  to type, and the licence photo is still captured separately.
//

import SwiftUI
import AVFoundation
import UIKit

// MARK: - Parsed Result

struct ScannedLicense {
    var firstName: String = ""
    var middleName: String = ""
    var lastName: String = ""
    var address: String = ""
    var city: String = ""
    var state: String = ""
    var zipCode: String = ""
    var licenseNumber: String = ""
    var dateOfBirth: String = ""
    var expiryDate: String = ""

    var fullName: String {
        [firstName, middleName, lastName]
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }

    /// True when we got enough out of the barcode to be worth applying.
    var hasUsableData: Bool {
        !fullName.isEmpty || !licenseNumber.isEmpty
    }
}

// MARK: - AAMVA Parser

enum AAMVAParser {

    /// AAMVA element codes we read. Everything else in the barcode is ignored.
    private enum Element: String {
        case lastName      = "DCS"
        case firstName     = "DAC"
        case middleName    = "DAD"
        case fullNameLegacy = "DAA"   // pre-2000 cards pack the whole name into one field
        case street1       = "DAG"
        case city          = "DAI"
        case state         = "DAJ"
        case postalCode    = "DAK"
        case licenseNumber = "DAQ"
        case dateOfBirth   = "DBB"
        case expiryDate    = "DBA"
    }

    static func parse(_ payload: String) -> ScannedLicense {
        var result = ScannedLicense()

        // Elements are newline-delimited, but some encoders use \r instead.
        let lines = payload
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
            .components(separatedBy: "\n")

        var values: [String: String] = [:]
        for line in lines {
            guard let (code, value) = element(in: line) else { continue }
            // Keep the first occurrence; the header can repeat a code inside its offsets.
            if values[code] == nil, !isPlaceholder(value) {
                values[code] = value
            }
        }

        result.lastName      = titleCased(values[Element.lastName.rawValue])
        result.firstName     = titleCased(values[Element.firstName.rawValue])
        result.middleName    = titleCased(values[Element.middleName.rawValue])
        result.address       = titleCased(values[Element.street1.rawValue])
        result.city          = titleCased(values[Element.city.rawValue])
        result.state         = verbatim(values[Element.state.rawValue]).uppercased()
        result.zipCode       = formatPostalCode(values[Element.postalCode.rawValue])
        result.licenseNumber = verbatim(values[Element.licenseNumber.rawValue])
        result.dateOfBirth   = verbatim(values[Element.dateOfBirth.rawValue])
        result.expiryDate    = verbatim(values[Element.expiryDate.rawValue])

        // Older cards only carry DAA — "LAST,FIRST,MIDDLE" or "LAST$FIRST$MIDDLE".
        if result.lastName.isEmpty && result.firstName.isEmpty,
           let legacy = values[Element.fullNameLegacy.rawValue] {
            let parts = legacy
                .components(separatedBy: CharacterSet(charactersIn: ",$@"))
                .map { $0.trimmingCharacters(in: .whitespaces) }
                .filter { !$0.isEmpty && !isPlaceholder($0) }
            if parts.count >= 1 { result.lastName   = titleCased(parts[0]) }
            if parts.count >= 2 { result.firstName  = titleCased(parts[1]) }
            if parts.count >= 3 { result.middleName = titleCased(parts[2]) }
        }

        return result
    }

    /// Pulls a `CODEvalue` pair out of one line.
    ///
    /// Most elements sit on their own line, but the very first one is appended straight
    /// onto the header — e.g. `ANSI 636001090002DL00410278ZV03190008DLDAQT64235789`,
    /// where the licence number trails the final `DL` subfile marker. Missing that case
    /// loses the licence number on most real cards, so the header gets special handling.
    private static func element(in line: String) -> (String, String)? {
        let trimmed = line.trimmingCharacters(in: .whitespaces)
        guard trimmed.count > 3 else { return nil }

        func split(_ text: String) -> (String, String)? {
            guard text.count > 3 else { return nil }
            let code = String(text.prefix(3))
            guard code.allSatisfy({ $0.isLetter && $0.isUppercase }) else { return nil }
            return (code, String(text.dropFirst(3)).trimmingCharacters(in: .whitespaces))
        }

        // Plain element line.
        if !trimmed.hasPrefix("@"), !trimmed.contains("ANSI"), !trimmed.contains("AAMVA"),
           let pair = split(trimmed) {
            return pair
        }

        // Header line: the subfile body starts after the last "DL"/"ID" marker.
        for marker in ["DL", "ID"] {
            if let range = trimmed.range(of: marker, options: .backwards) {
                if let pair = split(String(trimmed[range.upperBound...])) {
                    return pair
                }
            }
        }
        return split(trimmed)
    }

    /// Some jurisdictions write a literal "NONE" or "UNAVL" rather than leaving a field out.
    private static func isPlaceholder(_ value: String) -> Bool {
        let upper = value.uppercased()
        return value.isEmpty || upper == "NONE" || upper == "UNAVL" || upper == "UNKNOWN" || upper == "NA"
    }

    /// Trimmed, but otherwise exactly as encoded. Used for licence numbers, dates and
    /// state codes, where changing the case would corrupt the value.
    private static func verbatim(_ raw: String?) -> String {
        guard let raw, !isPlaceholder(raw) else { return "" }
        return raw.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// Barcodes store names and addresses in all-caps. Title-case them so they read
    /// normally on a receipt. Tokens containing digits ("42ND", "3B") are left alone —
    /// lowercasing those looks wrong in an address.
    private static func titleCased(_ raw: String?) -> String {
        let trimmed = verbatim(raw)
        guard !trimmed.isEmpty else { return "" }
        return trimmed
            .split(separator: " ")
            .map { word -> String in
                guard !word.contains(where: \.isNumber) else { return String(word) }
                let lower = word.lowercased()
                return lower.prefix(1).uppercased() + lower.dropFirst()
            }
            .joined(separator: " ")
    }

    /// AAMVA right-pads postal codes to 9 characters with zeros.
    private static func formatPostalCode(_ raw: String?) -> String {
        guard let raw, !isPlaceholder(raw) else { return "" }
        let digits = raw.trimmingCharacters(in: .whitespaces)
            .replacingOccurrences(of: "-", with: "")
        guard digits.count == 9, digits.allSatisfy(\.isNumber) else {
            return digits
        }
        let last4 = String(digits.suffix(4))
        let first5 = String(digits.prefix(5))
        return last4 == "0000" ? first5 : "\(first5)-\(last4)"
    }
}

// MARK: - Scanner Sheet

/// Full-screen camera that watches for a PDF417 barcode and hands back the parsed licence.
struct LicenseScannerView: View {
    let onScanned: (ScannedLicense) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var permissionDenied = false
    @State private var didScan = false
    @State private var torchOn = false

    private let primary = Color(red: 0.18, green: 0.27, blue: 0.90)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if permissionDenied {
                permissionMessage
            } else {
                PDF417CameraView(torchOn: torchOn) { payload in
                    handle(payload)
                } onPermissionDenied: {
                    permissionDenied = true
                }
                .ignoresSafeArea()

                scannerOverlay
            }

            VStack {
                HStack {
                    Button { dismiss() } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(.white)
                            .padding(12)
                            .background(Color.black.opacity(0.45), in: Circle())
                    }
                    Spacer()
                    if !permissionDenied {
                        Button { torchOn.toggle() } label: {
                            Image(systemName: torchOn ? "bolt.fill" : "bolt.slash.fill")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundStyle(torchOn ? .yellow : .white)
                                .padding(12)
                                .background(Color.black.opacity(0.45), in: Circle())
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                Spacer()
            }
        }
    }

    private var scannerOverlay: some View {
        VStack {
            Spacer()

            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.white.opacity(0.9), lineWidth: 3)
                .frame(maxWidth: 340)
                .frame(height: 190)
                .padding(.horizontal, 32)
                .shadow(color: .black.opacity(0.4), radius: 12)

            Text("Scan the barcode on the **back** of the licence")
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .padding(.top, 24)
                .padding(.horizontal, 32)

            Text("Hold steady — it fills the form automatically.")
                .font(.system(size: 14, design: .rounded))
                .foregroundStyle(.white.opacity(0.7))
                .padding(.top, 6)

            Spacer()
        }
    }

    private var permissionMessage: some View {
        VStack(spacing: 18) {
            Image(systemName: "camera.fill")
                .font(.system(size: 44))
                .foregroundStyle(.white.opacity(0.85))
            Text("Camera access needed")
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("Turn on camera access for MotelR in Settings to scan licences. You can still type the details in by hand.")
                .font(.system(size: 15, design: .rounded))
                .foregroundStyle(.white.opacity(0.75))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button("Open Settings") {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            .font(.system(size: 16, weight: .semibold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 26)
            .padding(.vertical, 13)
            .background(primary, in: Capsule())
        }
    }

    private func handle(_ payload: String) {
        guard !didScan else { return }
        let parsed = AAMVAParser.parse(payload)
        guard parsed.hasUsableData else { return }   // keep scanning on a garbled read
        didScan = true
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        onScanned(parsed)
        dismiss()
    }
}

// MARK: - Camera

/// Thin AVFoundation wrapper. `AVCaptureMetadataOutput` decodes PDF417 natively, so
/// no image processing of our own is needed.
private struct PDF417CameraView: UIViewControllerRepresentable {
    let torchOn: Bool
    let onFound: (String) -> Void
    let onPermissionDenied: () -> Void

    func makeUIViewController(context: Context) -> ScannerViewController {
        let controller = ScannerViewController()
        controller.onFound = onFound
        controller.onPermissionDenied = onPermissionDenied
        return controller
    }

    func updateUIViewController(_ controller: ScannerViewController, context: Context) {
        controller.setTorch(torchOn)
    }
}

final class ScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {

    var onFound: ((String) -> Void)?
    var onPermissionDenied: (() -> Void)?

    private let session = AVCaptureSession()
    private var previewLayer: AVCaptureVideoPreviewLayer?
    private let sessionQueue = DispatchQueue(label: "com.motelr.licensescanner")

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            configureSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                DispatchQueue.main.async {
                    granted ? self?.configureSession() : self?.onPermissionDenied?()
                }
            }
        default:
            onPermissionDenied?()
        }
    }

    private func configureSession() {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input)
        else {
            onPermissionDenied?()
            return
        }

        session.beginConfiguration()
        session.sessionPreset = .high
        session.addInput(input)

        let metadataOutput = AVCaptureMetadataOutput()
        guard session.canAddOutput(metadataOutput) else {
            session.commitConfiguration()
            return
        }
        session.addOutput(metadataOutput)
        metadataOutput.setMetadataObjectsDelegate(self, queue: .main)
        // Set only after the output is attached, or the type is rejected.
        metadataOutput.metadataObjectTypes = [.pdf417]
        session.commitConfiguration()

        let preview = AVCaptureVideoPreviewLayer(session: session)
        preview.videoGravity = .resizeAspectFill
        preview.frame = view.bounds
        view.layer.addSublayer(preview)
        previewLayer = preview

        // Licence barcodes are dense; focusing close in helps a lot.
        try? device.lockForConfiguration()
        if device.isAutoFocusRangeRestrictionSupported {
            device.autoFocusRangeRestriction = .near
        }
        if device.isFocusModeSupported(.continuousAutoFocus) {
            device.focusMode = .continuousAutoFocus
        }
        device.unlockForConfiguration()

        sessionQueue.async { [weak self] in self?.session.startRunning() }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sessionQueue.async { [weak self] in
            guard let self, self.session.isRunning else { return }
            self.session.stopRunning()
        }
    }

    func setTorch(_ on: Bool) {
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              device.hasTorch else { return }
        try? device.lockForConfiguration()
        device.torchMode = on ? .on : .off
        device.unlockForConfiguration()
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput,
                        didOutput metadataObjects: [AVMetadataObject],
                        from connection: AVCaptureConnection) {
        guard let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              object.type == .pdf417,
              let payload = object.stringValue
        else { return }
        onFound?(payload)
    }
}

// MARK: - Scan Button

/// Reusable "Scan licence" call-to-action shown above the guest fields.
struct ScanLicenseButton: View {
    let onScanned: (ScannedLicense) -> Void

    @State private var showScanner = false
    private let primary = Color(red: 0.18, green: 0.27, blue: 0.90)

    var body: some View {
        Button {
            showScanner = true
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "barcode.viewfinder")
                    .font(.system(size: 22, weight: .semibold))
                VStack(alignment: .leading, spacing: 2) {
                    Text("Scan Licence")
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                    Text("Fills the form from the back of the ID — optional")
                        .font(.system(size: 12, design: .rounded))
                        .opacity(0.85)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .opacity(0.7)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(
                LinearGradient(
                    colors: [primary, Color(red: 0.05, green: 0.12, blue: 0.65)],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 14))
        }
        .buttonStyle(.plain)
        .fullScreenCover(isPresented: $showScanner) {
            LicenseScannerView(onScanned: onScanned)
        }
    }
}
