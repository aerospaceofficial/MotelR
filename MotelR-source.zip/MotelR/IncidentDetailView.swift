//  IncidentDetailView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Design Tokens
private let idvPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let idvGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let idvGreen = Color(red: 0.20, green: 0.78, blue: 0.35)
private let idvGold  = Color(red: 0.96, green: 0.65, blue: 0.14)
private let idvRed   = Color(red: 1.0,  green: 0.23, blue: 0.19)

struct IncidentDetailView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    let incident: CDIncidentReport

    @State private var isResolved: Bool
    @State private var resolutionNotes: String
    @State private var showDeleteConfirmation = false
    @State private var deleteError: String?
    @State private var showDeleteError = false

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .long
        f.timeStyle = .short
        return f
    }()

    init(incident: CDIncidentReport) {
        self.incident = incident
        _isResolved = State(initialValue: incident.isResolved)
        _resolutionNotes = State(initialValue: incident.resolutionNotes ?? "")
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                headerCard
                descriptionCard
                statusCard
                if isResolved {
                    resolutionCard
                }
                actionButton
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Incident Detail")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .destructiveAction) {
                Button {
                    showDeleteConfirmation = true
                } label: {
                    Image(systemName: "trash")
                        .foregroundStyle(idvRed)
                }
            }
        }
        .confirmationDialog(
            "Delete Incident",
            isPresented: $showDeleteConfirmation,
            titleVisibility: .visible
        ) {
            Button("Delete", role: .destructive) {
                do {
                    try motelData.deleteIncident(incident)
                    dismiss()
                } catch {
                    deleteError = error.localizedDescription
                    showDeleteError = true
                }
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This incident report will be permanently deleted.")
        }
        .alert("Delete Failed", isPresented: $showDeleteError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(deleteError ?? "An unknown error occurred.")
        }
    }

    // MARK: - Header Card
    private var headerCard: some View {
        VStack(spacing: 16) {
            // Large severity badge
            HStack(spacing: 8) {
                Image(systemName: incident.severityLevel.icon)
                    .font(.system(size: 20, weight: .bold))
                Text(incident.severityLevel.rawValue.uppercased())
                    .font(.system(.headline, design: .rounded).weight(.bold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
            .background(incident.severityLevel.color)
            .clipShape(Capsule())

            VStack(spacing: 4) {
                Text(incident.customerName)
                    .font(.system(.title2, design: .rounded).weight(.bold))
                Text(Self.dateFormatter.string(from: incident.incidentDate))
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
            }

            HStack(spacing: 6) {
                Image(systemName: "person.fill")
                    .font(.system(size: 13))
                    .foregroundStyle(.secondary)
                Text("Reported by \(incident.reportedBy)")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.secondary)
            }

            if !incident.customerID.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "creditcard.fill")
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)
                    Text("ID: \(incident.customerID)")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity)
        .padding(20)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }

    // MARK: - Description Card
    private var descriptionCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Incident Description", systemImage: "doc.text.fill")
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(idvPrimary)
            Text(incident.incidentDescription)
                .font(.system(.body, design: .rounded))
                .foregroundStyle(.primary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }

    // MARK: - Status Card
    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Status", systemImage: "flag.fill")
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(idvPrimary)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(isResolved ? "Resolved" : "Open")
                        .font(.system(.headline, design: .rounded).weight(.semibold))
                        .foregroundStyle(isResolved ? idvGreen : idvRed)
                    Text("Filed \(Self.dateFormatter.string(from: incident.createdAt))")
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if isResolved {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 28))
                        .foregroundStyle(idvGreen)
                } else {
                    Image(systemName: "exclamationmark.circle.fill")
                        .font(.system(size: 28))
                        .foregroundStyle(idvRed)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }

    // MARK: - Resolution Card
    private var resolutionCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Resolution Notes", systemImage: "checkmark.seal.fill")
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
                .foregroundStyle(idvGreen)

            TextEditor(text: $resolutionNotes)
                .font(.system(.body, design: .rounded))
                .frame(minHeight: 80)
                .scrollContentBackground(.hidden)
                .padding(10)
                .background(Color(.secondarySystemGroupedBackground))
                .clipShape(RoundedRectangle(cornerRadius: 10))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.07), radius: 10)
    }

    // MARK: - Action Button
    private var actionButton: some View {
        Button {
            toggleResolution()
        } label: {
            HStack(spacing: 10) {
                Image(systemName: isResolved ? "arrow.uturn.left.circle.fill" : "checkmark.circle.fill")
                    .font(.system(size: 18, weight: .semibold))
                Text(isResolved ? "Re-open Incident" : "Mark as Resolved")
                    .font(.system(.headline, design: .rounded))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                isResolved
                    ? LinearGradient(colors: [idvGold, Color(red: 0.85, green: 0.50, blue: 0.05)], startPoint: .leading, endPoint: .trailing)
                    : LinearGradient(colors: [idvGreen, Color(red: 0.10, green: 0.60, blue: 0.25)], startPoint: .leading, endPoint: .trailing)
            )
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: (isResolved ? idvGold : idvGreen).opacity(0.35), radius: 10, y: 4)
        }
        .buttonStyle(.plain)
    }

    // MARK: - Logic
    private func toggleResolution() {
        let newState = !isResolved
        incident.isResolved = newState
        if newState {
            incident.resolutionNotes = resolutionNotes.isEmpty ? nil : resolutionNotes
        } else {
            incident.resolutionNotes = nil
        }
        incident.updatedAt = Date()
        motelData.updateIncident(incident)
        isResolved = newState

        let haptic = UIImpactFeedbackGenerator(style: .medium)
        haptic.impactOccurred()
    }
}
