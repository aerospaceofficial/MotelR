//  RoomPicker.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Environment Key (optional injection)

struct RoomPickerKey: EnvironmentKey {
    static let defaultValue: CDRoom? = nil
}

extension EnvironmentValues {
    var selectedPickerRoom: CDRoom? {
        get { self[RoomPickerKey.self] }
        set { self[RoomPickerKey.self] = newValue }
    }
}

// MARK: - RoomPickerView
// Full-featured horizontal card picker used in booking forms.
// Shows only rooms that are NOT currently in motelData.bookings (i.e., no active booking).

struct RoomPickerView: View {
    @EnvironmentObject var motelData: MotelData

    /// The currently selected room (two-way binding).
    @Binding var selectedRoom: CDRoom?

    /// Optional: provide check-in / check-out dates to filter more precisely.
    /// When nil, any room with an active booking is considered unavailable.
    var checkInDate:  Date?
    var checkOutDate: Date?

    // MARK: Computed

    private var availableRooms: [CDRoom] {
        motelData.rooms.filter { room in
            !motelData.bookings.contains { booking in
                guard booking.room.id == room.id else { return false }
                // Date-aware filtering when dates are provided
                if let ci = checkInDate, let co = checkOutDate {
                    return ci < booking.checkOutDate && booking.checkInDate < co
                }
                return true // no dates supplied → any active booking blocks the room
            }
        }
        .sorted { $0.number < $1.number }
    }

    // MARK: Body

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if availableRooms.isEmpty {
                emptyState
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(availableRooms) { room in
                            RoomPickerCard(
                                room: room,
                                isSelected: selectedRoom?.id == room.id
                            )
                            .onTapGesture {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    if selectedRoom?.id == room.id {
                                        selectedRoom = nil
                                    } else {
                                        selectedRoom = room
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 2)
                    .padding(.vertical, 4)
                }
            }
        }
    }

    // MARK: Empty State

    private var emptyState: some View {
        HStack(spacing: 10) {
            Image(systemName: "bed.double.fill")
                .foregroundColor(.secondary)
            Text("No rooms available for the selected dates.")
                .font(.system(size: 13, design: .rounded))
                .foregroundColor(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color(.systemFill))
        .cornerRadius(14)
    }
}

// MARK: - RoomPickerCard

struct RoomPickerCard: View {
    let room: CDRoom
    let isSelected: Bool

    private let selectedGradient = LinearGradient(
        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                 Color(red: 0.05, green: 0.12, blue: 0.65)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    var body: some View {
        VStack(spacing: 8) {
            // Room number badge
            ZStack {
                Circle()
                    .fill(isSelected
                          ? AnyShapeStyle(selectedGradient)
                          : AnyShapeStyle(Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.10)))
                    .frame(width: 48, height: 48)
                Text("\(room.number)")
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundColor(isSelected ? .white : Color(red: 0.18, green: 0.27, blue: 0.90))
            }

            // Room name
            if !room.name.isEmpty {
                Text(room.name)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundColor(isSelected ? Color(red: 0.18, green: 0.27, blue: 0.90) : .primary)
                    .lineLimit(1)
            }

            // Members
            if !room.members.isEmpty {
                Text(room.members)
                    .font(.system(size: 10, design: .rounded))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
            }

            // Available badge
            HStack(spacing: 3) {
                Circle()
                    .fill(Color(red: 0.20, green: 0.78, blue: 0.35))
                    .frame(width: 6, height: 6)
                Text("Available")
                    .font(.system(size: 9, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.20, green: 0.78, blue: 0.35))
            }
            .padding(.horizontal, 6)
            .padding(.vertical, 3)
            .background(Color(red: 0.20, green: 0.78, blue: 0.35).opacity(0.10))
            .cornerRadius(6)

            // Checkmark overlay indicator
            if isSelected {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: 14))
                    .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 14)
        .frame(width: 100)
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(
                    isSelected
                    ? Color(red: 0.18, green: 0.27, blue: 0.90)
                    : Color(.separator).opacity(0.5),
                    lineWidth: isSelected ? 2.0 : 1.0
                )
        )
        .shadow(
            color: isSelected
                ? Color(red: 0.05, green: 0.12, blue: 0.65).opacity(0.20)
                : Color.black.opacity(0.06),
            radius: isSelected ? 10 : 6,
            x: 0, y: 3
        )
        .scaleEffect(isSelected ? 1.04 : 1.0)
    }
}

// MARK: - RoomDropdownPicker
// Simpler Picker-based variant for contexts where a dropdown is more appropriate.

struct RoomDropdownPicker: View {
    @EnvironmentObject var motelData: MotelData

    /// Binding to the selected room's number string (for backward compat with existing form code).
    @Binding var selectedRoomNumber: String

    var checkInDate:  Date?
    var checkOutDate: Date?

    private var availableRooms: [CDRoom] {
        motelData.rooms.filter { room in
            !motelData.bookings.contains { booking in
                guard booking.room.id == room.id else { return false }
                if let ci = checkInDate, let co = checkOutDate {
                    return ci < booking.checkOutDate && booking.checkInDate < co
                }
                return true
            }
        }
        .sorted { $0.number < $1.number }
    }

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "bed.double.fill")
                .font(.system(size: 16))
                .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                .frame(width: 24)

            if availableRooms.isEmpty {
                Text("No available rooms")
                    .font(.system(size: 15, design: .rounded))
                    .foregroundColor(.secondary)
                Spacer()
            } else {
                Picker("Select Room", selection: $selectedRoomNumber) {
                    Text("Select a room").tag("")
                    ForEach(availableRooms) { room in
                        Text(dropdownLabel(for: room))
                            .tag(String(room.number))
                    }
                }
                .pickerStyle(.menu)
                .font(.system(size: 15, design: .rounded))
                .accentColor(Color(red: 0.18, green: 0.27, blue: 0.90))
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color(.systemFill))
        .cornerRadius(12)
    }

    private func dropdownLabel(for room: CDRoom) -> String {
        var parts = ["Room \(room.number)"]
        if !room.name.isEmpty    { parts.append(room.name) }
        if !room.members.isEmpty { parts.append("· \(room.members)") }
        return parts.joined(separator: " ")
    }
}

// MARK: - Legacy RoomPicker (kept for existing call-sites)
// Presents a full-screen modal list of available rooms.

struct RoomPicker: View {
    @Binding var selectedRoom: String
    @Binding var showPicker: Bool
    @EnvironmentObject var motelData: MotelData

    @State private var searchText = ""

    private var availableRooms: [CDRoom] {
        motelData.rooms
            .filter { room in
                !motelData.bookings.contains { $0.room.number == room.number }
            }
            .sorted { $0.number < $1.number }
    }

    private var filteredRooms: [CDRoom] {
        guard !searchText.isEmpty else { return availableRooms }
        return availableRooms.filter {
            "\($0.number)".contains(searchText) ||
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.members.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()

                VStack(spacing: 0) {
                    // Search bar
                    SearchBar(text: $searchText, placeholder: "Search rooms…")
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)

                    if filteredRooms.isEmpty {
                        Spacer()
                        VStack(spacing: 12) {
                            Image(systemName: "bed.double.fill")
                                .font(.system(size: 48))
                                .foregroundColor(.secondary.opacity(0.4))
                            Text("No available rooms")
                                .font(.system(size: 17, weight: .medium, design: .rounded))
                                .foregroundColor(.secondary)
                            Text("\(motelData.rooms.count) rooms registered, all currently occupied.")
                                .font(.system(size: 13, design: .rounded))
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .padding(.horizontal, 32)
                        Spacer()
                    } else {
                        List {
                            Section(header: Text("\(filteredRooms.count) room\(filteredRooms.count == 1 ? "" : "s") available")) {
                                ForEach(filteredRooms) { room in
                                    Button(action: {
                                        withAnimation(.spring()) {
                                            selectedRoom = String(room.number)
                                            showPicker = false
                                        }
                                    }) {
                                        HStack(spacing: 14) {
                                            ZStack {
                                                RoundedRectangle(cornerRadius: 10)
                                                    .fill(
                                                        LinearGradient(
                                                            colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                                                     Color(red: 0.05, green: 0.12, blue: 0.65)],
                                                            startPoint: .topLeading,
                                                            endPoint: .bottomTrailing
                                                        )
                                                    )
                                                    .frame(width: 42, height: 42)
                                                Text("\(room.number)")
                                                    .font(.system(size: 15, weight: .bold, design: .rounded))
                                                    .foregroundColor(.white)
                                            }

                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(room.name.isEmpty ? "Room \(room.number)" : room.name)
                                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                                    .foregroundColor(.primary)
                                                if !room.members.isEmpty {
                                                    Text(room.members)
                                                        .font(.system(size: 12, design: .rounded))
                                                        .foregroundColor(.secondary)
                                                }
                                            }

                                            Spacer()

                                            HStack(spacing: 3) {
                                                Circle()
                                                    .fill(Color(red: 0.20, green: 0.78, blue: 0.35))
                                                    .frame(width: 7, height: 7)
                                                Text("Available")
                                                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                                                    .foregroundColor(Color(red: 0.20, green: 0.78, blue: 0.35))
                                            }
                                        }
                                        .padding(.vertical, 4)
                                    }
                                }
                            }
                        }
                        .listStyle(.insetGrouped)
                    }
                }
            }
            .navigationTitle("Select Room")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        selectedRoom = ""
                        showPicker = false
                    }
                }
            }
        }
    }
}

// MARK: - Previews

struct RoomPickerView_Previews: PreviewProvider {
    @State static var room: CDRoom? = nil
    static var previews: some View {
        RoomPickerView(selectedRoom: $room)
            .environmentObject(MotelData())
            .padding()
    }
}

struct RoomDropdownPicker_Previews: PreviewProvider {
    @State static var roomNumber = ""
    static var previews: some View {
        RoomDropdownPicker(selectedRoomNumber: $roomNumber)
            .environmentObject(MotelData())
            .padding()
    }
}

struct RoomPicker_Previews: PreviewProvider {
    @State static var roomNumber = "101"
    @State static var showPicker = true
    static var previews: some View {
        RoomPicker(selectedRoom: $roomNumber, showPicker: $showPicker)
            .environmentObject(MotelData())
    }
}
