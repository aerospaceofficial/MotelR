//  ViewBookingsView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import CoreData
import AVFoundation
import Photos

// MARK: - Section enum

enum BookingSection: String, CaseIterable {
    case personal = "Guest"
    case room     = "Room"
    case payment  = "Payment"
    case review   = "Review"
}

// MARK: - ViewBookingsView

struct ViewBookingsView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    // ── Form state ──────────────────────────────────────────────────────────
    @State private var roomNumber              = ""
    @State private var selectedRoom: CDRoom?   = nil
    @State private var customerName            = ""
    @State private var phoneNumber             = ""
    @State private var drivingLicenseNumber    = ""
    @State private var address                 = ""
    @State private var city                    = ""
    @State private var state                   = ""
    @State private var zipCode                 = ""
    @State private var licenseImageData        = Data()
    @State private var signatureImage: UIImage?
    @State private var hasSignature            = false

    @State private var checkInDate             = Date()
    @State private var numberOfDays            = 1
    @State private var checkOutDate            = Calendar.current.date(byAdding: .day, value: 1, to: Date()) ?? Date()
    @State private var members                 = ""

    @State private var paymentMethod: PaymentMethod = .cash
    @State private var cardType                = ""
    @State private var checkNumber             = ""
    @State private var organizationName        = ""
    @State private var prize                   = ""
    @State private var isTaxed                 = true
    @State private var isPayLater              = true

    @State private var currentSection: BookingSection = .personal

    // ── UI control ──────────────────────────────────────────────────────────
    @State private var showAlert               = false
    @State private var alertMessage            = ""
    @State private var showImagePicker         = false
    @State private var showPhotoSource         = false
    @State private var photoSource: UIImagePickerController.SourceType = .photoLibrary
    @State private var showingRoomPicker       = false
    @State private var showSuccessOverlay      = false
    @State private var successScale: CGFloat   = 0.5
    @State private var successOpacity: Double  = 0
    @State private var showingIncidentWarning  = false
    @State private var pastIncidents: [CDIncidentReport] = []
    @State private var warnedLicense           = ""
    @State private var incidentWarningText     = ""

    // ── Optional pre-selected room ──────────────────────────────────────────
    init(preselectedRoom: String = "") {
        _roomNumber = State(initialValue: preselectedRoom)
    }

    // ── Design tokens ───────────────────────────────────────────────────────
    private let primaryColor = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let primaryGradient = LinearGradient(
        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                 Color(red: 0.05, green: 0.12, blue: 0.65)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let greenColor = Color(red: 0.20, green: 0.78, blue: 0.35)
    private let goldColor  = Color(red: 0.96, green: 0.65, blue: 0.14)
    private let redColor   = Color(red: 1.0,  green: 0.23, blue: 0.19)

    // ── Computed ─────────────────────────────────────────────────────────────
    private var totalAmount: Double {
        Double(prize.filter { "0123456789.".contains($0) }) ?? 0
    }
    private var taxRate: Double { motelData.taxRate }
    private var baseAmount: Double { isTaxed ? totalAmount / (1 + taxRate) : totalAmount }
    private var taxAmount: Double  { totalAmount - baseAmount }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()

                VStack(spacing: 0) {
                    progressDots
                        .padding(.horizontal, 16)
                        .padding(.top, 14)
                        .padding(.bottom, 4)

                    ScrollView {
                        VStack(spacing: 0) {
                            sectionContent
                                .transition(.asymmetric(
                                    insertion: .move(edge: .trailing).combined(with: .opacity),
                                    removal:   .move(edge: .leading).combined(with: .opacity)
                                ))
                                .id(currentSection)
                                .padding(.horizontal, 16)
                                .padding(.top, 14)

                            navButtons
                                .padding(.horizontal, 16)
                                .padding(.top, 24)
                                .padding(.bottom, 40)
                        }
                    }
                }

                if showSuccessOverlay { successView }
            }
            .navigationTitle("New Booking")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .alert("Missing Information", isPresented: $showAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(alertMessage)
            }
            .alert("Previous Incidents Found", isPresented: $showingIncidentWarning) {
                Button("Continue Anyway", role: .cancel) {}
            } message: {
                Text(buildIncidentWarning())
            }
            .sheet(isPresented: $showPhotoSource) {
                ImprovedPhotoSourcePicker(
                    showImagePicker: $showImagePicker,
                    isPresented: $showPhotoSource,
                    photoSource: $photoSource
                )
            }
            .sheet(isPresented: $showImagePicker) {
                ImprovedImagePicker(
                    imageData: $licenseImageData,
                    isPresented: $showImagePicker,
                    sourceType: photoSource,
                    onComplete: {}
                )
            }
            .sheet(isPresented: $showingRoomPicker) {
                RoomPicker(selectedRoom: $roomNumber, showPicker: $showingRoomPicker)
                    .environmentObject(motelData)
                    .onDisappear {
                        if let n = Int(roomNumber) {
                            selectedRoom = motelData.rooms.first { $0.number == CDRoom.clampedNumber(n) }
                        }
                    }
            }
        }
    }

    // MARK: - Progress dots
    private var progressDots: some View {
        let allCases = BookingSection.allCases
        let currentIdx = allCases.firstIndex(of: currentSection) ?? 0
        return HStack(spacing: 0) {
            ForEach(Array(allCases.enumerated()), id: \.element) { idx, section in
                let isDone    = idx < currentIdx
                let isCurrent = section == currentSection
                VStack(spacing: 6) {
                    ZStack {
                        Circle()
                            .fill(isDone ? greenColor : (isCurrent ? primaryColor : Color(UIColor.systemGray5)))
                            .frame(width: 34, height: 34)
                        if isDone {
                            Image(systemName: "checkmark")
                                .font(.system(size: 13, weight: .bold))
                                .foregroundColor(.white)
                        } else {
                            Text("\(idx + 1)")
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundColor(isCurrent ? .white : .secondary)
                        }
                    }
                    .shadow(color: isCurrent ? primaryColor.opacity(0.35) : .clear, radius: 5, y: 2)
                    Text(section.rawValue)
                        .font(.system(size: 10, weight: isCurrent ? .bold : .regular, design: .rounded))
                        .foregroundColor(isCurrent ? primaryColor : .secondary)
                }
                if section != allCases.last {
                    Rectangle()
                        .fill(idx < currentIdx ? greenColor : Color(UIColor.systemGray4))
                        .frame(height: 2)
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, 20)
                }
            }
        }
    }

    // MARK: - Section switcher
    /// Copies whatever the barcode gave us into the form. Only fills blank fields, so
    /// a re-scan never wipes something the clerk has already corrected by hand.
    private func applyScannedLicense(_ scanned: ScannedLicense) {
        if customerName.isEmpty         { customerName = scanned.fullName }
        if address.isEmpty              { address = scanned.address }
        if city.isEmpty                 { city = scanned.city }
        if state.isEmpty                { state = scanned.state }
        if zipCode.isEmpty              { zipCode = scanned.zipCode }
        if drivingLicenseNumber.isEmpty {
            drivingLicenseNumber = scanned.licenseNumber
            // Same guest-history lookup the manual field performs.
            if scanned.licenseNumber.count >= 5 {
                checkPastIncidents(id: scanned.licenseNumber)
            }
        }
    }

    @ViewBuilder
    private var sectionContent: some View {
        switch currentSection {
        case .personal: personalSection
        case .room:     roomSection
        case .payment:  paymentSection
        case .review:   reviewSection
        }
    }

    // ── Section 1: Personal Info ─────────────────────────────────────────
    private var personalSection: some View {
        VStack(spacing: 16) {
            // Optional shortcut — everything below can still be typed by hand.
            ScanLicenseButton { scanned in applyScannedLicense(scanned) }

            VBCard(title: "Personal Information", icon: "person.crop.circle.fill", color: primaryColor) {
                VBTextField(label: "Full Name *", placeholder: "Jane Smith", text: $customerName,
                            icon: "person", valid: !customerName.isEmpty)
                VBTextField(label: "Phone Number *", placeholder: "(555) 123-4567", text: $phoneNumber,
                            icon: "phone", keyboard: .phonePad, valid: phoneNumber.count >= 10)
                    .onChange(of: phoneNumber) { _, v in phoneNumber = formatPhone(v) }
                VBTextField(label: "Driving License # *", placeholder: "D12345678", text: $drivingLicenseNumber,
                            icon: "creditcard", valid: !drivingLicenseNumber.isEmpty)
                    .onChange(of: drivingLicenseNumber) { _, v in
                        if v.count >= 5 { checkPastIncidents(id: v) }
                    }
            }

            VBCard(title: "Address", icon: "location.fill", color: primaryColor) {
                VBTextField(label: "Street Address *", placeholder: "123 Main St", text: $address,
                            icon: "house", valid: !address.isEmpty)
                HStack(spacing: 10) {
                    VBTextField(label: "City *", placeholder: "Indianapolis", text: $city,
                                icon: "building.2", valid: !city.isEmpty)
                    StatePickerView(selectedState: $state)
                }
                VBTextField(label: "ZIP Code *", placeholder: "46201", text: $zipCode,
                            icon: "location", keyboard: .numberPad, valid: zipCode.count == 5)
            }

            VBCard(title: "License Photo", icon: "camera.fill", color: primaryColor) {
                if licenseImageData.isEmpty {
                    Button { showPhotoSource = true } label: {
                        HStack {
                            Spacer()
                            VStack(spacing: 10) {
                                Image(systemName: "camera.viewfinder")
                                    .font(.system(size: 34))
                                    .foregroundColor(primaryColor)
                                Text("Tap to capture or upload")
                                    .font(.system(size: 13, design: .rounded))
                                    .foregroundColor(primaryColor)
                            }
                            Spacer()
                        }
                        .padding(22)
                        .background(primaryColor.opacity(0.07))
                        .cornerRadius(14)
                        .overlay(RoundedRectangle(cornerRadius: 14)
                            .stroke(primaryColor.opacity(0.3), style: StrokeStyle(lineWidth: 1.5, dash: [6])))
                    }
                } else {
                    ZStack(alignment: .topTrailing) {
                        if let img = UIImage(data: licenseImageData) {
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 150)
                                .cornerRadius(12)
                        }
                        Button { licenseImageData = Data() } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 22))
                                .foregroundColor(.white)
                                .background(Circle().fill(Color.black.opacity(0.5)))
                        }
                        .padding(6)
                    }
                    Label("Photo uploaded", systemImage: "checkmark.circle.fill")
                        .font(.system(size: 13, design: .rounded))
                        .foregroundColor(greenColor)
                }
            }
        }
    }

    // ── Section 2: Room & Dates ──────────────────────────────────────────
    private var roomSection: some View {
        VStack(spacing: 16) {
            VBCard(title: "Select Room", icon: "bed.double.fill", color: primaryColor) {
                // Room cards grid
                let available = availableRoomsForDates
                if available.isEmpty {
                    VStack(spacing: 8) {
                        Image(systemName: "bed.double").font(.system(size: 28)).foregroundColor(.secondary)
                        Text("No rooms available for these dates")
                            .font(.system(size: 14, design: .rounded))
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity).padding(20)
                } else {
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                        ForEach(available, id: \.id) { room in
                            let isSel = selectedRoom?.id == room.id
                            Button {
                                withAnimation(.spring()) {
                                    selectedRoom = room
                                    roomNumber = String(room.number)
                                }
                            } label: {
                                VStack(spacing: 4) {
                                    Image(systemName: "bed.double").font(.system(size: 16))
                                        .foregroundColor(isSel ? .white : primaryColor)
                                    Text("\(room.number)")
                                        .font(.system(size: 15, weight: .bold, design: .rounded))
                                        .foregroundColor(isSel ? .white : .primary)
                                    if !room.name.isEmpty {
                                        Text(room.name)
                                            .font(.system(size: 9, design: .rounded))
                                            .foregroundColor(isSel ? .white.opacity(0.85) : .secondary)
                                            .lineLimit(1)
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(isSel
                                    ? primaryGradient
                                    : LinearGradient(colors: [Color(UIColor.systemGray6)], startPoint: .top, endPoint: .bottom))
                                .cornerRadius(12)
                                .shadow(color: isSel ? primaryColor.opacity(0.30) : .clear, radius: 6, y: 2)
                            }
                        }
                    }
                }
            }

            VBCard(title: "Stay Details", icon: "calendar", color: primaryColor) {
                VStack(spacing: 14) {
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Check-in Date", systemImage: "arrow.right.circle.fill")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundColor(.secondary)
                        DatePicker("", selection: $checkInDate, displayedComponents: .date)
                            .datePickerStyle(.compact)
                            .labelsHidden()
                            .onChange(of: checkInDate) { _, _ in syncDates() }
                    }
                    Divider()
                    HStack {
                        Label("Nights", systemImage: "moon.stars.fill")
                            .font(.system(size: 14, weight: .semibold, design: .rounded))
                        Spacer()
                        HStack(spacing: 14) {
                            Button {
                                if numberOfDays > 1 { numberOfDays -= 1; syncDates() }
                            } label: {
                                Image(systemName: "minus.circle.fill")
                                    .font(.system(size: 22))
                                    .foregroundColor(numberOfDays > 1 ? primaryColor : .secondary)
                            }
                            Text("\(numberOfDays)")
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                                .frame(minWidth: 28)
                            Button {
                                if numberOfDays < 30 { numberOfDays += 1; syncDates() }
                            } label: {
                                Image(systemName: "plus.circle.fill")
                                    .font(.system(size: 22))
                                    .foregroundColor(primaryColor)
                            }
                        }
                    }
                    Divider()
                    HStack {
                        Label("Check-out Date", systemImage: "arrow.left.circle.fill")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(DateFormatter.shortDate.string(from: checkOutDate))
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(primaryColor)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(primaryColor.opacity(0.10))
                            .cornerRadius(8)
                    }
                }
            }

            VBCard(title: "Members", icon: "person.2.fill", color: primaryColor) {
                VBTextField(label: "Number of Members", placeholder: "e.g. 2", text: $members,
                            icon: "person.2", keyboard: .numberPad, valid: true)
            }
        }
    }

    private var availableRoomsForDates: [CDRoom] {
        motelData.rooms.filter { room in
            !motelData.bookings.contains { b in
                b.room.id == room.id &&
                b.checkInDate < checkOutDate &&
                checkInDate < b.checkOutDate
            }
        }.sorted { $0.number < $1.number }
    }

    // ── Section 3: Payment ────────────────────────────────────────────────
    private var paymentSection: some View {
        VStack(spacing: 16) {
            VBCard(title: "Payment Method", icon: "creditcard.fill", color: primaryColor) {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ForEach(PaymentMethod.allCases, id: \.self) { method in
                        vbPaymentCard(method: method)
                    }
                }

                if paymentMethod == .card {
                    VBTextField(label: "Card Type", placeholder: "Visa / Mastercard / Amex",
                                text: $cardType, icon: "creditcard", valid: !cardType.isEmpty)
                        .padding(.top, 4)
                }
                if paymentMethod == .check {
                    VBTextField(label: "Check Number", placeholder: "e.g. 1042",
                                text: $checkNumber, icon: "doc.text.fill", valid: !checkNumber.isEmpty)
                        .padding(.top, 4)
                }
                if paymentMethod == .organization {
                    VBTextField(label: "Organization Name", placeholder: "ACME Corp",
                                text: $organizationName, icon: "building.2.fill", valid: !organizationName.isEmpty)
                        .padding(.top, 4)
                    Toggle(isOn: $isPayLater) {
                        Label("Bill Later (Pending)", systemImage: "clock.arrow.circlepath")
                            .font(.system(size: 14, design: .rounded))
                    }
                    .tint(goldColor)
                }
            }

            VBCard(title: "Price & Tax", icon: "dollarsign.circle.fill", color: primaryColor) {
                VBTextField(label: "Total Amount", placeholder: "89.00",
                            text: $prize, icon: "dollarsign.circle", keyboard: .decimalPad,
                            valid: totalAmount > 0)
                Toggle(isOn: $isTaxed) {
                    Label("Tax Included in Total", systemImage: "percent")
                        .font(.system(size: 14, design: .rounded))
                }
                .tint(primaryColor)

                if totalAmount > 0 && isTaxed {
                    VStack(spacing: 8) {
                        Divider()
                        vbPriceRow(label: "Base Amount", value: baseAmount)
                        vbPriceRow(label: "Tax (\(Int(taxRate * 100))%) included", value: taxAmount, secondary: true)
                        Divider()
                        vbPriceRow(label: "Total", value: totalAmount, isTotal: true)
                    }
                    .padding(.top, 4)
                }
            }
        }
    }

    private func vbPaymentCard(method: PaymentMethod) -> some View {
        let isSel = paymentMethod == method
        return Button { withAnimation(.spring()) { paymentMethod = method } } label: {
            VStack(spacing: 8) {
                Image(systemName: vbPaymentIcon(method))
                    .font(.system(size: 20, weight: .semibold))
                Text(method.rawValue)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .background(isSel ? primaryColor : Color(UIColor.systemGray6))
            .foregroundColor(isSel ? .white : .primary)
            .cornerRadius(14)
            .shadow(color: isSel ? primaryColor.opacity(0.28) : .clear, radius: 6, y: 2)
        }
    }

    private func vbPaymentIcon(_ m: PaymentMethod) -> String {
        switch m {
        case .cash:         return "banknote"
        case .check:        return "doc.text.fill"
        case .card:         return "creditcard.fill"
        case .organization: return "building.2.fill"
        }
    }

    private func vbPriceRow(label: String, value: Double, secondary: Bool = false, isTotal: Bool = false) -> some View {
        HStack {
            Text(label)
                .font(.system(size: secondary ? 13 : (isTotal ? 15 : 14),
                              weight: isTotal ? .bold : .regular, design: .rounded))
                .foregroundColor(secondary ? .secondary : .primary)
            Spacer()
            Text(String(format: "$%.2f", value))
                .font(.system(size: secondary ? 13 : (isTotal ? 15 : 14),
                              weight: isTotal ? .bold : .medium, design: .rounded))
                .foregroundColor(isTotal ? primaryColor : (secondary ? .secondary : .primary))
        }
    }

    // ── Section 4: Review & Sign ─────────────────────────────────────────
    private var reviewSection: some View {
        VStack(spacing: 16) {
            VBCard(title: "Booking Summary", icon: "list.bullet.clipboard.fill", color: primaryColor) {
                vbSummaryRow(label: "Guest",    value: customerName)
                vbSummaryRow(label: "Phone",    value: phoneNumber)
                vbSummaryRow(label: "Room",     value: selectedRoom.map { "Room \($0.number)" } ?? (roomNumber.isEmpty ? "—" : "Room \(roomNumber)"))
                vbSummaryRow(label: "Check-in", value: DateFormatter.shortDate.string(from: checkInDate))
                vbSummaryRow(label: "Check-out",value: DateFormatter.shortDate.string(from: checkOutDate))
                vbSummaryRow(label: "Nights",   value: "\(numberOfDays)")
                vbSummaryRow(label: "Payment",  value: paymentMethod.rawValue)
                vbSummaryRow(label: "Total",    value: String(format: "$%.2f", totalAmount), highlight: true)
                if isTaxed {
                    vbSummaryRow(label: "Tax Rate", value: "\(Int(taxRate * 100))%")
                }
            }

            HStack(spacing: 6) {
                Image(systemName: "doc.text")
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
                Text("Terms v\(TermsAndConditionsManager.shared.termsVersion)")
                    .font(.system(size: 12, design: .rounded))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 4)

            VBCard(title: "Guest Signature", icon: "signature", color: primaryColor) {
                SignatureStepView(
                    signatureImage: $signatureImage,
                    hasSignature: $hasSignature,
                    customerName: customerName
                )
            }

            // Submit button
            Button { submitBooking() } label: {
                HStack {
                    Spacer()
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 18, weight: .bold))
                    Text("Complete Booking")
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                    Spacer()
                }
                .foregroundColor(.white)
                .padding(.vertical, 18)
                .background(hasSignature
                    ? primaryGradient
                    : LinearGradient(colors: [Color.gray], startPoint: .leading, endPoint: .trailing))
                .cornerRadius(16)
                .shadow(color: hasSignature ? primaryColor.opacity(0.30) : .clear, radius: 10, y: 4)
            }
            .disabled(!hasSignature)
            .animation(.easeInOut, value: hasSignature)
        }
    }

    private func vbSummaryRow(label: String, value: String, highlight: Bool = false) -> some View {
        HStack {
            Text(label)
                .font(.system(size: 13, design: .rounded))
                .foregroundColor(.secondary)
                .frame(width: 75, alignment: .leading)
            Spacer()
            Text(value)
                .font(.system(size: 13, weight: highlight ? .bold : .medium, design: .rounded))
                .foregroundColor(highlight ? primaryColor : .primary)
                .multilineTextAlignment(.trailing)
        }
        .padding(.vertical, 2)
    }

    // MARK: - Navigation buttons
    private var navButtons: some View {
        let allCases   = BookingSection.allCases
        let idx        = allCases.firstIndex(of: currentSection) ?? 0
        let isFirst    = idx == 0
        let isLast     = idx == allCases.count - 1

        return HStack(spacing: 14) {
            if !isFirst {
                Button {
                    withAnimation(.easeInOut(duration: 0.28)) {
                        currentSection = allCases[idx - 1]
                    }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundColor(primaryColor)
                    .padding(.horizontal, 22)
                    .padding(.vertical, 13)
                    .background(primaryColor.opacity(0.10))
                    .cornerRadius(12)
                }
            }
            Spacer()
            if !isLast {
                Button {
                    if validateSection() {
                        withAnimation(.easeInOut(duration: 0.28)) {
                            currentSection = allCases[idx + 1]
                        }
                    }
                } label: {
                    HStack(spacing: 5) {
                        Text("Next")
                        Image(systemName: "chevron.right")
                    }
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.horizontal, 26)
                    .padding(.vertical, 13)
                    .background(primaryGradient)
                    .cornerRadius(12)
                    .shadow(color: primaryColor.opacity(0.28), radius: 7, y: 3)
                }
            }
        }
    }

    // MARK: - Success overlay
    private var successView: some View {
        ZStack {
            Color.black.opacity(0.45).ignoresSafeArea()
            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .fill(greenColor)
                        .frame(width: 96, height: 96)
                    Image(systemName: "checkmark")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundColor(.white)
                }
                .scaleEffect(successScale)
                .opacity(successOpacity)

                Text("Booking Confirmed!")
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .opacity(successOpacity)
                Text("\(customerName) is now checked in to Room \(selectedRoom.map { String($0.number) } ?? roomNumber).")
                    .font(.system(size: 15, design: .rounded))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .opacity(successOpacity)
            }
            .padding(36)
            .background(Color(UIColor.systemBackground).opacity(0.97))
            .cornerRadius(24)
            .shadow(color: .black.opacity(0.15), radius: 20, y: 8)
            .padding(.horizontal, 36)
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                successScale  = 1
                successOpacity = 1
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) { dismiss() }
        }
    }

    // MARK: - Validation
    private func validateSection() -> Bool {
        switch currentSection {
        case .personal:
            let missing = [
                customerName.isEmpty        ? "Full Name" : nil,
                phoneNumber.count < 10      ? "Phone Number" : nil,
                drivingLicenseNumber.isEmpty ? "Driving License #" : nil,
                address.isEmpty             ? "Street Address" : nil,
                city.isEmpty                ? "City" : nil,
                state.isEmpty               ? "State" : nil,
                zipCode.isEmpty             ? "ZIP Code" : nil
            ].compactMap { $0 }
            if !missing.isEmpty {
                alertMessage = "Please fill in:\n• " + missing.joined(separator: "\n• ")
                showAlert = true
                return false
            }
        case .room:
            let resolvedRoom = selectedRoom ?? motelData.rooms.first { $0.number == CDRoom.clampedNumber(Int(roomNumber) ?? -1) }
            if resolvedRoom == nil {
                alertMessage = "Please select a room."
                showAlert = true
                return false
            }
            selectedRoom = resolvedRoom
        case .payment:
            if prize.trimmingCharacters(in: .whitespaces).isEmpty {
                alertMessage = "Please enter the total amount."
                showAlert = true
                return false
            }
            if paymentMethod == .card && cardType.isEmpty {
                alertMessage = "Please enter the card type."
                showAlert = true
                return false
            }
            if paymentMethod == .check && checkNumber.isEmpty {
                alertMessage = "Please enter the check number."
                showAlert = true
                return false
            }
            if paymentMethod == .organization && organizationName.isEmpty {
                alertMessage = "Please enter the organization name."
                showAlert = true
                return false
            }
        case .review:
            break
        }
        return true
    }

    // MARK: - Submit
    private func submitBooking() {
        guard hasSignature else { return }

        // Resolve room
        let room: CDRoom
        if let r = selectedRoom {
            room = r
        } else if let n = Int(roomNumber), let r = motelData.rooms.first(where: { $0.number == CDRoom.clampedNumber(n) }) {
            room = r
        } else {
            alertMessage = "Please go back and select a room."
            showAlert = true
            return
        }

        let finalPrize = prize.hasPrefix("$") ? prize : "$\(prize)"
        let sigData    = signatureImage?.jpegData(compressionQuality: 0.8)
        // The photo goes inside the booking so it syncs to the owner's other devices.
        let storedLicensePhoto: Data? = licenseImageData.isEmpty ? nil : LicenseImageManager.prepareForStorage(licenseImageData)

        let newBooking = CDBooking(
            context: CoreDataManager.shared.context,
            room: room,
            customerName: customerName,
            phoneNumber: phoneNumber,
            drivingLicenseNumber: drivingLicenseNumber,
            address: address,
            city: city,
            state: state,
            zipCode: zipCode,
            licenseImageData: storedLicensePhoto,
            signatureImageData: sigData,
            paymentMethodEnum: paymentMethod,
            cardType: paymentMethod == .card ? cardType : nil,
            checkNumber: paymentMethod == .check ? checkNumber : nil,
            organizationName: paymentMethod == .organization ? organizationName : nil,
            prize: finalPrize,
            numberOfDays: numberOfDays,
            checkInDate: checkInDate,
            checkOutDate: checkOutDate,
            isTaxed: isTaxed
        )
        newBooking.paymentStatus = (paymentMethod == .organization && isPayLater)
            ? PaymentStatus.pending.rawValue
            : PaymentStatus.paid.rawValue

        let success = motelData.addBooking(newBooking)
        if success {
            scheduleCheckoutReminderNotification(booking: newBooking)
            let gen = UINotificationFeedbackGenerator()
            gen.notificationOccurred(.success)
            withAnimation { showSuccessOverlay = true }
        } else {
            alertMessage = "Room \(room.number) is already booked for these dates. Please choose a different room or dates."
            showAlert = true
        }
    }

    // MARK: - Helpers
    private func syncDates() {
        checkOutDate = Calendar.current.date(byAdding: .day, value: numberOfDays, to: checkInDate) ?? checkInDate
    }

    private func formatPhone(_ raw: String) -> String {
        let digits = raw.filter { "0123456789".contains($0) }
        var out = ""
        for (i, c) in digits.enumerated() {
            if i == 0 { out.append("(") }
            if i == 3 { out.append(") ") }
            if i == 6 { out.append("-") }
            out.append(c)
        }
        return String(out.prefix(14))
    }

    /// Warns once per licence number — typing more characters after a match no
    /// longer pops the same alert again on every keystroke.
    private func checkPastIncidents(id: String) {
        let key = MotelData.normalizedLicense(id)
        guard key != warnedLicense else { return }
        pastIncidents = motelData.getIncidentsForCustomer(withID: id)
        if let message = motelData.incidentWarningMessage(forLicense: id) {
            warnedLicense = key
            incidentWarningText = message
            showingIncidentWarning = true
        }
    }

    private func buildIncidentWarning() -> String {
        incidentWarningText
    }
}

// MARK: - VBCard — shared card container

struct VBCard<Content: View>: View {
    let title: String
    let icon: String
    let color: Color
    @ViewBuilder let content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(color)
                Text(title)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            content()
        }
        .padding(16)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }
}

// MARK: - VBTextField — validated text field

struct VBTextField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var icon: String = ""
    var keyboard: UIKeyboardType = .default
    var valid: Bool = true

    private let primary = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let green   = Color(red: 0.20, green: 0.78, blue: 0.35)

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundColor(.secondary)
            HStack(spacing: 8) {
                if !icon.isEmpty {
                    Image(systemName: icon)
                        .font(.system(size: 13))
                        .foregroundColor(primary)
                        .frame(width: 16)
                }
                TextField(placeholder, text: $text)
                    .font(.system(size: 14, design: .rounded))
                    .keyboardType(keyboard)
                if !text.isEmpty {
                    Image(systemName: valid ? "checkmark.circle.fill" : "exclamationmark.circle.fill")
                        .font(.system(size: 13))
                        .foregroundColor(valid ? green : .orange)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(!text.isEmpty && !valid ? Color.orange.opacity(0.5) : Color.clear, lineWidth: 1)
            )
        }
    }
}

// MARK: - cardStyle extension (retained for compatibility)
extension View {
    func cardStyle() -> some View {
        self.padding()
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(10)
            .shadow(radius: 1)
    }
}

// MARK: - Preview
struct ViewBookingsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ViewBookingsView()
                .environmentObject(MotelData())
        }
    }
}
