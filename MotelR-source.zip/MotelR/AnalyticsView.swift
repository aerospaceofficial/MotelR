//  AnalyticsView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - Date Range

enum AnalyticsRange: String, CaseIterable, Identifiable {
    case today    = "Today"
    case week     = "Week"
    case month    = "Month"
    case year     = "Year"
    case allTime  = "All Time"
    var id: String { rawValue }
}

// MARK: - AnalyticsView

struct AnalyticsView: View {
    @EnvironmentObject var motelData: MotelData

    @State private var selectedRange: AnalyticsRange = .month
    @State private var showTaxSetup    = false
    @State private var showShareSheet  = false
    @State private var shareText       = ""

    // Animated counters
    @State private var animatedRevenue: Double = 0
    @State private var barsReady = false

    // MARK: - Computed

    /// The stretch of time the selected range covers.
    private var periodInterval: DateInterval {
        let cal = Calendar.current
        let now = Date()
        switch selectedRange {
        case .today:
            let start = cal.startOfDay(for: now)
            return DateInterval(start: start, end: cal.date(byAdding: .day, value: 1, to: start) ?? now)
        case .week:
            return DateInterval(start: cal.date(byAdding: .day, value: -7, to: now) ?? now, end: now)
        case .month:
            return DateInterval(start: cal.date(byAdding: .month, value: -1, to: now) ?? now, end: now)
        case .year:
            return DateInterval(start: cal.date(byAdding: .year, value: -1, to: now) ?? now, end: now)
        case .allTime:
            let earliest = (motelData.bookings + motelData.history).map { $0.checkInDate }.min() ?? now
            return DateInterval(start: min(earliest, now), end: now)
        }
    }

    /// Bookings whose stay overlaps the selected period. Future reservations are not
    /// counted in past periods any more.
    private var filteredBookings: [CDBooking] {
        let period = periodInterval
        return (motelData.bookings + motelData.history).filter {
            $0.checkInDate < period.end && $0.checkOutDate >= period.start
        }
    }

    /// Money actually received. Unpaid organization invoices are shown separately as
    /// "Pending", matching the Dashboard and Reports.
    private var paidBookings: [CDBooking] {
        filteredBookings.filter { $0.paymentStatusEnum == .paid }
    }

    private var totalRevenue: Double {
        paidBookings.reduce(0) { $0 + $1.prizeAmount }
    }

    private var taxCollected: Double {
        paidBookings.filter { $0.isTaxed }.reduce(0) { sum, b in
            let amt = b.prizeAmount
            let base = amt / (1 + motelData.taxRate)
            return sum + (amt - base)
        }
    }

    private var pendingAmount: Double {
        filteredBookings.filter { $0.paymentStatusEnum == .pending }.reduce(0) { $0 + $1.prizeAmount }
    }

    private var avgRevenuePerBooking: Double {
        paidBookings.isEmpty ? 0 : totalRevenue / Double(paidBookings.count)
    }

    private var revenueByMethod: [(PaymentMethod, Double)] {
        var dict: [PaymentMethod: Double] = [:]
        for b in paidBookings { dict[b.paymentMethodEnum, default: 0] += b.prizeAmount }
        return PaymentMethod.allCases.map { ($0, dict[$0] ?? 0) }
    }

    /// First and last day (start of day, end exclusive) of the selected period.
    private var periodDays: (start: Date, end: Date, count: Int) {
        let cal = Calendar.current
        let period = periodInterval
        let start = cal.startOfDay(for: period.start)
        let end: Date
        if selectedRange == .today {
            end = cal.startOfDay(for: period.end)
        } else {
            end = cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: period.end)) ?? period.end
        }
        let count = max(1, cal.dateComponents([.day], from: start, to: end).day ?? 1)
        return (start, end, count)
    }

    /// Room-nights that fall inside the selected period (a 5-night stay that started
    /// before the period only counts the nights inside it).
    private var totalNightsSold: Int {
        let cal = Calendar.current
        let days = periodDays
        return filteredBookings.reduce(0) { sum, b in
            let from = max(cal.startOfDay(for: b.checkInDate), days.start)
            let to   = min(cal.startOfDay(for: b.checkOutDate), days.end)
            return sum + max(0, cal.dateComponents([.day], from: from, to: to).day ?? 0)
        }
    }

    private var avgLengthOfStay: Double {
        filteredBookings.isEmpty ? 0
            : Double(filteredBookings.map { Int($0.numberOfDays) }.reduce(0, +)) / Double(filteredBookings.count)
    }

    /// Share of available room-nights that were sold during the selected period.
    /// (Before, this was a snapshot of today whatever range was picked.)
    private var avgOccupancyRate: Double {
        guard motelData.rooms.count > 0 else { return 0 }
        let available = periodDays.count * motelData.rooms.count
        return min(100, Double(totalNightsSold) / Double(available) * 100)
    }

    /// Rooms ranked by total revenue in the filtered window
    private var topRooms: [(CDRoom, Double)] {
        var dict: [Int16: Double] = [:]
        for b in paidBookings { dict[b.room.number, default: 0] += b.prizeAmount }
        return motelData.rooms
            .map { ($0, dict[$0.number] ?? 0) }
            .sorted { $0.1 > $1.1 }
    }

    /// Last 7 days — (dayLabel, bookingCount)
    private var last7Days: [(String, Int)] {
        let cal  = Calendar.current
        let now  = Date()
        let fmt  = DateFormatter(); fmt.dateFormat = "EEE"
        return (0..<7).reversed().map { offset -> (String, Int) in
            let day   = cal.date(byAdding: .day, value: -offset, to: now) ?? now
            let label = fmt.string(from: day)
            let count = (motelData.bookings + motelData.history)
                .filter { cal.isDate($0.checkInDate, inSameDayAs: day) }
                .count
            return (label, count)
        }
    }

    // MARK: - Body

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                rangePicker
                revenueSummaryCard
                paymentMethodBarsCard
                occupancyStatsCard
                topRoomsCard
                recentTrendsCard
                exportButton
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 40)
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Analytics")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: { showTaxSetup = true }) {
                    Image(systemName: "percent")
                        .font(.system(size: 14, weight: .semibold))
                }
            }
        }
        .sheet(isPresented: $showTaxSetup) {
            TaxSetupView(currentRate: motelData.taxRate) { rate in motelData.taxRate = rate }
        }
        .sheet(isPresented: $showShareSheet) {
            SharedActivityView(activityItems: [shareText])
        }
        .onAppear { triggerAnimations() }
        .onChange(of: selectedRange) { _, _ in triggerAnimations() }
        .onChange(of: motelData.bookings.count) { _, _ in triggerAnimations() }
        .onChange(of: motelData.history.count)  { _, _ in triggerAnimations() }
    }

    // MARK: - Range Picker

    private var rangePicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(AnalyticsRange.allCases) { range in
                    Button(action: {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) {
                            selectedRange = range
                        }
                    }) {
                        Text(range.rawValue)
                            .font(.system(size: 13, weight: selectedRange == range ? .bold : .medium, design: .rounded))
                            .foregroundColor(selectedRange == range ? .white : .primary)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(
                                selectedRange == range
                                ? AnyView(LinearGradient(colors: [primaryColor, primaryDark], startPoint: .leading, endPoint: .trailing).clipShape(Capsule()))
                                : AnyView(Color(.systemGray5).clipShape(Capsule()))
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 4)
        }
    }

    // MARK: - Revenue Summary Card

    private var revenueSummaryCard: some View {
        ZStack {
            LinearGradient(
                colors: [primaryColor, primaryDark],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .cornerRadius(20)

            VStack(spacing: 16) {
                // Main revenue number
                VStack(spacing: 4) {
                    Text("Total Revenue")
                        .font(.system(size: 13, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.75))
                    Text(String(format: "$%.2f", animatedRevenue))
                        .font(.system(size: 38, weight: .black, design: .rounded))
                        .foregroundColor(.white)
                        .contentTransition(.numericText(value: animatedRevenue))
                }
                .padding(.top, 20)

                // 3 sub-stats
                HStack(spacing: 0) {
                    revenueSubStat(
                        label: "Tax Collected",
                        value: String(format: "$%.2f", taxCollected),
                        icon: "percent"
                    )
                    Divider().frame(height: 36).background(Color.white.opacity(0.25))
                    revenueSubStat(
                        label: "Pending",
                        value: String(format: "$%.2f", pendingAmount),
                        icon: "clock"
                    )
                    Divider().frame(height: 36).background(Color.white.opacity(0.25))
                    revenueSubStat(
                        label: "Avg / Booking",
                        value: String(format: "$%.0f", avgRevenuePerBooking),
                        icon: "divide.circle"
                    )
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 20)
            }
        }
    }

    private func revenueSubStat(label: String, value: String, icon: String) -> some View {
        VStack(spacing: 4) {
            Image(systemName: icon)
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(.white.opacity(0.70))
            Text(value)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundColor(.white)
            Text(label)
                .font(.system(size: 10, design: .rounded))
                .foregroundColor(.white.opacity(0.65))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Payment Method Bars Card

    private var paymentMethodBarsCard: some View {
        analyticsCard(title: "Revenue by Payment Method", icon: "chart.bar.fill", iconColor: primaryColor) {
            VStack(spacing: 14) {
                ForEach(revenueByMethod, id: \.0) { method, amount in
                    AnimatedBarRow(
                        label: method.rawValue,
                        amount: amount,
                        total: totalRevenue,
                        color: colorFor(method),
                        isReady: barsReady
                    )
                }
            }
        }
    }

    private func colorFor(_ method: PaymentMethod) -> Color {
        switch method {
        case .cash:         return greenColor
        case .card:         return primaryColor
        case .check:        return Color.orange
        case .organization: return Color.purple
        }
    }

    // MARK: - Occupancy Stats Card

    private var occupancyStatsCard: some View {
        analyticsCard(title: "Occupancy Stats", icon: "bed.double.fill", iconColor: .indigo) {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                occupancyTile(
                    value: (avgOccupancyRate > 0 && avgOccupancyRate < 1 ? "<1%" : String(format: "%.0f%%", avgOccupancyRate)),
                    label: "Occupancy Rate",
                    icon: "chart.pie.fill",
                    color: primaryColor
                )
                occupancyTile(
                    value: "\(totalNightsSold)",
                    label: "Nights Sold",
                    icon: "moon.stars.fill",
                    color: .indigo
                )
                occupancyTile(
                    value: String(format: "%.1f", avgLengthOfStay),
                    label: "Avg Stay (nights)",
                    icon: "calendar.badge.clock",
                    color: Color.orange
                )
            }
        }
    }

    private func occupancyTile(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(color)
            Text(value)
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundColor(.primary)
            Text(label)
                .font(.system(size: 10, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(12)
        .background(color.opacity(0.08))
        .cornerRadius(14)
    }

    // MARK: - Top Rooms Card

    private var topRoomsCard: some View {
        analyticsCard(title: "Top Rooms", icon: "trophy.fill", iconColor: goldColor) {
            if topRooms.isEmpty {
                Text("No room data available.")
                    .font(.system(size: 14, design: .rounded))
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.vertical, 8)
            } else {
                VStack(spacing: 8) {
                    ForEach(Array(topRooms.prefix(5).enumerated()), id: \.offset) { index, pair in
                        let (room, revenue) = pair
                        HStack(spacing: 12) {
                            // Rank badge
                            ZStack {
                                Circle()
                                    .fill(rankColor(index).opacity(0.15))
                                    .frame(width: 32, height: 32)
                                Text("#\(index + 1)")
                                    .font(.system(size: 11, weight: .black, design: .rounded))
                                    .foregroundColor(rankColor(index))
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Room \(room.number)")
                                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                                Text(room.name.isEmpty ? "\(room.members) guests" : room.name)
                                    .font(.system(size: 11, design: .rounded))
                                    .foregroundColor(.secondary)
                            }
                            Spacer()
                            Text(String(format: "$%.0f", revenue))
                                .font(.system(size: 15, weight: .bold, design: .rounded))
                                .foregroundColor(primaryColor)
                        }
                        if index < min(4, topRooms.count - 1) { Divider() }
                    }
                }
            }
        }
    }

    private func rankColor(_ index: Int) -> Color {
        switch index {
        case 0: return goldColor
        case 1: return Color(.systemGray)
        case 2: return Color(red: 0.80, green: 0.50, blue: 0.20)
        default: return primaryColor.opacity(0.6)
        }
    }

    // MARK: - Recent Trends Card

    private var recentTrendsCard: some View {
        analyticsCard(title: "Last 7 Days — Bookings", icon: "waveform.path.ecg", iconColor: greenColor) {
            let maxCount = max(1, last7Days.map { $0.1 }.max() ?? 1)
            HStack(alignment: .bottom, spacing: 8) {
                ForEach(last7Days, id: \.0) { day, count in
                    VStack(spacing: 4) {
                        if count > 0 {
                            Text("\(count)")
                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                .foregroundColor(primaryColor)
                        }
                        GeometryReader { geo in
                            VStack {
                                Spacer()
                                RoundedRectangle(cornerRadius: 5)
                                    .fill(
                                        count > 0
                                        ? LinearGradient(colors: [primaryColor, primaryDark], startPoint: .top, endPoint: .bottom)
                                        : LinearGradient(colors: [Color(.systemGray5), Color(.systemGray5)], startPoint: .top, endPoint: .bottom)
                                    )
                                    .frame(height: barsReady
                                           ? max(6, geo.size.height * CGFloat(count) / CGFloat(maxCount))
                                           : 6
                                    )
                                    .animation(.spring(response: 0.6, dampingFraction: 0.75).delay(Double(last7Days.firstIndex(where: { $0.0 == day }) ?? 0) * 0.07), value: barsReady)
                            }
                        }
                        Text(day)
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                }
            }
            .frame(height: 90)
        }
    }

    // MARK: - Export Button

    private var exportButton: some View {
        Button(action: exportSummary) {
            Label("Export Analytics Summary", systemImage: "square.and.arrow.up")
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    LinearGradient(colors: [primaryColor, primaryDark], startPoint: .leading, endPoint: .trailing)
                )
                .foregroundColor(.white)
                .cornerRadius(14)
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showShareSheet) {
            SharedActivityView(activityItems: [shareText])
        }
    }

    // MARK: - Helpers

    private func analyticsCard<Content: View>(title: String, icon: String, iconColor: Color, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(iconColor)
                Text(title)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
            }
            content()
        }
        .padding(16)
        .background(Color(.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }

    private func triggerAnimations() {
        barsReady = false
        animatedRevenue = 0
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.75)) {
                animatedRevenue = totalRevenue
                barsReady = true
            }
        }
    }

    private func exportSummary() {
        let df = DateFormatter(); df.dateStyle = .medium
        var lines: [String] = [
            "=== \(motelData.businessName) — Analytics Report ===",
            "Period: \(selectedRange.rawValue)",
            "Generated: \(df.string(from: Date()))",
            "",
            "-- Revenue --",
            "Total Revenue:        \(String(format: "$%.2f", totalRevenue))",
            "Tax Collected:        \(String(format: "$%.2f", taxCollected))",
            "Pending Amount:       \(String(format: "$%.2f", pendingAmount))",
            "Avg / Booking:        \(String(format: "$%.2f", avgRevenuePerBooking))",
            "",
            "-- Occupancy --",
            "Occupancy Rate:       \((avgOccupancyRate > 0 && avgOccupancyRate < 1 ? "<1%" : String(format: "%.0f%%", avgOccupancyRate)))",
            "Total Nights Sold:    \(totalNightsSold)",
            "Avg Stay Length:      \(String(format: "%.1f nights", avgLengthOfStay))",
            "",
            "-- Revenue by Payment Method --"
        ]
        for (method, amount) in revenueByMethod {
            let pct = totalRevenue > 0 ? (amount / totalRevenue) * 100 : 0
            lines.append(String(format: "%-16s $%.2f  (%.1f%%)", (method.rawValue as NSString).utf8String!, amount, pct))
        }
        lines.append("")
        lines.append("-- Top Rooms --")
        for (index, pair) in topRooms.prefix(5).enumerated() {
            lines.append("#\(index + 1) Room \(pair.0.number): \(String(format: "$%.2f", pair.1))")
        }
        shareText = lines.joined(separator: "\n")
        showShareSheet = true
    }

    // MARK: Design Tokens

    private var primaryColor: Color { Color(red: 0.18, green: 0.27, blue: 0.90) }
    private var primaryDark: Color  { Color(red: 0.05, green: 0.12, blue: 0.65) }
    private var goldColor: Color    { Color(red: 0.96, green: 0.65, blue: 0.14) }
    private var greenColor: Color   { Color(red: 0.20, green: 0.78, blue: 0.35) }
}

// MARK: - AnimatedBarRow

struct AnimatedBarRow: View {
    let label: String
    let amount: Double
    let total: Double
    let color: Color
    let isReady: Bool

    private var percentage: Double { total > 0 ? (amount / total) * 100 : 0 }

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text(label)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                Spacer()
                Text(String(format: "$%.2f", amount))
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                Text(String(format: "(%.0f%%)", percentage))
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 5)
                        .fill(Color(.systemGray5))
                        .frame(height: 10)
                    RoundedRectangle(cornerRadius: 5)
                        .fill(
                            LinearGradient(
                                colors: [color, color.opacity(0.75)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(
                            width: isReady ? geo.size.width * CGFloat(percentage / 100) : 0,
                            height: 10
                        )
                        .animation(.spring(response: 0.7, dampingFraction: 0.78), value: isReady)
                }
            }
            .frame(height: 10)
        }
    }
}

// MARK: - TaxSetupView

struct TaxSetupView: View {
    let currentRate: Double
    let onSave: (Double) -> Void

    @Environment(\.presentationMode) var presentationMode
    @State private var newRate   = ""
    @State private var showAlert = false
    @State private var alertMsg  = ""

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Current Tax Rate")) {
                    Text(String(format: "%.1f%%", currentRate * 100))
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                }
                Section(header: Text("Set New Rate (%)")) {
                    TextField("e.g. 8.5", text: $newRate)
                        .keyboardType(.decimalPad)
                    Text("Enter a value between 0 and 100.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Section {
                    Button("Save") {
                        if let rate = Double(newRate), rate >= 0, rate <= 100 {
                            onSave(rate / 100)
                            presentationMode.wrappedValue.dismiss()
                        } else {
                            alertMsg = "Please enter a valid number between 0 and 100."
                            showAlert = true
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                }
            }
            .navigationTitle("Tax Rate")
            .navigationBarItems(trailing: Button("Cancel") { presentationMode.wrappedValue.dismiss() })
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Invalid Input"), message: Text(alertMsg), dismissButton: .default(Text("OK")))
            }
        }
    }
}

// MARK: - StatisticView (backward-compatible)

struct StatisticView: View {
    let title: String
    let value: String

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 26, weight: .black, design: .rounded))
            Text(title)
                .font(.system(size: 12, design: .rounded))
                .foregroundColor(.secondary)
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .background(Color(.systemBackground))
        .cornerRadius(14)
        .shadow(color: .black.opacity(0.06), radius: 6, x: 0, y: 3)
    }
}

// MARK: - TaxStatView (backward-compatible)

struct TaxStatView: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.system(size: 11, design: .rounded))
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 15, weight: .bold, design: .rounded))
        }
        .frame(minWidth: 120, alignment: .leading)
    }
}

// MARK: - PaymentMethodRow (backward-compatible)

struct PaymentMethodRow: View {
    let method: PaymentMethod
    let amount: Double
    let total: Double

    private var percentage: Double { total > 0 ? (amount / total) * 100 : 0 }

    private func colorFor(_ m: PaymentMethod) -> Color {
        switch m {
        case .cash:         return Color(red: 0.20, green: 0.78, blue: 0.35)
        case .card:         return Color(red: 0.18, green: 0.27, blue: 0.90)
        case .check:        return .orange
        case .organization: return .purple
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(method.rawValue).fontWeight(.medium)
                Spacer()
                Text(String(format: "$%.2f", amount)).fontWeight(.semibold)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Rectangle().fill(Color.gray.opacity(0.3)).frame(height: 8).cornerRadius(4)
                    Rectangle()
                        .fill(colorFor(method))
                        .frame(width: geo.size.width * CGFloat(percentage / 100), height: 8)
                        .cornerRadius(4)
                }
            }
            .frame(height: 8)
            Text(String(format: "%.1f%%", percentage))
                .font(.caption).foregroundColor(.secondary)
        }
        .padding(.vertical, 5)
    }
}

// MARK: - MonthlyTrendsView (backward-compatible)

struct MonthlyTrendsView: View {
    let motelData: MotelData

    var monthlyData: [(month: String, amount: Double)] {
        let cal = Calendar.current
        let now = Date()
        guard let sixMonthsAgo = cal.date(byAdding: .month, value: -5, to: now) else { return [] }
        var months: [Date] = []
        var d = sixMonthsAgo
        while d <= now {
            months.append(d)
            guard let next = cal.date(byAdding: .month, value: 1, to: d) else { break }
            d = next
        }
        let fmt = DateFormatter(); fmt.dateFormat = "MMM"
        return months.map { date in
            let amt = (motelData.bookings + motelData.history)
                .filter { cal.isDate($0.checkInDate, equalTo: date, toGranularity: .month) }
                .reduce(0.0) { $0 + $1.prizeAmount }
            return (fmt.string(from: date), amt)
        }
    }

    var body: some View {
        VStack(alignment: .leading) {
            Text("Monthly Trends")
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .padding(.bottom, 8)
            GeometryReader { geo in
                HStack(alignment: .bottom, spacing: 10) {
                    ForEach(monthlyData, id: \.month) { data in
                        VStack {
                            Text("$\(Int(data.amount))")
                                .font(.caption2)
                                .rotationEffect(.degrees(-45))
                                .offset(y: -16)
                            Rectangle()
                                .fill(Color(red: 0.18, green: 0.27, blue: 0.90))
                                .frame(width: 28, height: barHeight(data.amount, geo: geo))
                                .cornerRadius(4)
                            Text(data.month)
                                .font(.caption2)
                                .rotationEffect(.degrees(-45))
                        }
                    }
                }
            }
        }
    }

    private func barHeight(_ amount: Double, geo: GeometryProxy) -> CGFloat {
        let maxAmt = monthlyData.map { $0.amount }.max() ?? 1
        guard maxAmt > 0 else { return 0 }
        return CGFloat(amount / maxAmt) * (geo.size.height - 40)
    }
}

// MARK: - Preview

struct AnalyticsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AnalyticsView()
                .environmentObject(MotelData())
        }
    }
}
