//
//  SharedActivityView.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 6/24/25.
//

import SwiftUI
import UIKit

// MARK: - Shared ActivityView Implementation
struct SharedActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    let applicationActivities: [UIActivity]?
    @Environment(\.presentationMode) var presentationMode
    
    init(activityItems: [Any], applicationActivities: [UIActivity]? = nil) {
        self.activityItems = activityItems
        self.applicationActivities = applicationActivities
    }

    func makeUIViewController(context: UIViewControllerRepresentableContext<SharedActivityView>) -> UIActivityViewController {
        let controller = UIActivityViewController(
            activityItems: activityItems,
            applicationActivities: applicationActivities
        )
        
        // Configure for iPad
        if let popover = controller.popoverPresentationController {
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let window = windowScene.windows.first {
                popover.sourceView = window.rootViewController?.view
                popover.sourceRect = CGRect(
                    x: window.bounds.midX,
                    y: window.bounds.midY,
                    width: 0,
                    height: 0
                )
                popover.permittedArrowDirections = []
            }
        }
        
        controller.completionWithItemsHandler = { _, completed, _, error in
            DispatchQueue.main.async {
                self.presentationMode.wrappedValue.dismiss()
            }
        }
        
        return controller
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: UIViewControllerRepresentableContext<SharedActivityView>) {}
}

// MARK: - Convenience Extensions
extension View {
    func shareSheet(
        isPresented: Binding<Bool>,
        items: @escaping () -> [Any]
    ) -> some View {
        self.sheet(isPresented: isPresented) {
            let shareItems = items()
            if !shareItems.isEmpty {
                SharedActivityView(activityItems: shareItems)
            } else {
                Text("No content to share")
                    .padding()
            }
        }
    }
}
