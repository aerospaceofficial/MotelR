//
//  Room+CoreDataProperties.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/13/24.
//
//

import Foundation
import CoreData

extension CDRoom: Identifiable {
    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDRoom> {
        return NSFetchRequest<CDRoom>(entityName: "Room")
    }

    @NSManaged public var id: UUID
    @NSManaged public var number: Int16
    @NSManaged public var name: String
    @NSManaged public var members: String
    @NSManaged public var bookings: NSSet?
    
    public var bookingsArray: [CDBooking] {
        let set = bookings as? Set<CDBooking> ?? []
        return set.sorted { $0.checkInDate < $1.checkInDate }
    }
}

extension CDRoom {
    convenience init(context: NSManagedObjectContext, number: Int, name: String, members: String) {
        self.init(context: context)
        self.id = UUID()
        // Clamp rather than convert: an out-of-range value would trap at runtime.
        self.number = CDRoom.clampedNumber(number)
        self.name = name
        self.members = members
    }

    /// Safely narrows a room number to the Int16 range Core Data stores it in.
    static func clampedNumber(_ number: Int) -> Int16 {
        Int16(min(max(number, Int(Int16.min)), Int(Int16.max)))
    }
}

// MARK: Generated accessors for bookings
extension CDRoom {
    @objc(addBookingsObject:)
    @NSManaged public func addToBookings(_ value: CDBooking)

    @objc(removeBookingsObject:)
    @NSManaged public func removeFromBookings(_ value: CDBooking)

    @objc(addBookings:)
    @NSManaged public func addToBookings(_ values: NSSet)

    @objc(removeBookings:)
    @NSManaged public func removeFromBookings(_ values: NSSet)
}
