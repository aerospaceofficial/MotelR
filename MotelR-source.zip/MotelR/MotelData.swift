//
//  ContentView.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 7/13/24.
//

import SwiftUI
import CoreData
import UserNotifications

class MotelData: ObservableObject {
    private let context = CoreDataManager.shared.context

    @Published var rooms: [CDRoom] = []
    @Published var bookings: [CDBooking] = []
    @Published var history: [CDBooking] = []
    @Published var incidents: [CDIncidentReport] = []
    /// Set when a Core Data fetch fails so the UI can surface an alert.
    @Published var fetchErrorMessage: String? = nil
    /// True while CloudKit is pushing a remote sync update.
    @Published var isSyncingFromCloud: Bool = false
    @Published var taxRate: Double = 0.0 {
        didSet {
            SettingsSync.shared.set(taxRate, forKey: "taxRate")
        }
    }
    @Published var businessName: String = "Motel R" {
        didSet {
            SettingsSync.shared.set(businessName, forKey: "businessName")
        }
    }

    private var remoteChangeObserver: NSObjectProtocol?
    private var settingsObserver: NSObjectProtocol?

    init() {
        fetchAllData()
        fetchIncidents()
        print("Initial incidents count: \(incidents.count)")
        businessName = UserDefaults.standard.string(forKey: "businessName") ?? "Motel R"
        taxRate = UserDefaults.standard.double(forKey: "taxRate")
        print("Loaded \(history.count) historical bookings")
        migrateLegacyLicensePhotos()

        // Another device changed the business name or tax rate.
        settingsObserver = NotificationCenter.default.addObserver(
            forName: SettingsSync.didChangeExternally,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            guard let self else { return }
            let name = UserDefaults.standard.string(forKey: "businessName") ?? "Motel R"
            let rate = UserDefaults.standard.double(forKey: "taxRate")
            if name != self.businessName { self.businessName = name }
            if rate != self.taxRate { self.taxRate = rate }
        }

        // Listen for CloudKit remote changes — when another device saves data,
        // NSPersistentCloudKitContainer posts this notification so we can refresh.
        remoteChangeObserver = NotificationCenter.default.addObserver(
            forName: .NSPersistentStoreRemoteChange,
            object: CoreDataManager.shared.persistentContainer.persistentStoreCoordinator,
            queue: .main
        ) { [weak self] _ in
            guard let self else { return }
            self.isSyncingFromCloud = true
            self.fetchAllData()
            // Brief indicator then hide
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.isSyncingFromCloud = false
            }
        }
    }

    deinit {
        if let observer = remoteChangeObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        if let observer = settingsObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }
    
    /// Active bookings whose guest has arrived (check-in day is today or earlier).
    var inHouseBookings: [CDBooking] {
        bookings.filter { !$0.isReservation }
    }

    /// Active bookings for a future day — reserved, not yet occupying the room.
    var reservedBookings: [CDBooking] {
        bookings.filter { $0.isReservation }
    }

    /// Number of rooms with a guest in them right now.
    var occupiedRoomCount: Int {
        Set(inHouseBookings.map { $0.room.id }).count
    }

    /// The booking for the guest currently staying in `room`, if any.
    func currentBooking(for room: CDRoom) -> CDBooking? {
        inHouseBookings.first { $0.room.id == room.id }
    }

    /// The guest staying in the room with this number right now, if any.
    func currentBooking(forRoomNumber number: Int) -> CDBooking? {
        inHouseBookings.first { Int($0.room.number) == number }
    }

    /// The next upcoming reservation for `room`, if any.
    func nextReservation(for room: CDRoom) -> CDBooking? {
        reservedBookings
            .filter { $0.room.id == room.id }
            .min { $0.checkInDate < $1.checkInDate }
    }

    // Add computed properties for analytics
    var paidBookings: [CDBooking] {
            return (bookings + history).filter { $0.paymentStatusEnum == .paid }
        }
        
    var pendingBookings: [CDBooking] {
            return (bookings + history).filter {
                $0.paymentMethodEnum == .organization &&
                $0.paymentStatusEnum == .pending
            }
        }
    
    // Modify revenue calculations to only include paid bookings
    func calculateRevenue(forBookings bookings: [CDBooking], onlyTaxed: Bool = false) -> Double {
           let filteredBookings = bookings.filter { booking in
               booking.paymentStatusEnum == .paid &&
               (onlyTaxed ? booking.isTaxed : true)
           }
           
           return filteredBookings.reduce(0.0) { sum, booking in
               sum + (Double(booking.prize.trimmingCharacters(in: CharacterSet(charactersIn: "$"))) ?? 0.0)
           }
       }
       
    // Add method to mark booking as paid
    func markBookingAsPaid(_ booking: CDBooking) {
           booking.paymentStatus = PaymentStatus.paid.rawValue
           CoreDataManager.shared.save()
           fetchAllData() // Refresh data
       }
    
    /// Earlier builds kept licence photos in files on this device only, so they never
    /// reached the owner's other devices. Move each one into its booking (which syncs
    /// through iCloud) and remove the file. Bookings whose file is not on this device
    /// are left alone — the device that has the file will move it.
    private func migrateLegacyLicensePhotos() {
        var movedFiles: [String] = []
        for booking in bookings + history {
            guard (booking.licenseImageData ?? Data()).isEmpty,
                  let filename = booking.licenseImageFileName,
                  let data = LicenseImageManager.data(named: filename) else { continue }
            booking.licenseImageData = LicenseImageManager.prepareForStorage(data)
            booking.licenseImageFileName = nil
            movedFiles.append(filename)
        }
        guard !movedFiles.isEmpty else { return }
        do {
            try context.save()
            // Only remove the old files once the photos are safely in the database.
            movedFiles.forEach { LicenseImageManager.delete(named: $0) }
            print("Moved \(movedFiles.count) licence photos into their bookings for iCloud sync")
        } catch {
            context.rollback()
            print("Could not move licence photos: \(error)")
        }
    }

    // MARK: - Data Fetching
    func fetchAllData() {
        fetchRooms()
        fetchBookings()
        fetchHistory()
        fetchIncidents()
    }
    
    private func fetchRooms() {
        let request: NSFetchRequest<CDRoom> = CDRoom.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "number", ascending: true)
        request.sortDescriptors = [sortDescriptor]

        do {
            rooms = try context.fetch(request)
        } catch {
            print("Error fetching rooms: \(error)")
            fetchErrorMessage = "Failed to load rooms. Please restart the app."
        }
    }

    private func fetchBookings() {
        let request: NSFetchRequest<CDBooking> = CDBooking.fetchRequest()
        request.predicate = NSPredicate(format: "isHistory == NO")

        do {
            bookings = try context.fetch(request)
        } catch {
            print("Error fetching bookings: \(error)")
            fetchErrorMessage = "Failed to load bookings. Please restart the app."
        }
    }

    private func fetchHistory() {
        let request: NSFetchRequest<CDBooking> = CDBooking.fetchRequest()
        request.predicate = NSPredicate(format: "isHistory == true")

        do {
            history = try context.fetch(request)
            print("Fetched \(history.count) historical bookings")
        } catch {
            print("Error fetching history: \(error)")
            history = []
            fetchErrorMessage = "Failed to load booking history. Please restart the app."
        }
    }
    
    func addIncident(_ incident: CDIncidentReport) {
        // Save to Core Data first
        CoreDataManager.shared.save()
        
        // Then update the local array
        incidents.append(incident)
        
        // Fetch fresh data
        fetchIncidents()
        print("Added incident. Total count: \(incidents.count)")
    }
    
    func updateIncident(_ incident: CDIncidentReport) {
        if let index = incidents.firstIndex(where: { $0.id == incident.id }) {
            incidents[index] = incident
            CoreDataManager.shared.save()
        }
        fetchIncidents()
    }
    
    func fetchIncidents() {
        let request: NSFetchRequest<CDIncidentReport> = CDIncidentReport.fetchRequest()
        
        do {
            incidents = try context.fetch(request)
            print("Fetched \(incidents.count) incidents")
        } catch {
            print("Error fetching incidents: \(error)")
            incidents = []
        }
    }
    
    
    
    
    /// Licence numbers compared without case, spaces or dashes, so "d123-456" and
    /// "D123456" are recognised as the same guest.
    static func normalizedLicense(_ value: String) -> String {
        value.uppercased().filter { $0.isLetter || $0.isNumber }
    }

    @MainActor
    func getIncidentsForCustomer(withID customerID: String) -> [CDIncidentReport] {
        let wanted = MotelData.normalizedLicense(customerID)
        guard !wanted.isEmpty else { return [] }
        return incidents
            .filter { MotelData.normalizedLicense($0.customerID) == wanted }
            .sorted { $0.incidentDate > $1.incidentDate }
    }

    /// The warning to show the clerk before handing over a key, or nil when the guest
    /// has no incidents on record. Used by both Check In and New Booking.
    @MainActor
    func incidentWarningMessage(forLicense license: String) -> String? {
        let past = getIncidentsForCustomer(withID: license)
        guard !past.isEmpty else { return nil }
        let high   = past.filter { $0.severityLevel == .high }.count
        let medium = past.filter { $0.severityLevel == .medium }.count
        var msg = "This guest has \(past.count) previous incident\(past.count == 1 ? "" : "s") on record:"
        if high   > 0 { msg += "\n• \(high) high priority" }
        if medium > 0 { msg += "\n• \(medium) medium priority" }
        if let latest = past.first {
            let df = DateFormatter(); df.dateStyle = .medium
            msg += "\n\nMost recent (\(df.string(from: latest.incidentDate))):\n\(latest.incidentDescription)"
        }
        return msg
    }
    
    func deleteIncident(_ incident: CDIncidentReport) throws {
        // Perform deletion on a background context to avoid blocking the UI
        let backgroundContext = CoreDataManager.shared.persistentContainer.newBackgroundContext()
        
        try backgroundContext.performAndWait {
            // Fetch the incident in the background context
            let fetchRequest: NSFetchRequest<CDIncidentReport> = CDIncidentReport.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", incident.id as CVarArg)
            
            guard let incidentToDelete = try backgroundContext.fetch(fetchRequest).first else {
                throw NSError(domain: "IncidentNotFound", code: 404, userInfo: [NSLocalizedDescriptionKey: "Incident not found"])
            }
            
            // Delete the incident
            backgroundContext.delete(incidentToDelete)
            
            // Save the background context
            try backgroundContext.save()
            
            // Update the main context on the main thread
            DispatchQueue.main.async {
                // Remove from local array
                if let index = self.incidents.firstIndex(where: { $0.id == incident.id }) {
                    self.incidents.remove(at: index)
                }
                
                // Refresh incidents to ensure consistency
                self.fetchIncidents()
                
                print("Successfully deleted incident. Remaining count: \(self.incidents.count)")
            }
        }
    }
    
    
    
    // MARK: - Room Operations
    func addRoom(_ number: Int, name: String, members: String) {
        // Create new room using Core Data
        let newRoom = CDRoom(context: CoreDataManager.shared.context,
                            number: number,
                            name: name,
                            members: members)
        
        // Insert the room in the correct position to maintain sorting
        let insertIndex = rooms.firstIndex { $0.number > CDRoom.clampedNumber(number) } ?? rooms.count
        rooms.insert(newRoom, at: insertIndex)
        
        CoreDataManager.shared.save()
        // Fetch again to ensure consistency
        fetchRooms()
    }
    
    /// Number of active (not yet checked out) bookings still attached to a room.
    func activeBookingCount(for room: CDRoom) -> Int {
        bookings.filter { $0.room.id == room.id }.count
    }

    /// Number of checked-out bookings kept in history for a room.
    func historyBookingCount(for room: CDRoom) -> Int {
        history.filter { $0.room.id == room.id }.count
    }

    /// Deleting a room nullifies the `room` relationship on its bookings, which would
    /// leave them pointing at nothing and crash every screen that reads `booking.room`.
    /// So we refuse while a room is still occupied, and otherwise remove its history
    /// records together with the room.
    @discardableResult
    func deleteRoom(at offsets: IndexSet) -> Bool {
        let targets = offsets.compactMap { $0 < rooms.count ? rooms[$0] : nil }
        guard targets.allSatisfy({ activeBookingCount(for: $0) == 0 }) else { return false }

        let context = CoreDataManager.shared.context
        for room in targets {
            // Remove the room's bookings first, via the inverse relationship, so no
            // booking is left pointing at a room that no longer exists.
            for booking in (room.bookings as? Set<CDBooking>) ?? [] {
                if let filename = booking.licenseImageFileName {
                    LicenseImageManager.delete(named: filename)
                }
                context.delete(booking)
            }
            context.delete(room)
        }

        CoreDataManager.shared.save()
        fetchAllData()
        return true
    }
    
    // MARK: - Booking Operations
    // Update how bookings are created to handle payment status
    /// Saves a booking the caller has already inserted into the context.
    ///
    /// The payment status the caller chose is kept as-is (the "Bill Later" toggle
    /// decides whether an organization booking starts out Pending or Paid).
    ///
    /// If the room is taken for those dates the booking is removed from the context
    /// again. Leaving it there meant the rejected booking was quietly saved the next
    /// time anything else in the app saved — a "ghost" guest in the room.
    func addBooking(_ booking: CDBooking) -> Bool {
        guard isRoomAvailable(for: booking) else {
            discardUnsavedBooking(booking)
            return false
        }
        bookings.append(booking)
        CoreDataManager.shared.save()
        fetchBookings()
        return true
    }

    /// Throws away a booking that was inserted but never saved, along with any
    /// licence photo written to disk for it.
    func discardUnsavedBooking(_ booking: CDBooking) {
        if let filename = booking.licenseImageFileName {
            LicenseImageManager.delete(named: filename)
        }
        CoreDataManager.shared.context.delete(booking)
    }
    
    func checkOut(_ booking: CDBooking) {
        if let index = bookings.firstIndex(where: { $0.id == booking.id }) {
            // Cancel any pending checkout reminder for this booking
            UNUserNotificationCenter.current().removePendingNotificationRequests(
                withIdentifiers: ["checkout-\(booking.id.uuidString)"]
            )

            // Update the booking's history status in Core Data
            booking.isHistory = true

            // Early departure: record when the guest actually left so history,
            // reports and room availability reflect reality. Amounts are kept.
            let now = Date()
            if now < booking.checkOutDate {
                booking.checkOutDate = max(now, booking.checkInDate)
            }

            // The room needs cleaning before the next guest.
            RoomHousekeeping.set(.cleaning, for: booking.room)

            // Save the changes to Core Data immediately
            CoreDataManager.shared.save()
            
            // Update the arrays
            history.append(booking)
            bookings.remove(at: index)
            
            // Fetch fresh data to ensure everything is in sync
            fetchBookings()
            fetchHistory()
        }
    }
    
    func checkOutRoom(_ room: CDRoom) {
        if let booking = currentBooking(for: room) {
            checkOut(booking)
        }
    }

    
    func reactivateBooking(_ booking: CDBooking) -> Bool {
            if isRoomAvailable(for: booking) {
                booking.isHistory = false
                CoreDataManager.shared.save()
                fetchBookings()
                fetchHistory()
                scheduleCheckoutReminderNotification(booking: booking)
                return true
            }
            return false
        }
    
    // MARK: - Helper Functions
    func isRoomAvailable(for booking: CDBooking) -> Bool {
        // Use strict < so that checkout day == next checkin day is allowed (standard hotel behaviour).
        !bookings.contains { existingBooking in
            existingBooking.room.number == booking.room.number &&
            existingBooking.id != booking.id &&
            existingBooking.checkInDate < booking.checkOutDate &&
            booking.checkInDate < existingBooking.checkOutDate
        }
    }
    
    // MARK: - Data Management
    func deleteAllData() {
        // Remove the guests' licence photos too — deleting the bookings that point at
        // them would otherwise leave the images orphaned on disk forever.
        for booking in bookings + history {
            if let filename = booking.licenseImageFileName {
                LicenseImageManager.delete(named: filename)
            }
        }

        do {
            try CoreDataManager.shared.deleteAllObjects(in: context)
        } catch {
            print("Error deleting data: \(error)")
            NotificationCenter.default.post(name: .coreDataSaveFailed, object: nil)
        }

        fetchAllData()

        // Reset settings
        taxRate = 0.0
        businessName = "Motel R"
    }
}





// MARK: - Settings sync (iCloud key-value storage)

/// Mirrors the motel's settings between the owner's devices through iCloud
/// key-value storage, so a second iPhone or iPad shows the same business name,
/// tax rate, check-out time, terms and housekeeping status.
///
/// UserDefaults stays the local source the rest of the app reads; this class copies
/// every change up to iCloud and copies changes from other devices back down.
final class SettingsSync {
    static let shared = SettingsSync()
    /// Posted on the main queue after another device changed a setting.
    static let didChangeExternally = Notification.Name("settingsSyncDidChangeExternally")

    static let syncedKeys: Set<String> = [
        "businessName",
        "taxRate",
        "checkOutTime",
        "motel_terms_and_conditions",
        "motel_terms_version"
    ]
    static let roomStatusPrefix = "room_status_"

    private let store = NSUbiquitousKeyValueStore.default
    private let defaults = UserDefaults.standard
    private var started = false

    private init() {}

    /// Call once at launch.
    func start() {
        guard !started else { return }
        started = true
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(storeDidChange(_:)),
            name: NSUbiquitousKeyValueStore.didChangeExternallyNotification,
            object: store
        )
        store.synchronize()

        // Take whatever the owner's other devices have already saved…
        for (key, value) in store.dictionaryRepresentation where isSynced(key) {
            defaults.set(value, forKey: key)
        }
        // …and share anything this device has that iCloud does not have yet.
        for (key, value) in defaults.dictionaryRepresentation()
        where isSynced(key) && store.object(forKey: key) == nil {
            store.set(value, forKey: key)
        }
    }

    /// Saves a setting locally and shares it with the owner's other devices.
    func set(_ value: Any?, forKey key: String) {
        defaults.set(value, forKey: key)
        if let value {
            store.set(value, forKey: key)
        } else {
            store.removeObject(forKey: key)
        }
    }

    private func isSynced(_ key: String) -> Bool {
        Self.syncedKeys.contains(key) || key.hasPrefix(Self.roomStatusPrefix)
    }

    @objc private func storeDidChange(_ note: Notification) {
        let keys = (note.userInfo?[NSUbiquitousKeyValueStoreChangedKeysKey] as? [String]) ?? []
        for key in keys where isSynced(key) {
            defaults.set(store.object(forKey: key), forKey: key)
        }
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: SettingsSync.didChangeExternally, object: nil)
        }
    }
}

// MARK: - Housekeeping status

/// Per-room housekeeping status (Available / Cleaning). Occupied is never stored:
/// it is worked out from the bookings. Synced between devices by `SettingsSync`.
enum RoomHousekeeping {
    static func key(for room: CDRoom) -> String {
        SettingsSync.roomStatusPrefix + room.id.uuidString
    }

    static func status(for room: CDRoom) -> HousekeepingStatus {
        let raw = UserDefaults.standard.string(forKey: key(for: room)) ?? HousekeepingStatus.available.rawValue
        return HousekeepingStatus(rawValue: raw) ?? .available
    }

    static func set(_ status: HousekeepingStatus, for room: CDRoom) {
        SettingsSync.shared.set(status.rawValue, forKey: key(for: room))
    }

    /// Every stored status, keyed by room id — included in backups.
    static func allStatuses() -> [String: String] {
        var result: [String: String] = [:]
        for (key, value) in UserDefaults.standard.dictionaryRepresentation()
        where key.hasPrefix(SettingsSync.roomStatusPrefix) {
            if let raw = value as? String { result[key] = raw }
        }
        return result
    }
}
