//  SearchBar.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import Foundation

// MARK: - SearchBar

/// A polished, reusable pure-SwiftUI search bar.
///
/// Usage:
///   SearchBar(text: $query)
///   SearchBar(text: $query, placeholder: "Search bookings…")
struct SearchBar: View {
    @Binding var text: String
    var placeholder: String = "Search…"

    @FocusState private var isFocused: Bool
    @State private var isActive = false

    var body: some View {
        HStack(spacing: 8) {
            // Search field + icon
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(isActive
                                     ? Color(red: 0.18, green: 0.27, blue: 0.90)
                                     : Color(.placeholderText))
                    .animation(.easeInOut(duration: 0.2), value: isActive)

                TextField(placeholder, text: $text)
                    .font(.system(size: 16, design: .rounded))
                    .foregroundColor(.primary)
                    .focused($isFocused)
                    .submitLabel(.search)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                    .onChange(of: isFocused) { _, focused in
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) {
                            isActive = focused
                        }
                    }

                // Clear button — only visible when there is text
                if !text.isEmpty {
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.15)) {
                            text = ""
                        }
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16))
                            .foregroundColor(Color(.placeholderText))
                    }
                    .transition(.scale.combined(with: .opacity))
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.systemFill))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(
                                isActive
                                    ? Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.55)
                                    : Color.clear,
                                lineWidth: 1.5
                            )
                    )
            )
            .animation(.spring(response: 0.3, dampingFraction: 0.75), value: isActive)

            // Cancel button — slides in when active
            if isActive {
                Button("Cancel") {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) {
                        text = ""
                        isFocused = false
                        isActive = false
                    }
                }
                .font(.system(size: 15, weight: .medium, design: .rounded))
                .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
        .animation(.spring(response: 0.3, dampingFraction: 0.75), value: isActive)
    }
}

// MARK: - DateFormatter Extension (preserved from original file)

extension DateFormatter {
    static var shortDate: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter
    }
}

// MARK: - Preview

struct SearchBar_Previews: PreviewProvider {
    struct PreviewWrapper: View {
        @State var query = ""
        var body: some View {
            VStack(spacing: 20) {
                SearchBar(text: $query)
                SearchBar(text: $query, placeholder: "Search bookings, rooms, guests…")
                if !query.isEmpty {
                    Text("Query: \"\(query)\"")
                        .font(.system(size: 14, design: .rounded))
                        .foregroundColor(.secondary)
                }
            }
            .padding()
            .background(Color(.systemGroupedBackground))
        }
    }

    static var previews: some View {
        PreviewWrapper()
    }
}
