//  RestoreView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import UniformTypeIdentifiers
import ZIPFoundation

// MARK: - Design Tokens
private let rstPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let rstGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let rstGold  = Color(red: 0.96, green: 0.65, blue: 0.14)
private let rstGreen = Color(red: 0.20, green: 0.78, blue: 0.35)

// MARK: - RestoreView
struct RestoreView: View {
    @AppStorage("hasCompletedSetup") private var hasCompletedSetup = false
    @State private var showDocumentPicker = false
    @State private var showPasswordPrompt = false
    @State private var pendingRestoreURL: URL?
    @State private var isRestoring = false
    @State private var showSuccessAlert = false
    @State private var showFailureAlert = false
    @State private var failureMessage = ""
    @State private var showPINSetup = false
    @State private var showReplaceWarning = false

    var body: some View {
        ZStack {
            rstGradient.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 32) {
                    Spacer(minLength: 40)
                    logoHeader
                    freshStartCard
                    restoreCard
                    Spacer(minLength: 40)
                }
                .padding(.horizontal, 24)
                .readableWidth(640)
            }
        }
        .sheet(isPresented: $showDocumentPicker) {
            BackupDocumentPicker { result in
                switch result {
                case .success(let url):
                    pendingRestoreURL = url
                    // Wait for the picker to dismiss, then warn before anything is replaced.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        showReplaceWarning = true
                    }
                case .failure(let error):
                    failureMessage = error.localizedDescription
                    showFailureAlert = true
                }
            }
        }
        .sheet(isPresented: $showPasswordPrompt) {
            BackupPasswordPrompt(mode: .restore, isPresented: $showPasswordPrompt) { password in
                guard let url = pendingRestoreURL else { return }
                handleRestore(from: url, password: password)
            }
        }
        .sheet(isPresented: $showPINSetup) {
            PINSetupView {
                hasCompletedSetup = true
            }
        }
        .alert("Replace All Data?", isPresented: $showReplaceWarning) {
            Button("Replace Everything", role: .destructive) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    showPasswordPrompt = true
                }
            }
            Button("Cancel", role: .cancel) { pendingRestoreURL = nil }
        } message: {
            Text(RestoreWarning.message)
        }
        .alert("Restore Complete", isPresented: $showSuccessAlert) {
            Button("Get Started") {
                hasCompletedSetup = true
            }
        } message: {
            Text("Your data has been restored successfully. Welcome back!")
        }
        .alert("Restore Failed", isPresented: $showFailureAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(failureMessage)
        }
        .overlay {
            if isRestoring {
                ZStack {
                    Color.black.opacity(0.45).ignoresSafeArea()
                    VStack(spacing: 18) {
                        ProgressView()
                            .progressViewStyle(.circular)
                            .scaleEffect(1.4)
                            .tint(.white)
                        Text("Restoring backup…")
                            .font(.system(.subheadline, design: .rounded).weight(.semibold))
                            .foregroundStyle(.white)
                    }
                    .padding(32)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                }
            }
        }
    }

    // MARK: Logo Header
    private var logoHeader: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(.white.opacity(0.15))
                    .frame(width: 90, height: 90)
                Image(systemName: "building.fill")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundStyle(.white)
            }
            Text("MotelR 2.0")
                .font(.system(.largeTitle, design: .rounded).weight(.bold))
                .foregroundStyle(.white)
            Text("by New Journey")
                .font(.system(.subheadline, design: .rounded))
                .foregroundStyle(.white.opacity(0.80))
        }
    }

    // MARK: Fresh Start Card
    private var freshStartCard: some View {
        VStack(spacing: 16) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(rstGreen.opacity(0.15))
                        .frame(width: 48, height: 48)
                    Image(systemName: "sparkles")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(rstGreen)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Fresh Start")
                        .font(.system(.headline, design: .rounded).weight(.semibold))
                    Text("Set up MotelR from scratch")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }

            Button {
                showPINSetup = true
            } label: {
                Text("Start Fresh")
                    .font(.system(.headline, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(rstGreen)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
        }
        .padding(20)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.12), radius: 16, y: 6)
    }

    // MARK: Restore Card
    private var restoreCard: some View {
        VStack(spacing: 16) {
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(rstGold.opacity(0.15))
                        .frame(width: 48, height: 48)
                    Image(systemName: "arrow.counterclockwise.icloud.fill")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(rstGold)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Restore from Backup")
                        .font(.system(.headline, design: .rounded).weight(.semibold))
                    Text("Import a .zip backup file")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }

            Button {
                showDocumentPicker = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "folder.badge.plus")
                        .font(.system(size: 15, weight: .semibold))
                    Text("Choose Backup File")
                        .font(.system(.headline, design: .rounded))
                }
                .foregroundStyle(rstPrimary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(rstPrimary.opacity(0.10))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .buttonStyle(.plain)
        }
        .padding(20)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.12), radius: 16, y: 6)
    }

    // MARK: Restore Logic

    private func handleRestore(from url: URL, password: String) {
        guard url.pathExtension.lowercased() == "zip" else {
            failureMessage = "Please select a valid .zip backup file."
            showFailureAlert = true
            return
        }

        isRestoring = true

        DispatchQueue.global(qos: .userInitiated).async {
            do {
                // Unpacks, verifies and re-encrypts under this device's key. Throws
                // before touching anything if the password or the file is wrong.
                try BackupUtils.shared.importBackup(from: url, password: password)

                // Core Data work must run on the view context's own queue.
                _ = try CoreDataManager.shared.performAndWait { _ in
                    try BackupManager.shared.restoreFromBackup()
                }

                DispatchQueue.main.async {
                    self.isRestoring = false
                    self.showSuccessAlert = true
                }
            } catch {
                DispatchQueue.main.async {
                    self.isRestoring = false
                    self.failureMessage = error.localizedDescription
                    self.showFailureAlert = true
                }
            }
        }
    }
}

// MARK: - Restore warning

/// Shown before a backup replaces the data. Because the data syncs through iCloud,
/// a restore on one device also replaces it on the owner's other devices.
enum RestoreWarning {
    static let message = "Restoring replaces every room, booking, history record and incident with the ones in this backup.\n\nMotelR syncs through iCloud, so this also replaces the data on every other iPhone or iPad signed in to the same iCloud account. Anything added since the backup was made will be lost."
}

// MARK: - PINSetupView
struct PINSetupView: View {
    let onComplete: () -> Void
    @Environment(\.dismiss) private var dismiss

    @State private var pin = ""
    @State private var confirmPin = ""
    @State private var showMismatch = false
    @State private var showTooShort = false
    @FocusState private var focus: PINField?

    private enum PINField: Hashable {
        case pin, confirm
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 28) {
                Spacer()

                VStack(spacing: 8) {
                    Image(systemName: "lock.shield.fill")
                        .font(.system(size: 52))
                        .foregroundStyle(rstGradient)
                    Text("Set a PIN")
                        .font(.system(.title2, design: .rounded).weight(.bold))
                    Text("Optional — protect your app with a 6-digit PIN.")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                }

                VStack(spacing: 16) {
                    pinDotsField(label: "New PIN", binding: $pin, field: .pin) {
                        focus = .confirm
                    }
                    pinDotsField(label: "Confirm PIN", binding: $confirmPin, field: .confirm) {
                        attemptSetPIN()
                    }
                }
                .padding(.horizontal, 32)

                if showMismatch {
                    Text("PINs do not match. Please try again.")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(Color(red: 1.0, green: 0.23, blue: 0.19))
                }
                if showTooShort {
                    Text("PIN must be exactly 6 digits.")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundStyle(Color(red: 1.0, green: 0.23, blue: 0.19))
                }

                VStack(spacing: 12) {
                    Button {
                        attemptSetPIN()
                    } label: {
                        Text("Set PIN")
                            .font(.system(.headline, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(rstGradient)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 32)

                    Button {
                        dismiss()
                        onComplete()
                    } label: {
                        Text("Skip for now")
                            .font(.system(.subheadline, design: .rounded))
                            .foregroundStyle(rstPrimary)
                    }
                    .buttonStyle(.plain)
                }

                Spacer()
            }
            .navigationTitle("PIN Setup")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Skip") {
                        dismiss()
                        onComplete()
                    }
                }
            }
        }
    }

    private func pinDotsField(label: String, binding: Binding<String>, field: PINField, onSubmit: @escaping () -> Void) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label)
                .font(.system(.caption, design: .rounded).weight(.semibold))
                .foregroundStyle(.secondary)
            ZStack(alignment: .center) {
                // Hidden text field
                TextField("", text: binding)
                    .keyboardType(.numberPad)
                    .focused($focus, equals: field)
                    .frame(width: 1, height: 1)
                    .opacity(0.01)
                    .onChange(of: binding.wrappedValue) { _, newVal in
                        let digits = newVal.filter { "0123456789".contains($0) }
                        if digits.count > 6 {
                            binding.wrappedValue = String(digits.prefix(6))
                        } else {
                            binding.wrappedValue = digits
                        }
                        showMismatch = false
                        showTooShort = false
                    }
                    .onSubmit(onSubmit)

                // Dots display
                HStack(spacing: 14) {
                    ForEach(0..<6) { i in
                        Circle()
                            .fill(i < binding.wrappedValue.count ? rstPrimary : Color(.tertiarySystemFill))
                            .frame(width: 16, height: 16)
                            .animation(.spring(response: 0.2), value: binding.wrappedValue.count)
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.vertical, 14)
            .background(Color(.secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 14))
            // Whole field is tappable, not just the narrow row of dots.
            .contentShape(RoundedRectangle(cornerRadius: 14))
            .onTapGesture { focus = field }
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .strokeBorder(focus == field ? rstPrimary : Color.clear, lineWidth: 1.5)
            )
        }
    }

    private func attemptSetPIN() {
        showMismatch = false
        showTooShort = false
        guard pin.count == 6 else {
            showTooShort = true
            return
        }
        guard pin == confirmPin else {
            showMismatch = true
            confirmPin = ""
            focus = .confirm
            return
        }
        try? SecurityManager.shared.setPin(pin)
        let haptic = UINotificationFeedbackGenerator()
        haptic.notificationOccurred(.success)
        dismiss()
        onComplete()
    }
}
