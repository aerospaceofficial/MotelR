//
//  AssistantVoice.swift
//  MotelR 2.0 — by New Journey
//
//  Voice for the booking assistant:
//    • AssistantVoiceInput — the manager talks; Apple's speech recogniser turns it
//      into text on the device (no internet needed where on-device recognition is
//      supported, which covers English and most major languages). It sends the
//      message by itself after a short pause.
//    • AssistantSpeaker — reads the assistant's replies aloud with the built-in
//      iOS voices, which also work offline.
//

#if canImport(FoundationModels)
import Foundation
import Speech
import AVFoundation
import SwiftUI

// MARK: - Sound meter (drives the voice-mode orb)

/// Kept separate from the voice classes so only the orb redraws when the sound
/// level changes, not the whole chat screen.
@MainActor
final class AssistantAudioMeter: ObservableObject {
    /// Microphone loudness, 0…1, smoothed.
    @Published var level: CGFloat = 0
    /// When the spoken reply last started a new word.
    @Published var lastWordAt = Date.distantPast
}

// MARK: - Voice input

@MainActor
final class AssistantVoiceInput: ObservableObject {
    @Published private(set) var isListening = false
    @Published private(set) var transcript = ""
    @Published var errorMessage: String?

    /// Called with the final text when the manager stops talking.
    var onFinished: ((String) -> Void)?
    /// Called when listening ended without hearing anything.
    var onEmpty: (() -> Void)?
    /// Live microphone level for the voice-mode orb.
    let meter = AssistantAudioMeter()

    /// How long a pause ends the message.
    private let silenceTimeout: TimeInterval = 1.6
    /// Hard stop, in case the room is noisy and the pause never comes.
    private let maxDuration: TimeInterval = 45

    private let recognizer = SFSpeechRecognizer(locale: Locale.current) ?? SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var silenceTimer: Timer?
    private var maxTimer: Timer?
    private var session = 0   // ignores late callbacks from a previous recording

    /// True when speech is turned into text on the device itself (works offline).
    var isOnDevice: Bool { recognizer?.supportsOnDeviceRecognition ?? false }

    func toggle(contextualStrings: [String] = []) {
        if isListening {
            stop(send: true)
        } else {
            start(contextualStrings: contextualStrings)
        }
    }

    func start(contextualStrings: [String] = []) {
        guard !isListening else { return }
        errorMessage = nil
        Task {
            guard await Self.requestPermissions() else {
                errorMessage = "MotelR needs microphone and speech recognition access. Turn them on in Settings → MotelR 2.0."
                return
            }
            do {
                try begin(contextualStrings: contextualStrings)
            } catch {
                cleanUp()
                errorMessage = "Couldn't start listening. Please try again."
            }
        }
    }

    /// Stops listening. With `send`, whatever was heard is passed to `onFinished`.
    func stop(send: Bool) {
        guard isListening else { return }
        let text = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        cleanUp()
        transcript = ""
        if send {
            if text.isEmpty { onEmpty?() } else { onFinished?(text) }
        }
    }

    // MARK: Private

    private func begin(contextualStrings: [String]) throws {
        guard let recognizer, recognizer.isAvailable else {
            errorMessage = "Speech recognition isn't available right now."
            return
        }

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
        try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        request.addsPunctuation = true
        // Keep guest details on the device whenever the language supports it.
        if recognizer.supportsOnDeviceRecognition {
            request.requiresOnDeviceRecognition = true
        }
        // Words the front desk says a lot, so they're recognised more reliably.
        request.contextualStrings = ["room", "nights", "cash", "card", "check", "organization",
                                     "Visa", "Mastercard", "Amex", "tax", "tonight", "tomorrow"] + contextualStrings
        self.request = request

        let input = audioEngine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        let meter = self.meter
        input.installTap(onBus: 0, bufferSize: 1024, format: format, block: Self.makeTapBlock(for: request) { value in
            Task { @MainActor in meter.level = meter.level * 0.45 + value * 0.55 }
        })
        audioEngine.prepare()
        try audioEngine.start()

        session += 1
        let thisSession = session
        task = recognizer.recognitionTask(with: request, resultHandler: Self.makeResultHandler { [weak self] text, isFinal, failed in
            guard let self, self.session == thisSession, self.isListening else { return }
            if let text {
                self.transcript = text
                self.restartSilenceTimer()
            }
            if isFinal || failed {
                self.stop(send: true)
            }
        })

        transcript = ""
        isListening = true
        maxTimer = Timer.scheduledTimer(withTimeInterval: maxDuration, repeats: false) { [weak self] _ in
            Task { @MainActor in self?.stop(send: true) }
        }
    }

    private func restartSilenceTimer() {
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: silenceTimeout, repeats: false) { [weak self] _ in
            Task { @MainActor in self?.stop(send: true) }
        }
    }

    private func cleanUp() {
        silenceTimer?.invalidate(); silenceTimer = nil
        maxTimer?.invalidate(); maxTimer = nil
        if audioEngine.isRunning { audioEngine.stop() }
        audioEngine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        request = nil
        task = nil
        isListening = false
        meter.level = 0
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    /// The microphone tap runs on an audio thread, so it is built outside the main actor.
    nonisolated private static func makeTapBlock(
        for request: SFSpeechAudioBufferRecognitionRequest,
        onLevel: @escaping (CGFloat) -> Void
    ) -> AVAudioNodeTapBlock {
        return { buffer, _ in
            request.append(buffer)
            guard let samples = buffer.floatChannelData?[0] else { return }
            let count = Int(buffer.frameLength)
            guard count > 0 else { return }
            var sum: Float = 0
            for i in 0..<count { sum += samples[i] * samples[i] }
            let rms = sqrt(sum / Float(count))
            let decibels = 20 * log10(max(rms, 0.000_01))
            // About -50 dB (quiet room) → 0, about -5 dB (loud voice) → 1.
            onLevel(CGFloat(min(max((decibels + 50) / 45, 0), 1)))
        }
    }

    /// Recognition results arrive on a background queue; hop to the main actor.
    nonisolated private static func makeResultHandler(
        _ handle: @escaping @MainActor (String?, Bool, Bool) -> Void
    ) -> (SFSpeechRecognitionResult?, Error?) -> Void {
        return { result, error in
            let text = result?.bestTranscription.formattedString
            let isFinal = result?.isFinal ?? false
            let failed = error != nil
            Task { @MainActor in
                handle(text, isFinal, failed)
            }
        }
    }

    private static func requestPermissions() async -> Bool {
        let speechAllowed: Bool = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status == .authorized)
            }
        }
        guard speechAllowed else { return false }
        return await AVAudioApplication.requestRecordPermission()
    }
}

// MARK: - Spoken replies

@MainActor
final class AssistantSpeaker: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published private(set) var isSpeaking = false
    /// Called when a reply has been read out completely (not when interrupted).
    var onFinished: (() -> Void)?
    /// Word-by-word pulses for the voice-mode orb.
    let meter = AssistantAudioMeter()

    private let synthesizer = AVSpeechSynthesizer()
    private var current: ObjectIdentifier?

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    func speak(_ text: String) {
        stop()
        let audioSession = AVAudioSession.sharedInstance()
        try? audioSession.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
        try? audioSession.setActive(true)

        let utterance = AVSpeechUtterance(string: Self.speakable(text))
        utterance.voice = Self.currentVoice
        // Natural pitch and speed: changing them makes the built-in voices warble.
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate
        utterance.pitchMultiplier = 1.0
        utterance.preUtteranceDelay = 0.08
        utterance.postUtteranceDelay = 0.05
        current = ObjectIdentifier(utterance)
        isSpeaking = true
        synthesizer.speak(utterance)
    }

    func stop() {
        current = nil
        isSpeaking = false
        if synthesizer.isSpeaking {
            synthesizer.stopSpeaking(at: .immediate)
        }
    }

    // MARK: Choosing the voice

    /// Where the manager's choice is saved. Only affects MotelR — never Siri.
    static let voiceKey = "assistantVoiceIdentifier"

    static var chosenVoiceIdentifier: String? {
        let id = UserDefaults.standard.string(forKey: voiceKey) ?? ""
        return id.isEmpty ? nil : id
    }

    /// The voice the assistant speaks with: the one picked in the Voice menu
    /// (if it's still a good one), otherwise the best gentleman voice installed.
    static var currentVoice: AVSpeechSynthesisVoice? {
        if let id = chosenVoiceIdentifier, let voice = AVSpeechSynthesisVoice(identifier: id), isGoodVoice(voice) {
            return voice
        }
        return gentlemanVoice
    }

    /// Joke / character voices that sound old, crackly or robotic on purpose,
    /// plus the 1990s Mac voices. Never used.
    private static let characterVoices: Set<String> = [
        "eddy", "flo", "grandma", "grandpa", "reed", "rocko", "sandy", "shelley",
        "albert", "bad news", "bahh", "bells", "boing", "bubbles", "cellos", "good news",
        "jester", "organ", "superstar", "trinoids", "whisper", "wobble", "zarvox",
        "fred", "junior", "kathy", "ralph", "agnes", "bruce", "princess", "vicki", "victoria"
    ]

    static func isGoodVoice(_ v: AVSpeechSynthesisVoice) -> Bool {
        let id = v.identifier.lowercased()
        let name = v.name.lowercased()
        let baseName = name.components(separatedBy: " (").first ?? name
        return !v.voiceTraits.contains(.isNoveltyVoice)
            && !v.voiceTraits.contains(.isPersonalVoice)
            && !id.contains("eloquence")
            && !id.contains("siri")                       // Siri voices come out garbled in apps
            && !id.hasPrefix("com.apple.speech.synthesis.voice")
            && !characterVoices.contains(baseName)
            && !isVoiceSix(v)
    }

    static func isVoiceSix(_ voice: AVSpeechSynthesisVoice?) -> Bool {
        guard let name = voice?.name else { return false }
        return name.range(of: #"\bvoice 6\b"#, options: [.regularExpression, .caseInsensitive]) != nil
    }

    /// Every voice MotelR may use in the phone's language, best quality first.
    static var availableVoices: [AVSpeechSynthesisVoice] {
        let family = String(AVSpeechSynthesisVoice.currentLanguageCode().prefix(2))
        return AVSpeechSynthesisVoice.speechVoices()
            .filter { $0.language.hasPrefix(family) && isGoodVoice($0) }
            .sorted { a, b in
                if a.quality != b.quality { return a.quality.rawValue > b.quality.rawValue }
                if a.name != b.name { return a.name < b.name }
                return a.language < b.language
            }
    }

    /// "Voice 6 · US · Premium"
    static func label(for voice: AVSpeechSynthesisVoice) -> String {
        let region = voice.language.split(separator: "-").last.map(String.init) ?? voice.language
        var text = "\(voice.name) · \(region)"
        switch voice.quality {
        case .premium:  text += " · Premium"
        case .enhanced: text += " · Enhanced"
        default:        text += " · Basic"
        }
        return text
    }

    /// The most natural male voice installed for the phone's language.
    /// Premium and Enhanced voices sound far more human; they can be downloaded in
    /// Settings → Accessibility → Spoken Content (Read & Speak) → Voices.
    static var gentlemanVoice: AVSpeechSynthesisVoice? {
        let language = AVSpeechSynthesisVoice.currentLanguageCode()
        // Smooth, well-known male voices. Daniel (British) is installed on every
        // iPhone and sounds like a polite gentleman even without a download.
        let favourites: [String: Int] = ["Daniel": 45, "Nathan": 40, "Evan": 40, "Tom": 35,
                                         "Aaron": 30, "Arthur": 30, "Oliver": 25, "Rishi": 20]
        func score(_ v: AVSpeechSynthesisVoice) -> Int {
            var points = 0
            switch v.quality {
            case .premium:  points += 100
            case .enhanced: points += 60
            default:        break
            }
            if v.gender == .male { points += 20 }
            let base = v.name.components(separatedBy: " (").first ?? v.name
            points += favourites[base] ?? 0
            if v.language == language { points += 5 }
            return points
        }
        return availableVoices.max { score($0) < score($1) }
            ?? AVSpeechSynthesisVoice(language: language)
            ?? AVSpeechSynthesisVoice(language: "en-US")
    }

    /// Drops emoji and symbols the voice would read out awkwardly.
    private static func speakable(_ text: String) -> String {
        let kept = text.unicodeScalars.filter { !($0.properties.isEmojiPresentation || $0.properties.isEmoji && $0.value > 0x2000) }
        return String(String.UnicodeScalarView(kept))
            .replacingOccurrences(of: "—", with: ", ")
            .replacingOccurrences(of: "•", with: "")
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer,
                                       willSpeakRangeOfSpeechString characterRange: NSRange,
                                       utterance: AVSpeechUtterance) {
        Task { @MainActor in self.meter.lastWordAt = Date() }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        let id = ObjectIdentifier(utterance)
        Task { @MainActor in
            guard self.current == id else { return }
            self.current = nil
            self.isSpeaking = false
            self.onFinished?()
        }
    }
}

#endif
