//  HistoryView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - HistoryView

struct HistoryView: View {
    @EnvironmentObject var motelData: MotelData

    @State private var searchText       = ""
    @State private var selectedFilter   = HistoryFilter.all
    @State private var showingPINForDelete      = false
    @State private var pendingDeleteBookings: [CDBooking] = []
    @State private var showReactivateErrorAlert = false
    @State private var reactivateErrorName      = ""

    // MARK: Filter

    enum HistoryFilter: String, CaseIterable, Identifiable {
        case all       = "All"
        case thisWeek  = "This Week"
        case thisMonth = "This Month"
        case thisYear  = "This Year"
        var id: String { rawValue }
    }

    // MARK: Derived Data

    private var filteredHistory: [CDBooking] {
        var result = motelData.history

        // Date filter
        let cal = Calendar.current
        let now = Date()
        switch selectedFilter {
        case .thisWeek:
            guard let start = cal.date(byAdding: .day, value: -7, to: now) else { break }
            result = result.filter { $0.checkOutDate >= start }
        case .thisMonth:
            guard let start = cal.date(byAdding: .month, value: -1, to: now) else { break }
            result = result.filter { $0.checkOutDate >= start }
        case .thisYear:
            guard let start = cal.date(byAdding: .year, value: -1, to: now) else { break }
            result = result.filter { $0.checkOutDate >= start }
        case .all: break
        }

        // Search
        if !searchText.isEmpty {
            let q = searchText.lowercased()
            result = result.filter {
                $0.customerName.lowercased().contains(q) ||
                String($0.room.number).contains(q) ||
                $0.drivingLicenseNumber.lowercased().contains(q)
            }
        }

        return result.sorted { $0.checkOutDate > $1.checkOutDate }
    }

    // Group by "Month YYYY"
    private var groupedHistory: [(String, [CDBooking])] {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        let dict = Dictionary(grouping: filteredHistory) { formatter.string(from: $0.checkOutDate) }
        // Sort sections newest-first by taking the first booking's date in each group
        return dict.sorted { lhs, rhs in
            let lDate = lhs.value.first?.checkOutDate ?? .distantPast
            let rDate = rhs.value.first?.checkOutDate ?? .distantPast
            return lDate > rDate
        }
    }

    private var totalRevenue: Double {
        filteredHistory.reduce(0.0) { $0 + $1.prizeAmount }
    }

    // MARK: Body

    var body: some View {
        VStack(spacing: 0) {
            filterBar
            searchBar
            summaryBar
            if filteredHistory.isEmpty {
                emptyStateView
            } else {
                historyList
            }
        }
        .background(Color(.systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("Booking History")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Delete Booking?", isPresented: $showingPINForDelete, titleVisibility: .visible) {
            Button("Delete", role: .destructive) { commitPendingDelete() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This booking will be permanently removed from history.")
        }
        .alert("Room Not Available", isPresented: $showReactivateErrorAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("Could not reactivate booking for \(reactivateErrorName) — room is already occupied for those dates.")
        }
    }

    // MARK: Filter Bar

    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(HistoryFilter.allCases) { filter in
                    filterChip(filter)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
        .background(Color(.systemBackground))
        .shadow(color: .black.opacity(0.04), radius: 3, x: 0, y: 2)
    }

    private func filterChip(_ filter: HistoryFilter) -> some View {
        Button(action: { withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) { selectedFilter = filter } }) {
            Text(filter.rawValue)
                .font(.system(size: 13, weight: selectedFilter == filter ? .bold : .medium, design: .rounded))
                .foregroundColor(selectedFilter == filter ? .white : .primary)
                .padding(.horizontal, 14)
                .padding(.vertical, 7)
                .background(
                    selectedFilter == filter
                    ? LinearGradient(colors: [primaryColor, primaryDark], startPoint: .leading, endPoint: .trailing)
                    : LinearGradient(colors: [Color(.systemGray5), Color(.systemGray5)], startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }

    // MARK: Search Bar

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.secondary)
                .font(.system(size: 15))
            TextField("Search guest, room, license...", text: $searchText)
                .font(.system(size: 14, design: .rounded))
            if !searchText.isEmpty {
                Button(action: { searchText = "" }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
    }

    // MARK: Summary Bar

    private var summaryBar: some View {
        HStack(spacing: 0) {
            summaryPill(
                value: "\(filteredHistory.count)",
                label: "Archived Bookings",
                icon: "archivebox.fill",
                color: primaryColor
            )
            Divider().frame(height: 30)
            summaryPill(
                value: String(format: "$%.0f", totalRevenue),
                label: "Archive Revenue",
                icon: "dollarsign.circle.fill",
                color: greenColor
            )
        }
        .padding(.vertical, 10)
        .background(Color(.systemBackground))
        .shadow(color: .black.opacity(0.04), radius: 3, x: 0, y: 2)
    }

    private func summaryPill(value: String, label: String, icon: String, color: Color) -> some View {
        VStack(spacing: 2) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(color)
                Text(value)
                    .font(.system(size: 17, weight: .bold, design: .rounded))
            }
            Text(label)
                .font(.system(size: 11, design: .rounded))
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: History List

    private var historyList: some View {
        List {
            ForEach(groupedHistory, id: \.0) { monthLabel, bookings in
                Section(header:
                    HStack(spacing: 6) {
                        Text(monthLabel)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundColor(primaryColor)
                            .textCase(nil)
                        Text("(\(bookings.count))")
                            .font(.system(size: 11, weight: .medium, design: .rounded))
                            .foregroundColor(.secondary)
                            .textCase(nil)
                    }
                ) {
                    ForEach(bookings, id: \.id) { booking in
                        NavigationLink(destination:
                            CustomerDetailsView(booking: booking, isHistorical: true)
                                .environmentObject(motelData)
                        ) {
                            HistoryBookingCard(booking: booking)
                        }
                        .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                        .listRowBackground(Color(.systemBackground))
                        .swipeActions(edge: .leading, allowsFullSwipe: true) {
                            Button {
                                reactivate(booking)
                            } label: {
                                Label("Reactivate", systemImage: "arrow.uturn.left.circle.fill")
                            }
                            .tint(greenColor)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                            Button(role: .destructive) {
                                pendingDeleteBookings = [booking]
                                showingPINForDelete   = true
                            } label: {
                                Label("Delete", systemImage: "trash.fill")
                            }
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .refreshable { motelData.fetchAllData() }
    }

    // MARK: Empty State

    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "archivebox")
                .font(.system(size: 56))
                .foregroundStyle(
                    LinearGradient(
                        colors: [primaryColor.opacity(0.6), primaryColor.opacity(0.3)],
                        startPoint: .top, endPoint: .bottom
                    )
                )
            Text(searchText.isEmpty ? "No History Yet" : "No Results Found")
                .font(.system(size: 22, weight: .bold, design: .rounded))
            Text(searchText.isEmpty
                 ? "Checked-out bookings will appear here."
                 : "Try adjusting your search or filter.")
                .font(.system(size: 15, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    // MARK: Actions

    private func reactivate(_ booking: CDBooking) {
        let success = motelData.reactivateBooking(booking)
        if !success {
            reactivateErrorName = booking.customerName
            showReactivateErrorAlert = true
        }
    }

    private func commitPendingDelete() {
        pendingDeleteBookings.forEach { booking in
            if let idx = motelData.history.firstIndex(where: { $0.id == booking.id }) {
                motelData.history.remove(at: idx)
            }
            // Remove the guest's licence photo file too (older builds stored it on disk).
            if let filename = booking.licenseImageFileName {
                LicenseImageManager.delete(named: filename)
            }
            CoreDataManager.shared.context.delete(booking)
        }
        CoreDataManager.shared.save()
        pendingDeleteBookings = []
    }

    // MARK: Design Tokens

    private var primaryColor: Color { Color(red: 0.18, green: 0.27, blue: 0.90) }
    private var primaryDark: Color  { Color(red: 0.05, green: 0.12, blue: 0.65) }
    private var greenColor: Color   { Color(red: 0.20, green: 0.78, blue: 0.35) }
}

// MARK: - HistoryBookingCard

struct HistoryBookingCard: View {
    let booking: CDBooking

    private var greenColor: Color  { Color(red: 0.20, green: 0.78, blue: 0.35) }
    private var goldColor: Color   { Color(red: 0.96, green: 0.65, blue: 0.14) }

    private var dateRange: String {
        let f = DateFormatter(); f.dateStyle = .short
        return "\(f.string(from: booking.checkInDate)) → \(f.string(from: booking.checkOutDate))"
    }

    private var paymentIcon: String {
        switch booking.paymentMethodEnum {
        case .cash:         return "banknote"
        case .card:         return "creditcard"
        case .check:        return "doc.text"
        case .organization: return "building.2"
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            // Room badge
            VStack(spacing: 2) {
                Text("Rm")
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundColor(Color(.systemGray))
                Text("\(booking.room.number)")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundColor(Color(.systemGray))
            }
            .frame(width: 44, height: 44)
            .background(Color(.systemGray5))
            .cornerRadius(10)

            // Center content
            VStack(alignment: .leading, spacing: 4) {
                Text(booking.customerName)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .lineLimit(1)
                Text(booking.drivingLicenseNumber.prefix(12))
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                Text(dateRange)
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
            }

            Spacer()

            // Right column
            VStack(alignment: .trailing, spacing: 5) {
                Text(booking.prize)
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)

                HStack(spacing: 3) {
                    Image(systemName: paymentIcon)
                        .font(.system(size: 10, weight: .semibold))
                    Text("\(booking.numberOfDays)n")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                }
                .foregroundColor(.secondary)

                if booking.isTaxed {
                    Text("Taxed")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color(red: 0.18, green: 0.27, blue: 0.90).opacity(0.10))
                        .clipShape(Capsule())
                }
            }
        }
        .padding(.vertical, 6)
    }
}

// MARK: - FilterChip (used in HistoryView — avoids duplicate in same module)
// Note: FilterChip is declared here only if the old HistoryView's version was
// the only declaration. Since we replaced the file, it is safe here.
struct FilterChip: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 11, weight: .semibold))
                Text(title)
                    .font(.system(size: 13, weight: isSelected ? .bold : .medium, design: .rounded))
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(isSelected ? Color(red: 0.18, green: 0.27, blue: 0.90) : Color(.systemGray5))
            .foregroundColor(isSelected ? .white : .primary)
            .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - StatBox (history summary box, used in some contexts)
struct StatBox: View {
    let title: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 4) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(color)
                Text(title)
                    .font(.system(size: 11, design: .rounded))
                    .foregroundColor(.secondary)
            }
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
}

// MARK: - BookingRowView (kept for backward-compatibility with any remaining references)
struct BookingRowView: View {
    let booking: CDBooking

    var body: some View {
        HistoryBookingCard(booking: booking)
    }
}

// MARK: - Preview

struct HistoryView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            HistoryView()
                .environmentObject(MotelData())
        }
    }
}
