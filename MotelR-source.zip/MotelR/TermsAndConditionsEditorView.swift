//  TermsAndConditionsEditorView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import UIKit

// MARK: - Design Tokens
private let tcPrimary = Color(red: 0.18, green: 0.27, blue: 0.90)
private let tcGradient = LinearGradient(
    colors: [Color(red: 0.18, green: 0.27, blue: 0.90), Color(red: 0.05, green: 0.12, blue: 0.65)],
    startPoint: .topLeading, endPoint: .bottomTrailing
)
private let tcGreen = Color(red: 0.20, green: 0.78, blue: 0.35)
private let tcGold  = Color(red: 0.96, green: 0.65, blue: 0.14)

// MARK: - TermsAndConditionsEditorView
struct TermsAndConditionsEditorView: View {
    @StateObject private var manager = TermsAndConditionsManager.shared
    @State private var editedText = ""
    @State private var isPreviewMode = false
    @State private var showSaveConfirmation = false
    @State private var showSavedToast = false
    @FocusState private var editorFocused: Bool

    private var charCount: Int { editedText.count }
    private var hasUnsavedChanges: Bool { editedText != manager.currentTerms }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                infoCard
                    .padding(.horizontal, 16)
                    .padding(.top, 12)
                    .padding(.bottom, 8)

                modeToggle
                    .padding(.horizontal, 16)
                    .padding(.bottom, 10)

                if isPreviewMode {
                    previewArea
                } else {
                    editorArea
                }

                saveBar
            }
            .background(Color(.systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("Terms & Conditions")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") { editorFocused = false }
                        .font(.system(.body, design: .rounded).weight(.semibold))
                }
            }
            .overlay(alignment: .bottom) {
                if showSavedToast {
                    savedToast
                        .padding(.bottom, 90)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
            .animation(.easeInOut(duration: 0.3), value: showSavedToast)
        }
        .onAppear {
            editedText = manager.currentTerms
        }
        .confirmationDialog(
            "Save & Update Version",
            isPresented: $showSaveConfirmation,
            titleVisibility: .visible
        ) {
            Button("Save") { performSave() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will bump the version to the next increment. Guests will need to re-sign on next check-in.")
        }
    }

    // MARK: Info Card
    private var infoCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "doc.text.fill")
                .font(.system(size: 20))
                .foregroundStyle(tcPrimary)
            VStack(alignment: .leading, spacing: 2) {
                Text("Guests sign these terms during check-in.")
                    .font(.system(.subheadline, design: .rounded))
                    .foregroundStyle(.primary)
                HStack(spacing: 4) {
                    Text("Current version:")
                        .font(.system(.caption, design: .rounded))
                        .foregroundStyle(.secondary)
                    Text(manager.termsVersion)
                        .font(.system(.caption, design: .rounded).weight(.bold))
                        .foregroundStyle(tcPrimary)
                    if hasUnsavedChanges {
                        Text("• Unsaved changes")
                            .font(.system(.caption, design: .rounded))
                            .foregroundStyle(tcGold)
                    }
                }
            }
            Spacer()
        }
        .padding(14)
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .shadow(color: .black.opacity(0.06), radius: 8)
    }

    // MARK: Mode Toggle
    private var modeToggle: some View {
        HStack(spacing: 0) {
            modeButton(title: "Edit", icon: "pencil", isSelected: !isPreviewMode) {
                isPreviewMode = false
            }
            modeButton(title: "Preview", icon: "eye.fill", isSelected: isPreviewMode) {
                isPreviewMode = true
                editorFocused = false
            }
        }
        .background(Color(.secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func modeButton(title: String, icon: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .semibold))
                Text(title)
                    .font(.system(.subheadline, design: .rounded).weight(.semibold))
            }
            .foregroundStyle(isSelected ? .white : .secondary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(
                isSelected
                    ? tcGradient
                    : LinearGradient(colors: [.clear, .clear], startPoint: .leading, endPoint: .trailing)
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
        }
        .buttonStyle(.plain)
    }

    // MARK: Editor Area
    private var editorArea: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .topLeading) {
                if editedText.isEmpty {
                    Text("Enter your terms and conditions here…")
                        .font(.system(.body, design: .rounded))
                        .foregroundStyle(Color(.placeholderText))
                        .padding(16)
                }
                TextEditor(text: $editedText)
                    .focused($editorFocused)
                    .font(.system(.body, design: .rounded))
                    .scrollContentBackground(.hidden)
                    .padding(12)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(.systemBackground))

            Divider()

            HStack {
                Text("\(charCount) characters")
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.secondary)
                Spacer()
                Text("Version \(manager.termsVersion)")
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(Color(.secondarySystemGroupedBackground))
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.07), radius: 10)
        .padding(.horizontal, 16)
        .frame(maxHeight: .infinity)
    }

    // MARK: Preview Area
    private var previewArea: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Label("Formatted Preview", systemImage: "doc.plaintext")
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(tcPrimary)
                    Spacer()
                    Text("v\(manager.termsVersion)")
                        .font(.system(.caption, design: .rounded).weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 3)
                        .background(tcPrimary)
                        .clipShape(Capsule())
                }
                Divider()
                Text(editedText.isEmpty ? "Nothing to preview." : editedText)
                    .font(.system(.body, design: .rounded))
                    .foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(16)
        }
        .background(Color(.systemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: .black.opacity(0.07), radius: 10)
        .padding(.horizontal, 16)
        .frame(maxHeight: .infinity)
    }

    // MARK: Save Bar
    private var saveBar: some View {
        VStack(spacing: 0) {
            Divider()
            HStack(spacing: 12) {
                Button {
                    editedText = manager.currentTerms
                } label: {
                    Text("Revert")
                        .font(.system(.subheadline, design: .rounded).weight(.semibold))
                        .foregroundStyle(hasUnsavedChanges ? tcPrimary : .secondary)
                        .padding(.vertical, 14)
                        .padding(.horizontal, 20)
                        .background(tcPrimary.opacity(hasUnsavedChanges ? 0.10 : 0.04))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                .disabled(!hasUnsavedChanges)

                Button {
                    if hasUnsavedChanges {
                        showSaveConfirmation = true
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 15, weight: .semibold))
                        Text("Save & Update Version")
                            .font(.system(.subheadline, design: .rounded).weight(.semibold))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(hasUnsavedChanges ? tcGradient : LinearGradient(colors: [Color(.systemGray4), Color(.systemGray4)], startPoint: .leading, endPoint: .trailing))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                .disabled(!hasUnsavedChanges)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color(.systemBackground))
        }
    }

    // MARK: Saved Toast
    private var savedToast: some View {
        HStack(spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(tcGreen)
            Text("Terms saved — version updated.")
                .font(.system(.subheadline, design: .rounded).weight(.semibold))
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial)
        .clipShape(Capsule())
        .shadow(color: .black.opacity(0.15), radius: 12, y: 4)
    }

    // MARK: Save Logic
    private func performSave() {
        manager.saveTerms(editedText)
        let haptic = UINotificationFeedbackGenerator()
        haptic.notificationOccurred(.success)
        showSavedToast = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            showSavedToast = false
        }
    }
}
