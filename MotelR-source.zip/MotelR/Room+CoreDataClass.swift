//
//  Room+CoreDataClass.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/13/24.
//
//

import Foundation
import CoreData

@objc(CDRoom)  // Changed from Room to CDRoom
public class CDRoom: NSManagedObject {
    // This file will be used as a base class for Room entity
}
