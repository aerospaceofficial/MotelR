//
//  BookingAssistant.swift
//  MotelR 2.0 — by New Journey
//
//  The booking assistant. The manager talks or types normally
//  ("jane smith 2 nights cash") and the assistant fills in a booking.
//
//  How it is built (version 2, after testing):
//
//  The first version let Apple's small on-device model run the conversation and
//  call tools. In practice it forgot to save details, asked for things it had
//  already been told, went round in circles, and often never showed the
//  confirmation card. So now:
//
//    • The APP runs the conversation. It knows exactly what is still missing,
//      asks for one thing at a time in a fixed order, and shows the confirmation
//      card itself as soon as the booking is complete.
//    • A fast rule-based reader (`BookingMessageParser`) handles the common
//      answers — "2 nights", "room 12", "$89", "cash", "yes", phone numbers.
//    • The AI model is only used to READ details out of a message (names,
//      addresses, licence numbers, dates in odd wording). Each message is read
//      on its own with a fresh session, so it never runs out of memory.
//    • Everything the model reads is checked against the manager's own words:
//      if a name or number doesn't actually appear in the message, it's ignored.
//      That stops the model inventing details.
//
//  The booking is only saved after the manager confirms and the guest signs,
//  through the same code path as the normal Check In screen.
//
//  Requires iOS 26+ on an Apple Intelligence device. Skipped entirely when
//  building with an Xcode that doesn't have the FoundationModels framework.
//

#if canImport(FoundationModels)
import SwiftUI
import CoreData
import FoundationModels

// MARK: - Availability

/// Whether the assistant can run on this device, in plain terms for the UI.
enum AssistantAvailability {
    case available
    case needsAppleIntelligence   // supported device, but Apple Intelligence is off
    case modelDownloading         // switched on, model still downloading
    case unsupported              // older device or OS

    static var current: AssistantAvailability {
        guard #available(iOS 26.0, *) else { return .unsupported }
        switch SystemLanguageModel.default.availability {
        case .available:
            return .available
        case .unavailable(.appleIntelligenceNotEnabled):
            return .needsAppleIntelligence
        case .unavailable(.modelNotReady):
            return .modelDownloading
        default:
            return .unsupported
        }
    }
}

// MARK: - Draft booking

/// Everything gathered so far. The app, not the model, decides what is missing.
struct AssistantDraft {
    var guestName = ""
    var phone = ""
    var licenseNumber = ""
    var street = ""
    var city = ""
    var state = ""
    var zipCode = ""
    var checkIn = Calendar.current.startOfDay(for: Date())
    var nights: Int?
    var roomNumber: Int?
    var nightlyRate: Double?
    var payment: PaymentMethod?
    var cardType = ""
    var checkNumber = ""
    var organizationName = ""
    var billLater = true
    var taxIncluded = true

    var checkOut: Date {
        Calendar.current.date(byAdding: .day, value: max(nights ?? 1, 1), to: checkIn) ?? checkIn
    }

    var total: Double {
        (nightlyRate ?? 0) * Double(nights ?? 0)
    }

    var firstName: String {
        guestName.split(separator: " ").first.map(String.init) ?? "the guest"
    }

    var hasFullAddress: Bool {
        !street.isEmpty && !city.isEmpty && !state.isEmpty && !zipCode.isEmpty
    }

    var hasPhone: Bool { phone.filter(\.isNumber).count >= 10 }

    var isComplete: Bool { nextField == nil }

    /// The next thing to ask for, in a fixed order. nil when the booking is complete.
    var nextField: AssistantField? {
        if guestName.isEmpty { return .name }
        if nights == nil { return .nights }
        if roomNumber == nil { return .room }
        if nightlyRate == nil { return .rate }
        if payment == nil { return .payment }
        if payment == .card && cardType.isEmpty { return .cardType }
        if payment == .check && checkNumber.isEmpty { return .checkNumber }
        if payment == .organization && organizationName.isEmpty { return .organization }
        if licenseNumber.isEmpty { return .license }
        if !hasFullAddress { return .address }
        if !hasPhone { return .phone }
        return nil
    }
}

/// One thing the assistant can ask for.
enum AssistantField: Hashable {
    case name, nights, room, rate, payment, cardType, checkNumber, organization, license, address, phone
}

// MARK: - Chat message and quick replies

struct AssistantMessage: Identifiable, Equatable {
    enum Sender { case manager, assistant, app }
    let id = UUID()
    let sender: Sender
    let text: String
}

struct AssistantQuickReply: Identifiable {
    enum Action {
        case send(String)
        case scan
        case sign
        case review
    }
    let id = UUID()
    let title: String
    let icon: String?
    let action: Action
}

// MARK: - What the AI model reads out of a message

@available(iOS 26.0, *)
@Generable
struct ExtractedBookingDetails {
    @Guide(description: "Guest's full name, only if the message says it")
    var guestName: String?
    @Guide(description: "Driving licence number, only if the message says it")
    var licenseNumber: String?
    @Guide(description: "Street address including the house number")
    var street: String?
    @Guide(description: "City")
    var city: String?
    @Guide(description: "Two-letter US state code, e.g. IL")
    var state: String?
    @Guide(description: "5-digit ZIP code")
    var zipCode: String?
    @Guide(description: "Phone number")
    var phone: String?
    @Guide(description: "Check-in day: today, tomorrow, or yyyy-MM-dd")
    var checkInDate: String?
    @Guide(description: "Number of nights")
    var nights: Int?
    @Guide(description: "Room number")
    var roomNumber: Int?
    @Guide(description: "Price per night in dollars")
    var nightlyRate: Double?
    @Guide(description: "Name of the company paying, only for organization bookings")
    var organizationName: String?
}

// MARK: - Assistant

@available(iOS 26.0, *)
@MainActor
final class BookingAssistant: ObservableObject {
    @Published var messages: [AssistantMessage] = []
    @Published var draft = AssistantDraft()
    @Published var roomChoices: [CDRoom] = []
    @Published var isThinking = false
    @Published var showScanner = false
    @Published var showConfirmation = false
    /// Set when the manager says "confirm" — the screen opens the signature step.
    @Published var wantsSignature = false
    @Published var incidentWarning: String?
    @Published var bookingSaved = false
    /// A past guest with the same name, waiting for the manager to say yes or no.
    @Published private(set) var possibleReturningGuest: CDBooking?
    /// True while a booking is being taken (otherwise the assistant answers questions).
    @Published var bookingActive = false
    /// A check-out or payment waiting for the manager's "yes".
    @Published var pendingAction: AssistantPendingAction?
    /// A screen the manager asked to open ("open analytics").
    @Published var openScreen: AssistantScreen?

    let motelData: MotelData
    var lastQuestion = ""
    /// Hands-free voice mode is open: shorter replies, and the scanner and
    /// signature screens open by themselves.
    var voiceMode = false
    /// The scanner has already been opened for this booking (only once).
    private var autoScanned = false
    private var retries: [AssistantField: Int] = [:]
    private var warnedLicense = ""
    private var askedReturningFor = ""

    init(motelData: MotelData) {
        self.motelData = motelData
        greet(first: true)
    }

    // MARK: Conversation

    func send(_ text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isThinking else { return }
        if bookingSaved {
            // The last booking is done; keep chatting with a fresh draft.
            startFreshDraft()
        }
        messages.append(AssistantMessage(sender: .manager, text: trimmed))
        Task { await handle(trimmed) }
    }

    /// Clears the booking but keeps the conversation.
    private func startFreshDraft() {
        draft = AssistantDraft()
        roomChoices = []
        showConfirmation = false
        wantsSignature = false
        bookingSaved = false
        bookingActive = false
        possibleReturningGuest = nil
        retries = [:]
        warnedLicense = ""
        askedReturningFor = ""
        autoScanned = false
    }

    /// Starts over for the next guest.
    func reset() {
        pendingAction = nil
        bookingActive = false
        draft = AssistantDraft()
        roomChoices = []
        showConfirmation = false
        wantsSignature = false
        bookingSaved = false
        incidentWarning = nil
        possibleReturningGuest = nil
        retries = [:]
        warnedLicense = ""
        askedReturningFor = ""
        autoScanned = false
        messages = []
        greet(first: false)
    }

    /// A short spoken hello when voice mode opens.
    func voiceGreeting() {
        let hour = Calendar.current.component(.hour, from: Date())
        let time = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening"
        say(bookingActive && !bookingSaved ? "\(time). Let's carry on with the booking." : "\(time). How may I help?")
    }

    private func greet(first: Bool) {
        let text = first
            ? "Hi! I can book rooms, check guests out and answer questions about the motel. What do you need?"
            : "Ready — book the next guest, or ask me anything."
        lastQuestion = text
        messages.append(AssistantMessage(sender: .assistant, text: text))
    }

    private func handle(_ text: String) async {
        isThinking = true
        defer { isThinking = false }

        let parser = BookingMessageParser(text: text, pending: draft.nextField)

        // 1. Cancel / start over.
        if parser.wantsStartOver {
            if pendingAction != nil {
                pendingAction = nil
                say("Okay, cancelled.")
            } else {
                reset()
            }
            return
        }

        // 2. An action waiting for a yes (check-out, mark paid).
        if pendingAction != nil {
            if parser.isYes && !parser.hasAnyDetail {
                say(performPendingAction() + bookingReminder())
                return
            }
            if parser.isNo && !parser.hasAnyDetail {
                pendingAction = nil
                say("Okay, I won't." + bookingReminder())
                return
            }
            pendingAction = nil   // they moved on
        }

        // 3. Booking confirmations and the returning-guest question.
        if bookingActive && draft.isComplete && parser.isYes && !parser.hasAnyDetail {
            if showConfirmation || voiceMode {
                wantsSignature = true
                say("Very good — please have the guest read the terms and sign.")
            } else {
                showConfirmation = true
                say("Here's the booking — check it, then tap Sign & Confirm or say “confirm”.")
            }
            return
        }
        if let guest = possibleReturningGuest {
            if parser.isYes && !parser.hasAnyDetail {
                fill(fromReturningGuest: guest)
                possibleReturningGuest = nil
                askNext(acknowledging: ["filled in \(draft.firstName)'s licence, address and phone from last time"])
                return
            }
            if parser.isNo && !parser.hasAnyDetail {
                possibleReturningGuest = nil
                askNext(acknowledging: [], prefix: "No problem.")
                return
            }
            possibleReturningGuest = nil
        }
        if parser.wantsScan {
            bookingActive = true
            say("Opening the scanner — scan the barcode on the back of the licence.")
            showScanner = true
            return
        }
        if bookingActive && parser.wantsFreeRooms && !parser.hasAnyDetail {
            say(roomListSentence(intro: true))
            return
        }

        // 4. Questions and commands about the motel ("who's in room 12?", "check out room 4").
        if let command = AssistantCommandReader.read(parser, motelData: motelData, bookingActive: bookingActive) {
            answer(command)
            return
        }

        // 5. Booking details.
        // Starting a booking from idle needs real booking details or a name that was clearly
        // meant as one — otherwise "thank you so much" would become a guest called Thank You.
        if bookingActive || parser.hasAnyDetail || (parser.bareName != nil && parser.nameIsIntentional) {
            bookingActive = true
            await continueBooking(with: parser, text: text)
            return
        }

        // 6. Nothing the rules know — ask the AI what kind of request this is.
        if let command = await AssistantIntentModel.guess(text, parser: parser, motelData: motelData) {
            answer(command)
            return
        }
        say("I'm not sure what you mean. You can book a room, check someone out, or ask things like “who checks out today?” or “how much did we make this week?”.")
    }

    private func answer(_ command: AssistantCommand) {
        let reply = run(command)
        if case .startBooking = command {
            lastQuestion = reply
            say(reply)
        } else {
            say(reply + (pendingAction == nil ? bookingReminder() : ""))
        }
    }

    /// When a booking is half done, a gentle nudge back to it after a side question.
    private func bookingReminder() -> String {
        guard bookingActive, !bookingSaved, draft.nextField != nil, !draft.guestName.isEmpty else { return "" }
        return " Back to \(draft.firstName)'s booking — \(question(for: draft.nextField))"
    }

    private func continueBooking(with parser: BookingMessageParser, text: String) async {
        let pending = draft.nextField
        var changes: [String] = []
        var problems: [String] = []
        let checkInBefore = draft.checkIn
        let nightsBefore = draft.nights

        applyRules(parser, pending: pending, changes: &changes, problems: &problems)

        if parser.needsModel(pendingField: pending) {
            if let details = await extractWithModel(text) {
                applyModel(details, verifiedAgainst: parser, pending: pending, changes: &changes, problems: &problems)
            }
        }

        // Dates changed with a room already picked: make sure it's still free.
        if draft.checkIn != checkInBefore || draft.nights != nightsBefore,
           let room = draft.roomNumber, !isRoomFree(room) {
            draft.roomNumber = nil
            problems.append("Room \(room) isn't free for those dates any more, so I've taken it off.")
        }

        if changes.isEmpty && problems.isEmpty {
            // Maybe it was a question the rules didn't recognise.
            if let command = await AssistantIntentModel.guess(text, parser: parser, motelData: motelData),
               !isBookingCommand(command) {
                answer(command)
                return
            }
            retryQuestion(for: pending)
            return
        }
        if let field = pending, !changes.isEmpty, draft.nextField != field {
            retries[field] = 0
        }
        if checkForReturningGuest(changes: changes) { return }
        askNext(acknowledging: changes, problems: problems)
    }

    private func isBookingCommand(_ command: AssistantCommand) -> Bool {
        if case .startBooking = command { return true }
        return false
    }

    /// Acknowledges what was understood, mentions any problem, then asks the next
    /// question — or shows the confirmation card when nothing is missing.
    private func askNext(acknowledging changes: [String], problems: [String] = [], prefix: String? = nil) {
        var changes = changes
        fillFromHistory(&changes)

        var parts: [String] = []
        if let prefix { parts.append(prefix) }
        if !changes.isEmpty {
            // Spoken replies stay short: only the first few details are read back.
            let shown = changes.prefix(voiceMode ? 3 : 6).joined(separator: ", ")
            parts.append(voiceMode ? "Very good — \(shown)." : "Got it — \(shown).")
        }
        parts.append(contentsOf: problems)

        if draft.isComplete {
            roomChoices = []
            if voiceMode {
                // No separate confirm step: the signature screen shows the summary.
                showConfirmation = false
                parts.append("\(draft.guestName), room \(draft.roomNumber ?? 0), \(draft.nights ?? 1) night\(draft.nights == 1 ? "" : "s"), \(String(format: "$%.2f", draft.total)). Please have the guest sign.")
                say(parts.joined(separator: " "))
                wantsSignature = true
                return
            }
            let wasShowing = showConfirmation
            showConfirmation = true
            parts.append(wasShowing
                ? "I've updated the card — check it again."
                : "That's everything! Check the booking below, then tap Sign & Confirm — or just say “confirm”.")
            say(parts.joined(separator: " "))
            return
        }

        showConfirmation = false

        // Voice mode: the camera is the quickest way to get the name, licence and
        // address, so open it once per booking when one of those is next.
        if voiceMode, !autoScanned, draft.licenseNumber.isEmpty,
           draft.nextField == .name || draft.nextField == .license {
            autoScanned = true
            let who = draft.guestName.isEmpty ? "their" : "\(draft.firstName)'s"
            let next = "Let's scan \(who) licence — hold the barcode up to the camera, or just tell me instead."
            lastQuestion = next
            parts.append(next)
            say(parts.joined(separator: " "))
            showScanner = true
            return
        }

        let next = question(for: draft.nextField)
        lastQuestion = next
        parts.append(next)
        say(parts.joined(separator: " "))
    }

    /// Uses the room's last nightly rate instead of asking for it again.
    /// The manager can still change it ("make it 79").
    private func fillFromHistory(_ changes: inout [String]) {
        if draft.nightlyRate == nil, let room = draft.roomNumber, let last = lastRate(forRoom: room) {
            draft.nightlyRate = last
            changes.append(String(format: "$%.2f a night like last time", last))
        }
    }

    private func retryQuestion(for field: AssistantField?) {
        guard let field else {
            say("Sorry, I didn't catch that. Tap Sign & Confirm when the booking looks right, or tell me what to change.")
            return
        }
        let count = (retries[field] ?? 0) + 1
        retries[field] = count
        let hint: String
        switch field {
        case .name:         hint = "Just say their first and last name, like “Jane Smith” — or tap Scan ID."
        case .nights:       hint = "Just say a number, like “2”, or tap a button below."
        case .room:         hint = "Say the room number, like “room 12”, or tap one of the rooms below."
        case .rate:         hint = "Say the price per night, like “89” or “$89.50”."
        case .payment:      hint = "Say cash, card, check or organization — or tap a button below."
        case .cardType:     hint = "Say Visa, Mastercard, Amex or Discover."
        case .checkNumber:  hint = "Say the number printed on the check, like “1042”."
        case .organization: hint = "Say the name of the company paying."
        case .license:      hint = "Read out the licence number, or tap Scan ID — that's quickest."
        case .address:      hint = "Say it like “100 Oak Street, Chicago, IL 60601” — or tap Scan ID."
        case .phone:        hint = "Say the 10-digit number, like “555 123 4567”."
        }
        lastQuestion = question(for: field)
        say(count >= 2 ? "I'm still not getting it, sorry. \(hint)" : "Sorry, I didn't catch that. \(hint)")
    }

    private func question(for field: AssistantField?) -> String {
        guard let field else { return "" }
        switch field {
        case .name:
            return "Who's checking in?"
        case .nights:
            if draft.roomNumber == nil {
                // Ask both at once — one answer like "2 nights, room 104" covers it.
                return "How many nights, and which room? \(roomListSentence(intro: true))"
            }
            return "How many nights for \(draft.firstName)?"
        case .room:
            return roomListSentence(intro: false)
        case .rate:
            if let room = draft.roomNumber, let last = lastRate(forRoom: room) {
                return String(format: "What's the nightly rate for Room %d? Last time it was $%.2f.", room, last)
            }
            if draft.payment == nil {
                return "What's the nightly rate for Room \(draft.roomNumber ?? 0), and how are they paying?"
            }
            return "What's the nightly rate for Room \(draft.roomNumber ?? 0)?"
        case .payment:
            return "How is \(draft.firstName) paying — cash, card, check or organization?"
        case .cardType:
            return "Which card — Visa, Mastercard, Amex or Discover?"
        case .checkNumber:
            return "What's the check number?"
        case .organization:
            return "Which company is paying?"
        case .license:
            if !draft.hasFullAddress && !draft.hasPhone {
                return "Last bit — \(draft.firstName)'s licence number, home address and phone. Scan ID fills in most of it."
            }
            return "What's \(draft.firstName)'s driving licence number? Tapping Scan ID fills in the licence and address in one go."
        case .address:
            if !draft.street.isEmpty || !draft.city.isEmpty || !draft.zipCode.isEmpty {
                var missing: [String] = []
                if draft.street.isEmpty { missing.append("street") }
                if draft.city.isEmpty { missing.append("city") }
                if draft.state.isEmpty { missing.append("state") }
                if draft.zipCode.isEmpty { missing.append("ZIP code") }
                return "And the \(missing.joined(separator: ", "))?"
            }
            if !draft.hasPhone {
                return "And \(draft.firstName)'s home address and phone number?"
            }
            return "What's \(draft.firstName)'s home address — street, city, state and ZIP?"
        case .phone:
            return "And a phone number for \(draft.firstName)?"
        }
    }

    private func roomListSentence(intro: Bool) -> String {
        let free = freeRooms()
        roomChoices = free
        let dates = "\(Self.shortDate(draft.checkIn)) to \(Self.shortDate(draft.checkOut))"
        if motelData.rooms.isEmpty {
            return "You haven't added any rooms yet — say something like “add rooms 101 to 120” first."
        }
        guard !free.isEmpty else {
            return "Sorry — no rooms are free from \(dates). Try fewer nights or a different day."
        }
        let limit = voiceMode ? 5 : 10
        let numbers = free.prefix(limit).map { "\($0.number)" }.joined(separator: ", ")
        let more = free.count > limit ? " and \(free.count - limit) more" : ""
        return intro
            ? "Free from \(dates): rooms \(numbers)\(more)."
            : "Which room? Free from \(dates): \(numbers)\(more)."
    }

    private func say(_ text: String) {
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        messages.append(AssistantMessage(sender: .assistant, text: clean))
    }

    // MARK: Quick replies

    /// Buttons under the chat, matching whatever is being asked right now.
    var quickReplies: [AssistantQuickReply] {
        var replies: [AssistantQuickReply] = []

        if pendingAction != nil {
            replies.append(AssistantQuickReply(title: "Yes, do it", icon: "checkmark", action: .send("Yes")))
            replies.append(AssistantQuickReply(title: "Cancel", icon: "xmark", action: .send("No")))
            return replies
        }
        if motelData.rooms.isEmpty {
            replies.append(AssistantQuickReply(title: "Add rooms 101–110", icon: "plus.circle", action: .send("Add rooms 101 to 110")))
            replies.append(AssistantQuickReply(title: "Add 20 rooms", icon: "plus.circle", action: .send("Add 20 rooms")))
            replies.append(AssistantQuickReply(title: "What can you do?", icon: "questionmark.circle", action: .send("What can you do?")))
            return replies
        }
        if !bookingActive || bookingSaved {
            replies.append(AssistantQuickReply(title: "Book a room", icon: "bed.double.fill", action: .send("Book a room")))
            replies.append(AssistantQuickReply(title: "Scan ID", icon: "barcode.viewfinder", action: .scan))
            replies.append(AssistantQuickReply(title: "Who checks out today?", icon: "door.left.hand.open", action: .send("Who checks out today?")))
            replies.append(AssistantQuickReply(title: "Free rooms tonight", icon: "bed.double", action: .send("Which rooms are free tonight?")))
            replies.append(AssistantQuickReply(title: "How full are we?", icon: "chart.pie", action: .send("How full are we?")))
            replies.append(AssistantQuickReply(title: "Today's takings", icon: "dollarsign.circle", action: .send("How much did we make today?")))
            replies.append(AssistantQuickReply(title: "Who owes us?", icon: "building.2", action: .send("Who owes us money?")))
            return replies
        }

        if possibleReturningGuest != nil {
            replies.append(AssistantQuickReply(title: "Yes, same guest", icon: "checkmark", action: .send("Yes")))
            replies.append(AssistantQuickReply(title: "No, someone else", icon: "xmark", action: .send("No")))
            return replies
        }
        if showConfirmation {
            replies.append(AssistantQuickReply(title: "Sign & Confirm", icon: "signature", action: .sign))
            return replies
        }

        if draft.isComplete {
            replies.append(AssistantQuickReply(title: "Show booking", icon: "checklist", action: .review))
            return replies
        }

        replies.append(AssistantQuickReply(title: "Scan ID", icon: "barcode.viewfinder", action: .scan))
        switch draft.nextField {
        case .nights:
            for n in [1, 2, 3] {
                let label = "\(n) night\(n == 1 ? "" : "s")"
                replies.append(AssistantQuickReply(title: label, icon: nil, action: .send(label)))
            }
            replies.append(AssistantQuickReply(title: "1 week", icon: nil, action: .send("7 nights")))
        case .room:
            for room in roomChoices.prefix(10) {
                replies.append(AssistantQuickReply(title: "Room \(room.number)", icon: "bed.double.fill", action: .send("Room \(room.number)")))
            }
        case .rate:
            if let room = draft.roomNumber, let last = lastRate(forRoom: room) {
                let price = String(format: "$%.2f", last)
                replies.append(AssistantQuickReply(title: price, icon: "dollarsign.circle", action: .send("\(price) a night")))
            }
        case .payment:
            replies.append(AssistantQuickReply(title: "Cash", icon: "banknote", action: .send("Cash")))
            replies.append(AssistantQuickReply(title: "Card", icon: "creditcard", action: .send("Card")))
            replies.append(AssistantQuickReply(title: "Check", icon: "doc.text", action: .send("Paying by check")))
            replies.append(AssistantQuickReply(title: "Organization", icon: "building.2", action: .send("Organization")))
        case .cardType:
            for brand in ["Visa", "Mastercard", "Amex", "Discover"] {
                replies.append(AssistantQuickReply(title: brand, icon: "creditcard", action: .send(brand)))
            }
        default:
            break
        }
        return replies
    }

    // MARK: Reading details

    private func applyRules(_ p: BookingMessageParser, pending: AssistantField?,
                            changes: inout [String], problems: inout [String]) {
        if pending == .name, let name = p.bareName {
            setName(name, changes: &changes)
        }
        if let license = p.license {
            setLicense(license, changes: &changes)
        }
        if let street = p.addressStreet, draft.street != street { draft.street = street; changes.append(street) }
        if let city = p.addressCity, draft.city != city { draft.city = city; changes.append(city) }
        if let state = p.addressState, draft.state != state { draft.state = state; changes.append(state) }
        if let zip = p.addressZip, draft.zipCode != zip { draft.zipCode = zip; changes.append(zip) }
        if let date = p.checkIn, !Calendar.current.isDate(date, inSameDayAs: draft.checkIn) {
            draft.checkIn = date
            changes.append("checking in \(Self.shortDate(date))")
        }
        if let n = p.nights {
            if (1...365).contains(n) {
                if draft.nights != n {
                    draft.nights = n
                    changes.append("\(n) night\(n == 1 ? "" : "s")")
                }
            } else {
                problems.append("\(n) nights doesn't look right.")
            }
        }
        if p.nights == nil, let leave = p.departure {
            let n = Calendar.current.dateComponents([.day], from: draft.checkIn, to: leave).day ?? 0
            if n >= 1 {
                if draft.nights != n {
                    draft.nights = n
                    changes.append("\(n) night\(n == 1 ? "" : "s") (leaving \(Self.shortDate(leave)))")
                }
            } else {
                problems.append("That check-out day is before the check-in day.")
            }
        }
        if let total = p.total, p.rate == nil {
            if let n = draft.nights, n > 0 {
                setRate(total / Double(n), plusTax: p.plusTax, changes: &changes, problems: &problems)
            } else {
                problems.append("Is that the total or the price per night?")
            }
        }
        if let rate = p.rate {
            setRate(rate, plusTax: p.plusTax, changes: &changes, problems: &problems)
        }
        if p.noTax && draft.taxIncluded {
            draft.taxIncluded = false
            changes.append("no tax")
        }
        if let method = p.payment {
            setPayment(method, changes: &changes)
        }
        if let brand = p.cardType {
            if draft.payment == nil { setPayment(.card, changes: &changes) }
            if draft.payment == .card && draft.cardType != brand {
                draft.cardType = brand
                changes.append(brand)
            }
        }
        if let number = p.checkNumber {
            if draft.payment == nil { setPayment(.check, changes: &changes) }
            if draft.payment == .check && draft.checkNumber != number {
                draft.checkNumber = number
                changes.append("check #\(number)")
            }
        }
        if let phone = p.phone {
            let formatted = Self.formatPhone(phone)
            if draft.phone != formatted {
                draft.phone = formatted
                changes.append("phone \(formatted)")
            }
        }
        if let room = p.room {
            setRoom(room, changes: &changes, problems: &problems)
        }
        if let org = p.organizationName, draft.payment == .organization || pending == .organization {
            if draft.payment == nil { setPayment(.organization, changes: &changes) }
            if draft.organizationName != org {
                draft.organizationName = org
                changes.append("billed to \(org)")
            }
        }
        if p.billLater && draft.payment == .organization && !draft.billLater {
            draft.billLater = true
            changes.append("billing later")
        }
        if p.paidNow && draft.payment == .organization && draft.billLater {
            draft.billLater = false
            changes.append("paid now")
        }
    }

    private func extractWithModel(_ text: String) async -> ExtractedBookingDetails? {
        let df = DateFormatter()
        df.dateFormat = "EEEE yyyy-MM-dd"
        let instructions = """
        You read one message from a motel manager who is checking a guest in, and copy out \
        the booking details it contains. Fill a field only if the message clearly says it. \
        Leave everything else empty. Never guess or make anything up. \
        Today is \(df.string(from: Date())).
        """
        let prompt = """
        The assistant had asked: "\(lastQuestion)"
        The manager answered: "\(text)"
        """
        // A new session for every message: nothing to forget, nothing to loop on.
        // Given up after a few seconds so the chat never hangs on "Thinking…".
        return await assistantWithTimeout(6, {
            try? await LanguageModelSession(instructions: instructions)
                .respond(to: prompt, generating: ExtractedBookingDetails.self).content
        })
    }

    /// Uses what the model read — but only values that really appear in the message.
    private func applyModel(_ d: ExtractedBookingDetails, verifiedAgainst p: BookingMessageParser,
                            pending: AssistantField?, changes: inout [String], problems: inout [String]) {
        if p.bareName == nil, let name = d.guestName, p.mentionsName(name) {
            setName(name, changes: &changes)
        }
        if let license = d.licenseNumber, license.filter(\.isNumber).count >= 3, p.mentionsCode(license) {
            setLicense(license, changes: &changes)
        }
        if p.addressStreet == nil, let street = d.street, street.contains(where: \.isNumber), p.mentionsWords(street), draft.street != street {
            draft.street = street
            changes.append(street)
        }
        if p.addressCity == nil, let city = d.city, p.mentionsWords(city) {
            let tidy = city == city.lowercased() ? city.capitalized : city
            if draft.city != tidy {
                draft.city = tidy
                changes.append(tidy)
            }
        }
        if p.addressState == nil, let state = d.state.flatMap(BookingMessageParser.stateCode), p.mentionsState(state), draft.state != state {
            draft.state = state
            changes.append(state)
        }
        if p.addressZip == nil, let zip = d.zipCode, zip.count == 5, zip.allSatisfy(\.isNumber), p.mentionsCode(zip), draft.zipCode != zip {
            draft.zipCode = zip
            changes.append(zip)
        }
        if p.phone == nil, let phone = d.phone, phone.filter(\.isNumber).count >= 10, p.mentionsCode(phone) {
            let formatted = Self.formatPhone(phone)
            if draft.phone != formatted {
                draft.phone = formatted
                changes.append("phone \(formatted)")
            }
        }
        if p.checkIn == nil, p.mentionsDate, let raw = d.checkInDate,
           let date = BookingMessageParser.parseISODate(raw),
           !Calendar.current.isDate(date, inSameDayAs: draft.checkIn) {
            draft.checkIn = date
            changes.append("checking in \(Self.shortDate(date))")
        }
        if p.nights == nil, let n = d.nights, (1...365).contains(n), p.mentionsNumber(n),
           pending == .nights || p.mentionsNightWord, draft.nights != n {
            draft.nights = n
            changes.append("\(n) night\(n == 1 ? "" : "s")")
        }
        if p.room == nil, let room = d.roomNumber, p.mentionsNumber(room),
           pending == .room || p.mentionsRoomWord {
            setRoom(room, changes: &changes, problems: &problems)
        }
        if p.rate == nil, p.total == nil, let rate = d.nightlyRate, rate > 0, p.mentionsNumber(Int(rate)),
           pending == .rate || p.mentionsMoneyWord {
            setRate(rate, plusTax: p.plusTax, changes: &changes, problems: &problems)
        }
        if let org = d.organizationName, !org.isEmpty, p.mentionsWords(org),
           draft.payment == .organization || pending == .organization || p.payment == .organization {
            if draft.payment == nil { setPayment(.organization, changes: &changes) }
            if draft.organizationName != org {
                draft.organizationName = org
                changes.append("billed to \(org)")
            }
        }
        // A short answer to "which company?" that the model didn't pick up.
        if pending == .organization, draft.organizationName.isEmpty, let words = p.shortAnswer {
            draft.organizationName = words
            changes.append("billed to \(words)")
        }
    }

    // MARK: Setting fields

    private func setName(_ raw: String, changes: inout [String]) {
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        let tidy = name == name.lowercased() ? name.capitalized : name
        guard draft.guestName != tidy else { return }
        draft.guestName = tidy
        changes.append(tidy)
    }

    private func setLicense(_ raw: String, changes: inout [String]) {
        let license = raw.uppercased().filter { $0.isLetter || $0.isNumber || $0 == "-" }
        guard !license.isEmpty, draft.licenseNumber != license else { return }
        draft.licenseNumber = license
        changes.append("licence \(license)")
        checkIncidents()
    }

    private func setRate(_ value: Double, plusTax: Bool, changes: inout [String], problems: inout [String]) {
        guard value > 0, value < 10_000 else {
            problems.append("That rate doesn't look right.")
            return
        }
        var rate = value
        if plusTax && motelData.taxRate > 0 {
            rate = (value * (1 + motelData.taxRate) * 100).rounded() / 100
            draft.taxIncluded = true
        }
        guard draft.nightlyRate != rate else { return }
        draft.nightlyRate = rate
        changes.append(String(format: plusTax ? "$%.2f a night with tax" : "$%.2f a night", rate))
    }

    private func setPayment(_ method: PaymentMethod, changes: inout [String]) {
        guard draft.payment != method else { return }
        draft.payment = method
        switch method {
        case .cash:         changes.append("paying cash")
        case .card:         changes.append("paying by card")
        case .check:        changes.append("paying by check")
        case .organization: changes.append("billed to a company")
        }
    }

    private func setRoom(_ number: Int, changes: inout [String], problems: inout [String]) {
        guard motelData.rooms.contains(where: { Int($0.number) == number }) else {
            problems.append("There's no Room \(number).")
            return
        }
        guard isRoomFree(number) else {
            problems.append("Room \(number) is booked for those dates.")
            return
        }
        guard draft.roomNumber != number else { return }
        draft.roomNumber = number
        roomChoices = []
        changes.append("Room \(number)")
    }

    // MARK: Returning guests

    /// After a new name, offers to reuse a past guest's details. Returns true if it asked.
    private func checkForReturningGuest(changes: [String]) -> Bool {
        let name = draft.guestName.lowercased()
        guard !name.isEmpty, draft.licenseNumber.isEmpty, askedReturningFor != name,
              changes.contains(draft.guestName) else { return false }
        askedReturningFor = name
        let matches = (motelData.history + motelData.bookings)
            .filter { $0.customerName.lowercased() == name && !$0.drivingLicenseNumber.isEmpty }
        guard let past = matches.max(by: { $0.checkInDate < $1.checkInDate }) else { return false }

        possibleReturningGuest = past
        let ack = "Got it — \(changes.prefix(4).joined(separator: ", "))."
        say("\(ack) \(past.customerName) stayed here before (last on \(Self.shortDate(past.checkInDate)), licence \(past.drivingLicenseNumber)). Same guest? I can fill in their details.")
        return true
    }

    private func fill(fromReturningGuest b: CDBooking) {
        draft.licenseNumber = b.drivingLicenseNumber
        draft.street = b.address
        draft.city = b.city
        draft.state = b.state
        draft.zipCode = b.zipCode
        if b.phoneNumber.filter(\.isNumber).count >= 10 { draft.phone = b.phoneNumber }
        checkIncidents()
    }

    // MARK: Scanner

    /// Called by the scanner screen when it reads a licence.
    func scannerRead(_ license: ScannedLicense) {
        if bookingSaved { startFreshDraft() }
        var changes: [String] = []
        if !license.fullName.isEmpty {
            draft.guestName = license.fullName
            changes.append(license.fullName)
        }
        if !license.licenseNumber.isEmpty {
            draft.licenseNumber = license.licenseNumber
            changes.append("licence \(license.licenseNumber)")
        }
        if !license.address.isEmpty { draft.street = license.address }
        if !license.city.isEmpty    { draft.city = license.city }
        if !license.state.isEmpty   { draft.state = license.state }
        if !license.zipCode.isEmpty { draft.zipCode = license.zipCode }
        bookingActive = true
        if draft.hasFullAddress { changes.append("address in \(draft.city)") }
        askedReturningFor = draft.guestName.lowercased()   // scanned details win over past records
        possibleReturningGuest = nil
        messages.append(AssistantMessage(sender: .app, text: "ID scanned"))
        checkIncidents()
        askNext(acknowledging: changes)
    }

    /// Called when the scanner closes, whether or not it read anything.
    func scannerClosed() {}

    // MARK: Saving

    /// Saves the booking — same steps as the Check In screen.
    func saveBooking(signature: UIImage) -> Bool {
        guard draft.isComplete,
              let number = draft.roomNumber,
              let room = motelData.rooms.first(where: { Int($0.number) == number }),
              let nights = draft.nights,
              let payment = draft.payment else { return false }

        let booking = CDBooking(
            context: CoreDataManager.shared.context,
            room: room,
            customerName: draft.guestName,
            phoneNumber: draft.phone,
            drivingLicenseNumber: draft.licenseNumber,
            address: draft.street,
            city: draft.city,
            state: draft.state,
            zipCode: draft.zipCode,
            signatureImageData: signature.jpegData(compressionQuality: 0.8),
            paymentMethodEnum: payment,
            cardType: payment == .card ? draft.cardType : nil,
            checkNumber: payment == .check ? draft.checkNumber : nil,
            organizationName: payment == .organization ? draft.organizationName : nil,
            prize: String(format: "$%.2f", draft.total),
            numberOfDays: nights,
            checkInDate: draft.checkIn,
            checkOutDate: draft.checkOut,
            isTaxed: draft.taxIncluded
        )
        booking.paymentStatus = (payment == .organization && draft.billLater)
            ? PaymentStatus.pending.rawValue
            : PaymentStatus.paid.rawValue

        guard motelData.addBooking(booking) else {
            draft.roomNumber = nil
            showConfirmation = false
            askNext(acknowledging: [], problems: ["Room \(number) was taken in the meantime."])
            return false
        }
        scheduleCheckoutReminderNotification(booking: booking)
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        showConfirmation = false
        wantsSignature = false
        bookingSaved = true
        roomChoices = []
        messages.append(AssistantMessage(
            sender: .app,
            text: "Booked: \(draft.guestName) in Room \(number), \(Self.shortDate(draft.checkIn)) – \(Self.shortDate(draft.checkOut))"
        ))
        bookingActive = false
        say("All done — \(draft.firstName) is booked into Room \(number). Anything else?")
        return true
    }

    // MARK: Helpers

    /// Shows the incident warning once per licence number.
    private func checkIncidents() {
        let key = MotelData.normalizedLicense(draft.licenseNumber)
        guard !key.isEmpty, key != warnedLicense,
              let message = motelData.incidentWarningMessage(forLicense: draft.licenseNumber) else { return }
        warnedLicense = key
        incidentWarning = message
    }

    private func freeRooms() -> [CDRoom] {
        motelData.rooms
            .filter { isRoomFree(Int($0.number)) }
            .sorted { $0.number < $1.number }
    }

    /// Same overlap rule as the rest of the app: check-out day can be the next check-in day.
    private func isRoomFree(_ number: Int) -> Bool {
        let start = draft.checkIn
        let end = draft.checkOut
        return !motelData.bookings.contains { b in
            Int(b.room.number) == number && b.checkInDate < end && start < b.checkOutDate
        }
    }

    /// Nightly rate the room went for most recently, as a suggestion.
    private func lastRate(forRoom number: Int) -> Double? {
        let past = (motelData.history + motelData.bookings)
            .filter { Int($0.room.number) == number && $0.numberOfDays > 0 && $0.prizeAmount > 0 }
            .max { $0.checkInDate < $1.checkInDate }
        guard let past else { return nil }
        return (past.prizeAmount / Double(past.numberOfDays) * 100).rounded() / 100
    }

    static func formatPhone(_ raw: String) -> String {
        var digits = raw.filter(\.isNumber)
        if digits.count == 11, digits.hasPrefix("1") { digits.removeFirst() }
        guard digits.count == 10 else { return raw }
        let a = digits.prefix(3), b = digits.dropFirst(3).prefix(3), c = digits.suffix(4)
        return "(\(a)) \(b)-\(c)"
    }

    static func shortDate(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "EEE MMM d"
        return f.string(from: date)
    }
}

#endif
