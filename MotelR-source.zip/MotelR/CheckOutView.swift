//  CheckOutView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI

// MARK: - CheckOutView

struct CheckOutView: View {
    @EnvironmentObject var motelData: MotelData
    @State private var searchText: String = ""
    @State private var selectedBooking: CDBooking? = nil
    @State private var showDetail = false

    // Design tokens
    private let primaryColor = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let primaryGradient = LinearGradient(
        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                 Color(red: 0.05, green: 0.12, blue: 0.65)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let redColor   = Color(red: 1.0,  green: 0.23, blue: 0.19)
    private let greenColor = Color(red: 0.20, green: 0.78, blue: 0.35)
    private let goldColor  = Color(red: 0.96, green: 0.65, blue: 0.14)

    private var filteredBookings: [CDBooking] {
        let base = motelData.bookings.sorted { $0.room.number < $1.room.number }
        guard !searchText.trimmingCharacters(in: .whitespaces).isEmpty else { return base }
        let q = searchText.lowercased()
        return base.filter {
            $0.customerName.lowercased().contains(q) ||
            String($0.room.number).contains(q)
        }
    }

    var body: some View {
        ZStack {
            Color(UIColor.systemGroupedBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                // Search bar
                searchBar
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)

                if filteredBookings.isEmpty {
                    emptyState
                } else {
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(filteredBookings, id: \.id) { booking in
                                CheckOutRowCard(booking: booking,
                                               primaryColor: primaryColor,
                                               greenColor: greenColor,
                                               goldColor: goldColor)
                                    .onTapGesture {
                                        selectedBooking = booking
                                        showDetail = true
                                    }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.bottom, 30)
                    }
                }
            }
        }
        .navigationTitle("Check Out")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(item: $selectedBooking) { booking in
            CheckOutDetailView(booking: booking)
                .environmentObject(motelData)
        }
    }

    // MARK: - Search bar
    private var searchBar: some View {
        HStack {
            Image(systemName: "magnifyingglass").foregroundColor(.secondary)
            TextField("Search by guest name or room…", text: $searchText)
                .font(.system(size: 15, design: .rounded))
            if !searchText.isEmpty {
                Button { searchText = "" } label: {
                    Image(systemName: "xmark.circle.fill").foregroundColor(.secondary)
                }
            }
        }
        .padding(12)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, y: 2)
    }

    // MARK: - Empty state
    private var emptyState: some View {
        VStack(spacing: 18) {
            Spacer()
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 56))
                .foregroundStyle(LinearGradient(colors: [greenColor, greenColor.opacity(0.6)],
                                                startPoint: .topLeading, endPoint: .bottomTrailing))
            Text("All Clear")
                .font(.system(size: 22, weight: .bold, design: .rounded))
            Text(searchText.isEmpty
                 ? "No guests are currently checked in."
                 : "No guests match \"\(searchText)\".")
                .font(.system(size: 15, design: .rounded))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            Spacer()
        }
        .padding(.horizontal, 30)
    }
}

// MARK: - CheckOutRowCard

struct CheckOutRowCard: View {
    let booking: CDBooking
    let primaryColor: Color
    let greenColor: Color
    let goldColor: Color

    private var daysStayed: Int {
        let cal = Calendar.current
        let components = cal.dateComponents([.day], from: booking.checkInDate, to: Date())
        return max(components.day ?? 0, 0)
    }

    var body: some View {
        HStack(spacing: 14) {
            // Room badge
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(LinearGradient(
                        colors: [Color(red: 1.0, green: 0.23, blue: 0.19),
                                 Color(red: 0.80, green: 0.10, blue: 0.10)],
                        startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 52, height: 52)
                VStack(spacing: 1) {
                    Text("Rm")
                        .font(.system(size: 9, weight: .medium, design: .rounded))
                        .foregroundColor(.white.opacity(0.85))
                    Text("\(booking.room.number)")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(booking.customerName)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                HStack(spacing: 4) {
                    Image(systemName: "arrow.right.circle").font(.system(size: 11))
                    Text("Checked in \(DateFormatter.shortDate.string(from: booking.checkInDate))")
                        .font(.system(size: 12, design: .rounded))
                }
                .foregroundColor(.secondary)
                if daysStayed > 0 {
                    Text("\(daysStayed) day\(daysStayed == 1 ? "" : "s") elapsed")
                        .font(.system(size: 11, design: .rounded))
                        .foregroundColor(daysStayed > Int(booking.numberOfDays) ? Color(red: 1.0, green: 0.23, blue: 0.19) : .secondary)
                }
            }

            Spacer()

            VStack(alignment: .trailing, spacing: 6) {
                Text(booking.prize)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundColor(primaryColor)
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.secondary)
            }
        }
        .padding(14)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }
}

// MARK: - CheckOutDetailView

struct CheckOutDetailView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss
    let booking: CDBooking

    @State private var showConfirmAlert = false
    @State private var showSuccessOverlay = false
    @State private var showShareSheet = false
    @State private var successScale: CGFloat = 0.5
    @State private var successOpacity: Double = 0

    private let primaryColor = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let primaryGradient = LinearGradient(
        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                 Color(red: 0.05, green: 0.12, blue: 0.65)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let greenColor = Color(red: 0.20, green: 0.78, blue: 0.35)
    private let goldColor  = Color(red: 0.96, green: 0.65, blue: 0.14)
    private let redGradient = LinearGradient(
        colors: [Color(red: 1.0, green: 0.23, blue: 0.19),
                 Color(red: 0.80, green: 0.10, blue: 0.10)],
        startPoint: .topLeading, endPoint: .bottomTrailing)

    private var daysStayed: Int {
        let cal = Calendar.current
        return max(cal.dateComponents([.day], from: booking.checkInDate, to: Date()).day ?? 0, 0)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(UIColor.systemGroupedBackground).ignoresSafeArea()
                ScrollView {
                    VStack(spacing: 16) {
                        // Guest info card
                        guestInfoCard
                        // Room info card
                        roomInfoCard
                        // Payment summary
                        paymentCard
                        // Action buttons
                        actionButtons
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 10)
                    .padding(.bottom, 40)
                }

                if showSuccessOverlay {
                    successView
                }
            }
            .navigationTitle("Check Out Guest")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
            .alert("Confirm Check-Out", isPresented: $showConfirmAlert) {
                Button("Check Out", role: .destructive) { performCheckOut() }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure you want to check out \(booking.customerName) from Room \(booking.room.number)? This will move the booking to history.")
            }
        }
    }

    // MARK: - Guest info card
    private var guestInfoCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "person.fill")
                    .foregroundColor(primaryColor)
                Text("Guest Information")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            Divider()
            detailRow(label: "Name", value: booking.customerName, icon: "person")
            detailRow(label: "Phone", value: booking.phoneNumber, icon: "phone")
            detailRow(label: "License #", value: booking.drivingLicenseNumber, icon: "creditcard")
            if !booking.address.isEmpty {
                detailRow(label: "Address",
                          value: "\(booking.address), \(booking.city), \(booking.state) \(booking.zipCode)",
                          icon: "house")
            }
        }
        .padding(16)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }

    // MARK: - Room info card
    private var roomInfoCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "bed.double.fill")
                    .foregroundColor(primaryColor)
                Text("Room & Stay Details")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            Divider()
            detailRow(label: "Room", value: "Room \(booking.room.number)", icon: "door.left.hand.open")
            if !booking.room.name.isEmpty {
                detailRow(label: "Room Name", value: booking.room.name, icon: "tag")
            }
            detailRow(label: "Check-in", value: DateFormatter.shortDate.string(from: booking.checkInDate), icon: "arrow.right.circle")
            detailRow(label: "Check-out", value: DateFormatter.shortDate.string(from: booking.checkOutDate), icon: "arrow.left.circle")
            detailRow(label: "Booked Nights", value: "\(booking.numberOfDays)", icon: "moon.stars")
            if daysStayed > 0 {
                detailRow(label: "Days Elapsed", value: "\(daysStayed)", icon: "clock")
            }
        }
        .padding(16)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }

    // MARK: - Payment card
    private var paymentCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "creditcard.fill")
                    .foregroundColor(primaryColor)
                Text("Payment Summary")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            Divider()
            detailRow(label: "Amount", value: booking.prize, icon: "dollarsign.circle", highlight: true)
            detailRow(label: "Method", value: booking.paymentMethodEnum.rawValue, icon: paymentIcon(booking.paymentMethodEnum))
            if booking.isTaxed { detailRow(label: "Tax", value: "Included", icon: "percent") }
            if let card = booking.cardType, !card.isEmpty {
                detailRow(label: "Card", value: card, icon: "creditcard")
            }
            if let check = booking.checkNumber, !check.isEmpty {
                detailRow(label: "Check #", value: check, icon: "doc.text")
            }
            if let org = booking.organizationName, !org.isEmpty {
                detailRow(label: "Organization", value: org, icon: "building.2")
            }
            // Status badge
            HStack {
                Spacer()
                let isPaid = booking.paymentStatusEnum == .paid
                Label(isPaid ? "Paid" : "Pending",
                      systemImage: isPaid ? "checkmark.circle.fill" : "clock.fill")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundColor(isPaid ? greenColor : goldColor)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 7)
                    .background((isPaid ? greenColor : goldColor).opacity(0.12))
                    .clipShape(Capsule())
            }
        }
        .padding(16)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }

    // MARK: - Action buttons
    private var actionButtons: some View {
        VStack(spacing: 12) {
            // Complete check-out
            Button { showConfirmAlert = true } label: {
                HStack {
                    Spacer()
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.system(size: 18, weight: .bold))
                    Text("Complete Check-Out")
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                    Spacer()
                }
                .foregroundColor(.white)
                .padding(.vertical, 18)
                .background(redGradient)
                .cornerRadius(16)
                .shadow(color: Color(red: 1.0, green: 0.23, blue: 0.19).opacity(0.30), radius: 10, y: 4)
            }

            // Receipt / share (stub – navigates to CustomerDetailsView for full receipt)
            NavigationLink(destination: CustomerDetailsView(booking: booking).environmentObject(motelData)) {
                HStack {
                    Spacer()
                    Image(systemName: "doc.text.fill")
                        .font(.system(size: 16))
                    Text("View Receipt")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                    Spacer()
                }
                .foregroundColor(primaryColor)
                .padding(.vertical, 14)
                .background(primaryColor.opacity(0.10))
                .cornerRadius(14)
            }
        }
    }

    // MARK: - Success overlay
    private var successView: some View {
        ZStack {
            Color.black.opacity(0.45).ignoresSafeArea()
            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .fill(greenColor)
                        .frame(width: 100, height: 100)
                    Image(systemName: "checkmark")
                        .font(.system(size: 44, weight: .bold))
                        .foregroundColor(.white)
                }
                .scaleEffect(successScale)
                .opacity(successOpacity)

                Text("Checked Out!")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .opacity(successOpacity)
                Text("\(booking.customerName) has been checked out from Room \(booking.room.number).")
                    .font(.system(size: 15, design: .rounded))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .opacity(successOpacity)
            }
            .padding(40)
            .background(Color(UIColor.systemBackground).opacity(0.97))
            .cornerRadius(24)
            .shadow(color: .black.opacity(0.15), radius: 20, y: 8)
            .padding(.horizontal, 40)
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                successScale = 1
                successOpacity = 1
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                dismiss()
            }
        }
    }

    // MARK: - Helpers
    private func detailRow(label: String, value: String, icon: String, highlight: Bool = false) -> some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 13))
                .foregroundColor(primaryColor.opacity(0.75))
                .frame(width: 18)
            Text(label)
                .font(.system(size: 13, design: .rounded))
                .foregroundColor(.secondary)
                .frame(width: 90, alignment: .leading)
            Spacer()
            Text(value)
                .font(.system(size: 14, weight: highlight ? .bold : .medium, design: .rounded))
                .foregroundColor(highlight ? primaryColor : .primary)
                .multilineTextAlignment(.trailing)
        }
    }

    private func paymentIcon(_ m: PaymentMethod) -> String {
        switch m {
        case .cash:         return "banknote"
        case .check:        return "doc.text"
        case .card:         return "creditcard"
        case .organization: return "building.2"
        }
    }

    private func performCheckOut() {
        motelData.checkOut(booking)
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        withAnimation { showSuccessOverlay = true }
    }
}

// MARK: - Preview
struct CheckOutView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            CheckOutView()
                .environmentObject(MotelData())
        }
    }
}
