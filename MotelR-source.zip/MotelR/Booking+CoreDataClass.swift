//
//  Booking+CoreDataClass.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/13/24.
//
//

import Foundation
import CoreData

@objc(CDBooking)  // Changed from Booking to CDBooking
public class CDBooking: NSManagedObject {
    // This file will be used as a base class for Booking entity
}
