//
//  BackupUtils.swift
//  MotelR
//
//  Export and import of the encrypted backup archive.
//
//  An exported archive carries the payload files plus a `keywrap.json` holding the
//  data key sealed under a key derived from a password the user chooses. The password
//  never leaves the device and is not stored, so an exported file on its own — in
//  email, in iCloud Drive, on someone else's Mac — is not readable.
//

import Foundation
import CryptoKit
import UIKit
import UniformTypeIdentifiers
import SwiftUI
import ZIPFoundation

class BackupUtils {
    static let shared = BackupUtils()
    private init() {}

    /// Payload files that make up a complete backup.
    static let payloadFiles = [
        "rooms.encrypted",
        "bookings.encrypted",
        "history.encrypted",
        "incidents.encrypted",
        "settings.encrypted"
    ]

    private static let keyWrapFile = "keywrap.json"

    // MARK: - File System Operations

    func getDocumentsDirectory() -> URL? {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    }

    func getBackupFiles() -> [URL]? {
        guard let backupURL = BackupManager.shared.getBackupURL() else { return nil }
        do {
            let files = try FileManager.default.contentsOfDirectory(at: backupURL, includingPropertiesForKeys: nil)
            return files.filter { $0.pathExtension == "encrypted" }
        } catch {
            print("Error getting backup files: \(error)")
            return nil
        }
    }

    // MARK: - Key Wrapping

    private struct KeyWrap: Codable {
        let version: Int
        let rounds: Int
        let salt: Data
        let wrappedKey: Data
    }

    private func makeKeyWrap(password: String, dataKey: SymmetricKey) throws -> Data {
        var salt = Data(count: 16)
        _ = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }

        let kek = SecurityManager.derivedKey(fromPassword: password, salt: salt)
        let rawKey = dataKey.withUnsafeBytes { Data($0) }
        guard let sealed = try AES.GCM.seal(rawKey, using: kek).combined else {
            throw BackupError.exportFailed
        }

        return try JSONEncoder().encode(KeyWrap(
            version: 1,
            rounds: SecurityManager.keyDerivationRounds,
            salt: salt,
            wrappedKey: sealed
        ))
    }

    private func unwrapKey(from wrapData: Data, password: String) throws -> SymmetricKey {
        let wrap = try JSONDecoder().decode(KeyWrap.self, from: wrapData)
        let kek = SymmetricKey(data: SecurityManager.pbkdf2SHA256(
            password: password,
            salt: wrap.salt,
            rounds: wrap.rounds,
            byteCount: 32
        ))
        do {
            let box = try AES.GCM.SealedBox(combined: wrap.wrappedKey)
            return SymmetricKey(data: try AES.GCM.open(box, using: kek))
        } catch {
            // AES-GCM authentication failed — effectively always a wrong password.
            throw BackupError.wrongPassword
        }
    }

    // MARK: - Backup Export

    /// Builds a fresh backup and packages it into a password-protected zip.
    func exportBackup(password: String) throws -> URL {
        guard password.count >= 6 else { throw BackupError.weakPassword }

        // Core Data work has to happen on the view context's own queue.
        try CoreDataManager.shared.performAndWait { _ in
            let motelData = MotelData()
            try BackupManager.shared.createBackup(motelData: motelData)
        }

        guard let backupURL = BackupManager.shared.getBackupURL(),
              FileManager.default.fileExists(atPath: backupURL.path) else {
            throw BackupError.noBackupFound
        }

        let tempDir = FileManager.default.temporaryDirectory
        let zipURL = tempDir.appendingPathComponent("MotelRBackup_\(Int(Date().timeIntervalSince1970)).zip")
        try? FileManager.default.removeItem(at: zipURL)

        guard let archive = try? Archive(url: zipURL, accessMode: .create, pathEncoding: nil) else {
            throw BackupError.exportFailed
        }

        for name in Self.payloadFiles {
            let file = backupURL.appendingPathComponent(name)
            guard FileManager.default.fileExists(atPath: file.path) else {
                throw BackupError.noBackupFound
            }
            try archive.addEntry(with: name, fileURL: file)
        }

        // Seal the data key under the user's password and ship it alongside.
        let wrapData = try makeKeyWrap(
            password: password,
            dataKey: SecurityManager.shared.getOrCreateBackupKey()
        )
        try archive.addEntry(
            with: Self.keyWrapFile,
            type: .file,
            uncompressedSize: Int64(wrapData.count)
        ) { position, size in
            let start = Int(position)
            return wrapData.subdata(in: start ..< min(start + size, wrapData.count))
        }

        return zipURL
    }

    // MARK: - Backup Import

    /// Unpacks an exported archive into the local backup folder, re-encrypting it
    /// under this device's key. The existing backup is only replaced once the new
    /// one has been fully decrypted and verified.
    func importBackup(from sourceURL: URL, password: String) throws {
        guard sourceURL.pathExtension.lowercased() == "zip" else {
            throw BackupError.invalidBackup
        }

        // Stage everything in a scratch directory first.
        let staging = FileManager.default.temporaryDirectory
            .appendingPathComponent("MotelRImport_\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: staging) }

        try extractZip(from: sourceURL, to: staging)

        // Every payload file must be present before we touch anything.
        for name in Self.payloadFiles {
            guard FileManager.default.fileExists(atPath: staging.appendingPathComponent(name).path) else {
                throw BackupError.invalidBackup
            }
        }

        guard let wrapData = try? Data(contentsOf: staging.appendingPathComponent(Self.keyWrapFile)) else {
            throw BackupError.missingKeyWrap
        }
        let archiveKey = try unwrapKey(from: wrapData, password: password)

        // Decrypt with the archive's key and re-encrypt under this device's key, so a
        // later restore just works. A corrupt file throws here, before anything is replaced.
        let localKey = SecurityManager.shared.getOrCreateBackupKey()
        var reEncrypted: [String: Data] = [:]
        for name in Self.payloadFiles {
            let cipherText = try Data(contentsOf: staging.appendingPathComponent(name))
            let plain: Data
            do {
                plain = try AES.GCM.open(try AES.GCM.SealedBox(combined: cipherText), using: archiveKey)
            } catch {
                throw BackupError.invalidBackup
            }
            guard let resealed = try AES.GCM.seal(plain, using: localKey).combined else {
                throw BackupError.invalidBackup
            }
            reEncrypted[name] = resealed
        }

        // Everything decoded cleanly — now it is safe to swap the live backup out.
        let backupDir = try ensureBackupDirectory()
        try clearExistingBackup(at: backupDir)
        for (name, data) in reEncrypted {
            try data.write(to: backupDir.appendingPathComponent(name), options: .atomic)
        }

        guard BackupManager.shared.backupExists() else {
            throw BackupError.invalidBackup
        }
    }

    private func ensureBackupDirectory() throws -> URL {
        guard let backupDir = BackupManager.shared.getBackupURL() else {
            throw BackupError.invalidDirectory
        }
        if !FileManager.default.fileExists(atPath: backupDir.path) {
            try FileManager.default.createDirectory(
                at: backupDir,
                withIntermediateDirectories: true,
                attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication]
            )
        }
        return backupDir
    }

    private func clearExistingBackup(at directory: URL) throws {
        guard FileManager.default.fileExists(atPath: directory.path) else { return }
        let existingFiles = try FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: nil
        )
        for file in existingFiles {
            try FileManager.default.removeItem(at: file)
        }
    }

    /// Extracts a zip, refusing entries whose path would escape the destination
    /// directory (`../..` traversal) or that nest into subdirectories.
    private func extractZip(from zipURL: URL, to directory: URL) throws {
        guard let archive = try? Archive(url: zipURL, accessMode: .read, pathEncoding: nil) else {
            throw BackupError.invalidBackup
        }

        let allowed = Set(Self.payloadFiles + [Self.keyWrapFile])

        for entry in archive {
            let name = (entry.path as NSString).lastPathComponent
            guard entry.type == .file,
                  allowed.contains(name),
                  !entry.path.contains("..")
            else { continue }

            let destination = directory.appendingPathComponent(name)
            // Belt and braces: the resolved path must still sit inside the staging dir.
            guard destination.standardizedFileURL.path.hasPrefix(directory.standardizedFileURL.path) else {
                throw BackupError.invalidBackup
            }
            _ = try archive.extract(entry, to: destination)
        }
    }

    enum BackupError: LocalizedError {
        case noBackupFound
        case invalidDirectory
        case invalidBackup
        case exportFailed
        case importFailed
        case wrongPassword
        case missingKeyWrap
        case weakPassword

        var errorDescription: String? {
            switch self {
            case .noBackupFound:
                return "No backup found."
            case .invalidDirectory:
                return "Could not access the backup folder."
            case .invalidBackup:
                return "This backup file is damaged or incomplete."
            case .exportFailed:
                return "Could not create the backup file."
            case .importFailed:
                return "Could not import the backup."
            case .wrongPassword:
                return "Incorrect password. Enter the password used when this backup was exported."
            case .missingKeyWrap:
                return "This file was exported by an older version of MotelR and cannot be imported. Export a fresh backup from the original device."
            case .weakPassword:
                return "Please use a backup password of at least 6 characters."
            }
        }
    }
}

// MARK: - Document Picker View

struct BackupDocumentPicker: UIViewControllerRepresentable {
    let onCompletion: (Result<URL, Error>) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let supportedTypes: [UTType] = [.zip, .item]
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: supportedTypes)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: BackupDocumentPicker

        init(_ parent: BackupDocumentPicker) {
            self.parent = parent
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else {
                parent.onCompletion(.failure(BackupUtils.BackupError.importFailed))
                return
            }

            guard url.startAccessingSecurityScopedResource() else {
                parent.onCompletion(.failure(BackupUtils.BackupError.importFailed))
                return
            }
            defer { url.stopAccessingSecurityScopedResource() }

            // Copy out of the security-scoped location so the file stays readable after
            // this callback returns and the password prompt is answered.
            let local = FileManager.default.temporaryDirectory
                .appendingPathComponent("MotelRPicked_\(UUID().uuidString).zip")
            do {
                try? FileManager.default.removeItem(at: local)
                try FileManager.default.copyItem(at: url, to: local)
                parent.onCompletion(.success(local))
            } catch {
                parent.onCompletion(.failure(error))
            }
        }
    }
}
