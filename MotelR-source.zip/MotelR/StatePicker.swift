//
//  StatePicker.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/11/24.
//

import SwiftUI

// First, add this enum at the top level of your file
enum USState: String, CaseIterable {
    case alabama = "Alabama"
    case alaska = "Alaska"
    case arizona = "Arizona"
    case arkansas = "Arkansas"
    case california = "California"
    case colorado = "Colorado"
    case connecticut = "Connecticut"
    case delaware = "Delaware"
    case florida = "Florida"
    case georgia = "Georgia"
    case hawaii = "Hawaii"
    case idaho = "Idaho"
    case illinois = "Illinois"
    case indiana = "Indiana"
    case iowa = "Iowa"
    case kansas = "Kansas"
    case kentucky = "Kentucky"
    case louisiana = "Louisiana"
    case maine = "Maine"
    case maryland = "Maryland"
    case massachusetts = "Massachusetts"
    case michigan = "Michigan"
    case minnesota = "Minnesota"
    case mississippi = "Mississippi"
    case missouri = "Missouri"
    case montana = "Montana"
    case nebraska = "Nebraska"
    case nevada = "Nevada"
    case newHampshire = "New Hampshire"
    case newJersey = "New Jersey"
    case newMexico = "New Mexico"
    case newYork = "New York"
    case northCarolina = "North Carolina"
    case northDakota = "North Dakota"
    case ohio = "Ohio"
    case oklahoma = "Oklahoma"
    case oregon = "Oregon"
    case pennsylvania = "Pennsylvania"
    case rhodeIsland = "Rhode Island"
    case southCarolina = "South Carolina"
    case southDakota = "South Dakota"
    case tennessee = "Tennessee"
    case texas = "Texas"
    case utah = "Utah"
    case vermont = "Vermont"
    case virginia = "Virginia"
    case washington = "Washington"
    case westVirginia = "West Virginia"
    case wisconsin = "Wisconsin"
    case wyoming = "Wyoming"
}

// Add this new view component
struct StatePickerView: View {
    @Binding var selectedState: String
    @State private var showingPicker = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("State")
                .font(.headline)
            
            Button(action: { showingPicker = true }) {
                HStack {
                    Image(systemName: "map")
                        .foregroundColor(.blue)
                    
                    Text(selectedState.isEmpty ? "Select State" : selectedState)
                        .foregroundColor(selectedState.isEmpty ? .gray : .primary)
                    
                    Spacer()
                    
                    Image(systemName: "chevron.down")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color(UIColor.systemBackground))
                .cornerRadius(10)
                .shadow(radius: 1)
            }
        }
        .sheet(isPresented: $showingPicker) {
            NavigationView {
                List(USState.allCases, id: \.self) { state in
                    Button(action: {
                        selectedState = state.rawValue
                        showingPicker = false
                    }) {
                        HStack {
                            Text(state.rawValue)
                            Spacer()
                            if state.rawValue == selectedState {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    .foregroundColor(.primary)
                }
                .navigationTitle("Select State")
                .navigationBarItems(
                    trailing: Button("Cancel") {
                        showingPicker = false
                    }
                )
            }
            .presentationDetents([.medium])
        }
    }
}
