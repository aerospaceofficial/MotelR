//
//  Booking+CoreDataProperties.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 12/13/24.
//
//

import Foundation
import CoreData

enum PaymentMethod: String, Codable, CaseIterable {
    case cash = "Cash"
    case check = "Check"
    case card = "Card"
    case organization = "Organization"
    
    static func from(string: String) -> PaymentMethod? {
        return PaymentMethod(rawValue: string)
    }
}

enum PaymentStatus: String, Codable {
    case paid = "Paid"
    case pending = "Pending"
}

extension CDBooking: Identifiable {}

extension CDBooking {
    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDBooking> {
        return NSFetchRequest<CDBooking>(entityName: "Booking")
    }

    @NSManaged public var id: UUID
    @NSManaged public var customerName: String
    @NSManaged public var phoneNumber: String
    @NSManaged public var drivingLicenseNumber: String
    @NSManaged public var address: String
    @NSManaged public var city: String
    @NSManaged public var state: String
    @NSManaged public var zipCode: String
    @NSManaged public var licenseImageData: Data?
    @NSManaged public var licenseImageFileName: String?
    @NSManaged public var signatureImageData: Data?
    @NSManaged public var signatureDate: Date?
    @NSManaged public var termsVersion: String?
    @NSManaged public var paymentMethod: String
    @NSManaged public var cardType: String?
    @NSManaged public var checkNumber: String?
    @NSManaged public var organizationName: String?
    @NSManaged public var prize: String
    @NSManaged public var numberOfDays: Int16
    @NSManaged public var checkInDate: Date
    @NSManaged public var checkOutDate: Date
    @NSManaged public var isTaxed: Bool
    @NSManaged public var isHistory: Bool
    @NSManaged public var paymentStatus: String
    @NSManaged public var room: CDRoom
    
    // Add computed property to get PaymentMethod enum
    var paymentMethodEnum: PaymentMethod {
        get {
            return PaymentMethod.from(string: paymentMethod) ?? .cash
        }
        set {
            paymentMethod = newValue.rawValue
        }
    }
    
    var paymentStatusEnum: PaymentStatus {
        get {
            // Default to .pending so corrupted/missing data never silently hides owed amounts.
            return PaymentStatus(rawValue: paymentStatus) ?? .pending
        }
        set {
            paymentStatus = newValue.rawValue
        }
    }
    
    var prizeAmount: Double {
        get {
            Double(prize.replacingOccurrences(of: "$", with: "")) ?? 0.0
        }
        set {
            prize = String(format: "$%.2f", newValue)
        }
    }

    /// A booking whose check-in day has not arrived yet: the guest is not here, so the
    /// room is not occupied — it is only reserved.
    var isReservation: Bool {
        let cal = Calendar.current
        return cal.startOfDay(for: checkInDate) > cal.startOfDay(for: Date())
    }

    /// The guest's licence photo, wherever it is stored: inside the booking (current
    /// builds, synced through iCloud) or in a legacy file on this device.
    var licensePhotoData: Data? {
        if let data = licenseImageData, !data.isEmpty { return data }
        if let filename = licenseImageFileName { return LicenseImageManager.data(named: filename) }
        return nil
    }

    func updatePayment(additionalAmount: Double, isTaxed: Bool, taxRate: Double) {
        let taxMultiplier = isTaxed ? (1 + taxRate) : 1.0
        let newAmount = prizeAmount + (additionalAmount * taxMultiplier)
        prize = String(format: "$%.2f", newAmount)
    }
}

extension CDBooking {
    convenience init(context: NSManagedObjectContext,
                    room: CDRoom,
                    customerName: String,
                    phoneNumber: String,
                    drivingLicenseNumber: String,
                    address: String,
                    city: String,
                    state: String,
                    zipCode: String,
                    licenseImageFileName: String? = nil,
                    licenseImageData: Data? = nil,
                    signatureImageData: Data? = nil,
                    paymentMethodEnum: PaymentMethod,
                    cardType: String?,
                    checkNumber: String?,
                    organizationName: String?,
                    prize: String,
                    numberOfDays: Int,
                    checkInDate: Date,
                    checkOutDate: Date,
                    isTaxed: Bool,
                    isHistory: Bool = false) {
        self.init(context: context)
        self.id = UUID()
        self.room = room
        self.customerName = customerName
        self.phoneNumber = phoneNumber
        self.drivingLicenseNumber = drivingLicenseNumber
        self.address = address
        self.city = city
        self.state = state
        self.zipCode = zipCode
        self.licenseImageFileName = licenseImageFileName
        self.licenseImageData = licenseImageData
        self.signatureImageData = signatureImageData
        self.signatureDate = signatureImageData != nil ? Date() : nil
        self.termsVersion = signatureImageData != nil ? TermsAndConditionsManager.shared.termsVersion : nil
        self.paymentMethod = paymentMethodEnum.rawValue
        self.cardType = cardType
        self.checkNumber = checkNumber
        self.organizationName = organizationName
        self.prize = prize
        // Clamp rather than convert: an out-of-range value would trap at runtime.
        self.numberOfDays = Int16(min(max(numberOfDays, 0), Int(Int16.max)))
        self.checkInDate = checkInDate
        self.checkOutDate = checkOutDate
        self.isTaxed = isTaxed
        self.isHistory = isHistory
        self.paymentStatus = (paymentMethodEnum == .organization) ? PaymentStatus.pending.rawValue : PaymentStatus.paid.rawValue
    }
}
