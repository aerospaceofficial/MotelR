//  CheckInView.swift
//  MotelR 2.0 — by New Journey

import SwiftUI
import AVFoundation
import Photos

// MARK: - CheckInView (multi-step form)

struct CheckInView: View {
    @EnvironmentObject var motelData: MotelData
    @Environment(\.dismiss) private var dismiss

    // Form fields
    @State private var customerName        = ""
    @State private var phoneNumber         = ""
    @State private var drivingLicenseNumber = ""
    @State private var address             = ""
    @State private var city                = ""
    @State private var state               = ""
    @State private var zipCode             = ""
    @State private var licenseImageData    = Data()
    @State private var signatureImage: UIImage?
    @State private var hasSignature        = false

    @State private var selectedRoom: CDRoom?
    @State private var checkInDate         = Date()
    @State private var numberOfNights      = 1
    @State private var checkOutDate        = Calendar.current.date(byAdding: .day, value: 1, to: Date()) ?? Date()

    @State private var paymentMethod: PaymentMethod = .cash
    @State private var cardType            = ""
    @State private var checkNumber         = ""
    @State private var organizationName    = ""
    @State private var pricePerNight       = ""
    @State private var isTaxed             = true
    @State private var isPayLater          = true

    // UI state
    @State private var currentStep: CheckInStep = .guestInfo
    @State private var showAlert           = false
    @State private var alertMessage        = ""
    @State private var showImagePicker     = false
    @State private var showPhotoSource     = false
    @State private var photoSource: UIImagePickerController.SourceType = .photoLibrary
    @State private var showSuccess         = false
    // Previous-incident warning (same check New Booking does)
    @State private var showingIncidentWarning = false
    @State private var incidentWarningText = ""
    @State private var warnedLicense       = ""
    @State private var successScale: CGFloat = 0.5
    @State private var successOpacity: Double = 0

    // Design tokens
    private let primaryColor  = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let primaryGradient = LinearGradient(
        colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                 Color(red: 0.05, green: 0.12, blue: 0.65)],
        startPoint: .topLeading, endPoint: .bottomTrailing)
    private let goldColor     = Color(red: 0.96, green: 0.65, blue: 0.14)
    private let greenColor    = Color(red: 0.20, green: 0.78, blue: 0.35)

    enum CheckInStep: Int, CaseIterable {
        case guestInfo  = 0
        case roomDates  = 1
        case payment    = 2
        case signConfirm = 3

        var title: String {
            switch self {
            case .guestInfo:   return "Guest"
            case .roomDates:   return "Room"
            case .payment:     return "Payment"
            case .signConfirm: return "Sign"
            }
        }
        var icon: String {
            switch self {
            case .guestInfo:   return "person.fill"
            case .roomDates:   return "bed.double.fill"
            case .payment:     return "creditcard.fill"
            case .signConfirm: return "signature"
            }
        }
    }

    // MARK: - Computed helpers
    private var totalPrice: Double {
        let nightly = Double(pricePerNight.filter { "0123456789.".contains($0) }) ?? 0
        return nightly * Double(numberOfNights)
    }
    private var taxRate: Double { motelData.taxRate }
    private var baseAmount: Double { isTaxed ? totalPrice / (1 + taxRate) : totalPrice }
    private var taxAmount: Double  { totalPrice - baseAmount }

    var body: some View {
        ZStack {
            Color(UIColor.systemGroupedBackground).ignoresSafeArea()

            VStack(spacing: 0) {
                progressBar
                    .padding(.horizontal, 20)
                    .padding(.top, 16)
                    .padding(.bottom, 8)

                ScrollView {
                    VStack(spacing: 0) {
                        stepContent
                            .transition(.asymmetric(
                                insertion: .move(edge: .trailing).combined(with: .opacity),
                                removal: .move(edge: .leading).combined(with: .opacity)
                            ))
                            .id(currentStep)
                            .padding(.horizontal, 16)
                            .padding(.top, 10)

                        navigationButtons
                            .padding(.horizontal, 16)
                            .padding(.top, 24)
                            .padding(.bottom, 40)
                    }
                }
            }

            // Success overlay
            if showSuccess {
                successOverlay
            }
        }
        .navigationTitle("Check In")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Missing Information", isPresented: $showAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(alertMessage)
        }
        .alert("Previous Incidents Found", isPresented: $showingIncidentWarning) {
            Button("Continue Anyway", role: .cancel) {}
        } message: {
            Text(incidentWarningText)
        }
        .sheet(isPresented: $showPhotoSource) {
            ImprovedPhotoSourcePicker(
                showImagePicker: $showImagePicker,
                isPresented: $showPhotoSource,
                photoSource: $photoSource
            )
        }
        .sheet(isPresented: $showImagePicker) {
            ImprovedImagePicker(
                imageData: $licenseImageData,
                isPresented: $showImagePicker,
                sourceType: photoSource,
                onComplete: {}
            )
        }
    }

    // MARK: - Progress bar
    private var progressBar: some View {
        HStack(spacing: 0) {
            ForEach(CheckInStep.allCases, id: \.self) { step in
                let stepIdx    = step.rawValue
                let currentIdx = currentStep.rawValue
                let isDone     = stepIdx < currentIdx
                let isCurrent  = step == currentStep

                VStack(spacing: 6) {
                    ZStack {
                        Circle()
                            .fill(isDone ? greenColor : (isCurrent ? primaryColor : Color(UIColor.systemGray5)))
                            .frame(width: 36, height: 36)
                        if isDone {
                            Image(systemName: "checkmark")
                                .font(.system(size: 14, weight: .bold))
                                .foregroundColor(.white)
                        } else {
                            Image(systemName: step.icon)
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(isCurrent ? .white : .secondary)
                        }
                    }
                    .shadow(color: isCurrent ? primaryColor.opacity(0.4) : .clear, radius: 6, y: 2)

                    Text(step.title)
                        .font(.system(size: 10, weight: isCurrent ? .bold : .regular, design: .rounded))
                        .foregroundColor(isCurrent ? primaryColor : .secondary)
                }

                if step != CheckInStep.allCases.last {
                    Rectangle()
                        .fill(stepIdx < currentIdx ? greenColor : Color(UIColor.systemGray4))
                        .frame(height: 2)
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, 22)
                }
            }
        }
    }

    /// Copies whatever the barcode gave us into the form. Only fills blank fields, so
    /// a re-scan never wipes something the clerk has already corrected by hand.
    private func applyScannedLicense(_ scanned: ScannedLicense) {
        if customerName.isEmpty         { customerName = scanned.fullName }
        if drivingLicenseNumber.isEmpty { drivingLicenseNumber = scanned.licenseNumber }
        if address.isEmpty              { address = scanned.address }
        if city.isEmpty                 { city = scanned.city }
        if state.isEmpty                { state = scanned.state }
        if zipCode.isEmpty              { zipCode = scanned.zipCode }
        checkPastIncidents()
    }

    /// Warns the clerk when this licence number has incidents on record. Runs after a
    /// scan and when leaving the Guest step; warns once per licence number.
    private func checkPastIncidents() {
        let key = MotelData.normalizedLicense(drivingLicenseNumber)
        guard !key.isEmpty, key != warnedLicense else { return }
        if let message = motelData.incidentWarningMessage(forLicense: drivingLicenseNumber) {
            warnedLicense = key
            incidentWarningText = message
            showingIncidentWarning = true
        }
    }

    // MARK: - Step content switcher
    @ViewBuilder
    private var stepContent: some View {
        switch currentStep {
        case .guestInfo:   guestInfoStep
        case .roomDates:   roomDatesStep
        case .payment:     paymentStep
        case .signConfirm: signConfirmStep
        }
    }

    // ── Step 1: Guest Info ────────────────────────────────────────────────
    private var guestInfoStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Optional shortcut — everything below can still be typed by hand.
            ScanLicenseButton { scanned in applyScannedLicense(scanned) }

            CIStepCard(title: "Guest Information", icon: "person.crop.circle.fill", color: primaryColor) {
                CITextField(label: "Full Name", placeholder: "Jane Smith", text: $customerName, icon: "person")
                CITextField(label: "Phone Number", placeholder: "(555) 123-4567", text: $phoneNumber, icon: "phone", keyboard: .phonePad)
                    .onChange(of: phoneNumber) { _, v in phoneNumber = formatPhone(v) }
                CITextField(label: "Driving License #", placeholder: "e.g. D12345678", text: $drivingLicenseNumber, icon: "creditcard")
            }

            CIStepCard(title: "Address", icon: "location.fill", color: primaryColor) {
                CITextField(label: "Street Address", placeholder: "123 Main St", text: $address, icon: "house")
                HStack(spacing: 12) {
                    CITextField(label: "City", placeholder: "Indianapolis", text: $city, icon: "building.2")
                    StatePickerView(selectedState: $state)
                }
                CITextField(label: "ZIP Code", placeholder: "46201", text: $zipCode, icon: "location", keyboard: .numberPad)
            }

            CIStepCard(title: "License Photo", icon: "camera.fill", color: primaryColor) {
                if licenseImageData.isEmpty {
                    Button { showPhotoSource = true } label: {
                        HStack {
                            Spacer()
                            VStack(spacing: 10) {
                                Image(systemName: "camera.viewfinder")
                                    .font(.system(size: 36))
                                    .foregroundColor(primaryColor)
                                Text("Tap to capture or upload")
                                    .font(.system(size: 14, design: .rounded))
                                    .foregroundColor(primaryColor)
                            }
                            Spacer()
                        }
                        .padding(24)
                        .background(primaryColor.opacity(0.08))
                        .cornerRadius(14)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(primaryColor.opacity(0.3), style: StrokeStyle(lineWidth: 1.5, dash: [6]))
                        )
                    }
                } else {
                    ZStack(alignment: .topTrailing) {
                        if let img = UIImage(data: licenseImageData) {
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 160)
                                .cornerRadius(12)
                        }
                        Button { licenseImageData = Data() } label: {
                            Image(systemName: "xmark.circle.fill")
                                .font(.system(size: 22))
                                .foregroundColor(.white)
                                .background(Circle().fill(Color.black.opacity(0.5)))
                        }
                        .padding(6)
                    }
                    Label("Photo uploaded", systemImage: "checkmark.circle.fill")
                        .font(.system(size: 13, design: .rounded))
                        .foregroundColor(greenColor)
                }
            }
        }
    }

    // ── Step 2: Room & Dates ──────────────────────────────────────────────
    private var roomDatesStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            CIStepCard(title: "Select Room", icon: "bed.double.fill", color: primaryColor) {
                RoomPickerInline(
                    selectedRoom: $selectedRoom,
                    checkInDate: checkInDate,
                    checkOutDate: checkOutDate
                )
                .environmentObject(motelData)
            }

            CIStepCard(title: "Stay Dates", icon: "calendar", color: primaryColor) {
                VStack(spacing: 14) {
                    VStack(alignment: .leading, spacing: 6) {
                        Label("Check-in Date", systemImage: "arrow.right.circle.fill")
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .foregroundColor(.secondary)
                        DatePicker("", selection: $checkInDate, displayedComponents: .date)
                            .datePickerStyle(.compact)
                            .labelsHidden()
                            .onChange(of: checkInDate) { _, _ in syncCheckOut() }
                    }
                    Divider()
                    // Nights stepper
                    HStack {
                        Label("Number of Nights", systemImage: "moon.stars.fill")
                            .font(.system(size: 14, weight: .semibold, design: .rounded))
                        Spacer()
                        HStack(spacing: 16) {
                            Button {
                                if numberOfNights > 1 { numberOfNights -= 1; syncCheckOut() }
                            } label: {
                                Image(systemName: "minus.circle.fill")
                                    .font(.system(size: 24))
                                    .foregroundColor(numberOfNights > 1 ? primaryColor : .secondary)
                            }
                            Text("\(numberOfNights)")
                                .font(.system(size: 20, weight: .bold, design: .rounded))
                                .frame(minWidth: 32)
                            Button {
                                if numberOfNights < 30 { numberOfNights += 1; syncCheckOut() }
                            } label: {
                                Image(systemName: "plus.circle.fill")
                                    .font(.system(size: 24))
                                    .foregroundColor(primaryColor)
                            }
                        }
                    }
                    Divider()
                    // Computed checkout
                    HStack {
                        Label("Check-out Date", systemImage: "arrow.left.circle.fill")
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .foregroundColor(.secondary)
                        Spacer()
                        Text(DateFormatter.shortDate.string(from: checkOutDate))
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundColor(primaryColor)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(primaryColor.opacity(0.10))
                            .cornerRadius(8)
                    }
                }
            }
        }
    }

    // ── Step 3: Payment ────────────────────────────────────────────────────
    private var paymentStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            CIStepCard(title: "Payment Method", icon: "creditcard.fill", color: primaryColor) {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    ForEach(PaymentMethod.allCases, id: \.self) { method in
                        paymentMethodCard(method: method)
                    }
                }
                if paymentMethod == .card {
                    CITextField(label: "Card Type", placeholder: "Visa / Mastercard / Amex", text: $cardType, icon: "creditcard")
                        .padding(.top, 4)
                }
                if paymentMethod == .check {
                    CITextField(label: "Check Number", placeholder: "e.g. 1042", text: $checkNumber, icon: "doc.text.fill")
                        .padding(.top, 4)
                }
                if paymentMethod == .organization {
                    CITextField(label: "Organization Name", placeholder: "ACME Corp", text: $organizationName, icon: "building.2.fill")
                        .padding(.top, 4)
                    Toggle(isOn: $isPayLater) {
                        Label("Bill Later (Pending)", systemImage: "clock.arrow.circlepath")
                            .font(.system(size: 14, design: .rounded))
                    }
                    .tint(goldColor)
                }
            }

            CIStepCard(title: "Pricing", icon: "dollarsign.circle.fill", color: primaryColor) {
                CITextField(label: "Rate Per Night", placeholder: "89.00", text: $pricePerNight, icon: "dollarsign.circle", keyboard: .decimalPad)
                Toggle(isOn: $isTaxed) {
                    Label("Tax Included in Total", systemImage: "percent")
                        .font(.system(size: 14, design: .rounded))
                }
                .tint(primaryColor)

                if totalPrice > 0 {
                    VStack(spacing: 8) {
                        Divider()
                        priceRow(label: "\(numberOfNights) night\(numberOfNights == 1 ? "" : "s") × $\(String(format: "%.2f", Double(pricePerNight.filter{"0123456789.".contains($0)}) ?? 0))", value: totalPrice)
                        if isTaxed {
                            priceRow(label: "  Base amount", value: baseAmount, secondary: true)
                            priceRow(label: "  Tax (\(Int(taxRate * 100))%) included", value: taxAmount, secondary: true)
                        }
                        Divider()
                        priceRow(label: "Total", value: totalPrice, isTotal: true)
                    }
                    .padding(.top, 4)
                }
            }
        }
    }

    private func paymentMethodCard(method: PaymentMethod) -> some View {
        let isSelected = paymentMethod == method
        return Button { withAnimation(.spring()) { paymentMethod = method } } label: {
            VStack(spacing: 8) {
                Image(systemName: paymentIcon(method))
                    .font(.system(size: 22, weight: .semibold))
                Text(method.rawValue)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(isSelected ? primaryColor : Color(UIColor.systemGray6))
            .foregroundColor(isSelected ? .white : .primary)
            .cornerRadius(14)
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(isSelected ? primaryColor : Color.clear, lineWidth: 2)
            )
            .shadow(color: isSelected ? primaryColor.opacity(0.30) : .clear, radius: 6, y: 2)
        }
    }

    private func paymentIcon(_ m: PaymentMethod) -> String {
        switch m {
        case .cash:         return "banknote"
        case .check:        return "doc.text.fill"
        case .card:         return "creditcard.fill"
        case .organization: return "building.2.fill"
        }
    }

    private func priceRow(label: String, value: Double, secondary: Bool = false, isTotal: Bool = false) -> some View {
        HStack {
            Text(label)
                .font(.system(size: secondary ? 13 : (isTotal ? 16 : 14),
                              weight: isTotal ? .bold : .regular, design: .rounded))
                .foregroundColor(secondary ? .secondary : .primary)
            Spacer()
            Text(String(format: "$%.2f", value))
                .font(.system(size: secondary ? 13 : (isTotal ? 16 : 14),
                              weight: isTotal ? .bold : .medium, design: .rounded))
                .foregroundColor(isTotal ? primaryColor : (secondary ? .secondary : .primary))
        }
    }

    // ── Step 4: Sign & Confirm ─────────────────────────────────────────────
    private var signConfirmStep: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Summary
            CIStepCard(title: "Booking Summary", icon: "list.bullet.clipboard.fill", color: primaryColor) {
                summaryRow(label: "Guest", value: customerName)
                summaryRow(label: "Room", value: selectedRoom.map { "Room \($0.number)" } ?? "—")
                summaryRow(label: "Check-in", value: DateFormatter.shortDate.string(from: checkInDate))
                summaryRow(label: "Check-out", value: DateFormatter.shortDate.string(from: checkOutDate))
                summaryRow(label: "Nights", value: "\(numberOfNights)")
                summaryRow(label: "Payment", value: paymentMethod.rawValue)
                summaryRow(label: "Total", value: String(format: "$%.2f", totalPrice), highlight: true)
                if isTaxed {
                    summaryRow(label: "Tax Rate", value: "\(Int(taxRate * 100))%")
                }
            }

            // Terms version
            HStack {
                Image(systemName: "doc.text")
                    .foregroundColor(.secondary)
                Text("Terms Version: \(TermsAndConditionsManager.shared.termsVersion)")
                    .font(.system(size: 12, design: .rounded))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 4)

            // Signature
            CIStepCard(title: "Guest Signature", icon: "signature", color: primaryColor) {
                SignatureStepView(
                    signatureImage: $signatureImage,
                    hasSignature: $hasSignature,
                    customerName: customerName
                )
            }

            // Confirm button
            Button { confirmCheckIn() } label: {
                HStack {
                    Spacer()
                    Image(systemName: "checkmark.seal.fill")
                        .font(.system(size: 18, weight: .bold))
                    Text("Confirm Check-In")
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                    Spacer()
                }
                .foregroundColor(.white)
                .padding(.vertical, 18)
                .background(hasSignature ? primaryGradient : LinearGradient(colors: [.gray], startPoint: .leading, endPoint: .trailing))
                .cornerRadius(16)
                .shadow(color: hasSignature ? primaryColor.opacity(0.35) : .clear, radius: 10, y: 4)
            }
            .disabled(!hasSignature)
            .animation(.easeInOut, value: hasSignature)
        }
    }

    private func summaryRow(label: String, value: String, highlight: Bool = false) -> some View {
        HStack {
            Text(label)
                .font(.system(size: 14, design: .rounded))
                .foregroundColor(.secondary)
                .frame(width: 80, alignment: .leading)
            Spacer()
            Text(value)
                .font(.system(size: 14, weight: highlight ? .bold : .medium, design: .rounded))
                .foregroundColor(highlight ? primaryColor : .primary)
                .multilineTextAlignment(.trailing)
        }
        .padding(.vertical, 2)
    }

    // MARK: - Navigation buttons
    private var navigationButtons: some View {
        let steps   = CheckInStep.allCases
        let idx     = currentStep.rawValue
        let isFirst = idx == 0
        let isLast  = idx == steps.count - 1

        return HStack(spacing: 14) {
            if !isFirst {
                Button {
                    withAnimation(.easeInOut(duration: 0.3)) {
                        currentStep = steps[idx - 1]
                    }
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "chevron.left")
                        Text("Back")
                    }
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundColor(primaryColor)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 14)
                    .background(primaryColor.opacity(0.10))
                    .cornerRadius(12)
                }
            }

            Spacer()

            if !isLast {
                Button {
                    if validateStep() {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            currentStep = steps[idx + 1]
                        }
                    }
                } label: {
                    HStack(spacing: 6) {
                        Text("Next")
                        Image(systemName: "chevron.right")
                    }
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 14)
                    .background(primaryGradient)
                    .cornerRadius(12)
                    .shadow(color: primaryColor.opacity(0.30), radius: 8, y: 3)
                }
            }
        }
    }

    // MARK: - Success overlay
    private var successOverlay: some View {
        ZStack {
            Color.black.opacity(0.45).ignoresSafeArea()
            VStack(spacing: 20) {
                ZStack {
                    Circle()
                        .fill(greenColor)
                        .frame(width: 100, height: 100)
                    Image(systemName: "checkmark")
                        .font(.system(size: 44, weight: .bold))
                        .foregroundColor(.white)
                }
                .scaleEffect(successScale)
                .opacity(successOpacity)

                Text("Checked In!")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .opacity(successOpacity)
                Text("\(customerName) is now checked in to Room \(selectedRoom.map { String($0.number) } ?? "").")
                    .font(.system(size: 15, design: .rounded))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .opacity(successOpacity)
            }
            .padding(40)
            .background(Color(UIColor.systemBackground).opacity(0.97))
            .cornerRadius(24)
            .shadow(color: .black.opacity(0.15), radius: 20, y: 8)
            .padding(.horizontal, 40)
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                successScale = 1
                successOpacity = 1
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                dismiss()
            }
        }
    }

    // MARK: - Logic
    private func syncCheckOut() {
        checkOutDate = Calendar.current.date(byAdding: .day, value: numberOfNights, to: checkInDate) ?? checkInDate
    }

    private func formatPhone(_ raw: String) -> String {
        let digits = raw.filter { "0123456789".contains($0) }
        var out = ""
        for (i, c) in digits.enumerated() {
            if i == 0 { out.append("(") }
            if i == 3 { out.append(") ") }
            if i == 6 { out.append("-") }
            out.append(c)
        }
        return String(out.prefix(14))
    }

    private func validateStep() -> Bool {
        switch currentStep {
        case .guestInfo:
            let missing = [
                customerName.isEmpty ? "Full Name" : nil,
                phoneNumber.isEmpty  ? "Phone Number" : nil,
                drivingLicenseNumber.isEmpty ? "Driving License #" : nil,
                address.isEmpty      ? "Street Address" : nil,
                city.isEmpty         ? "City" : nil,
                state.isEmpty        ? "State" : nil,
                zipCode.isEmpty      ? "ZIP Code" : nil
            ].compactMap { $0 }
            if !missing.isEmpty {
                alertMessage = "Please fill in:\n• " + missing.joined(separator: "\n• ")
                showAlert = true
                return false
            }
            checkPastIncidents()
        case .roomDates:
            if selectedRoom == nil {
                alertMessage = "Please select a room."
                showAlert = true
                return false
            }
        case .payment:
            if pricePerNight.trimmingCharacters(in: .whitespaces).isEmpty {
                alertMessage = "Please enter a price per night."
                showAlert = true
                return false
            }
            if paymentMethod == .card && cardType.isEmpty {
                alertMessage = "Please enter the card type."
                showAlert = true
                return false
            }
            if paymentMethod == .check && checkNumber.isEmpty {
                alertMessage = "Please enter the check number."
                showAlert = true
                return false
            }
            if paymentMethod == .organization && organizationName.isEmpty {
                alertMessage = "Please enter the organization name."
                showAlert = true
                return false
            }
        case .signConfirm:
            break
        }
        return true
    }

    private func confirmCheckIn() {
        guard hasSignature, let room = selectedRoom else { return }
        let priceVal = Double(pricePerNight.filter { "0123456789.".contains($0) }) ?? 0
        let total = priceVal * Double(numberOfNights)
        let prizeStr = String(format: "$%.2f", total)
        let sigData = signatureImage?.jpegData(compressionQuality: 0.8)
        // The photo goes inside the booking so it syncs to the owner's other devices.
        let storedLicensePhoto: Data? = licenseImageData.isEmpty ? nil : LicenseImageManager.prepareForStorage(licenseImageData)

        let newBooking = CDBooking(
            context: CoreDataManager.shared.context,
            room: room,
            customerName: customerName,
            phoneNumber: phoneNumber,
            drivingLicenseNumber: drivingLicenseNumber,
            address: address,
            city: city,
            state: state,
            zipCode: zipCode,
            licenseImageData: storedLicensePhoto,
            signatureImageData: sigData,
            paymentMethodEnum: paymentMethod,
            cardType: paymentMethod == .card ? cardType : nil,
            checkNumber: paymentMethod == .check ? checkNumber : nil,
            organizationName: paymentMethod == .organization ? organizationName : nil,
            prize: prizeStr,
            numberOfDays: numberOfNights,
            checkInDate: checkInDate,
            checkOutDate: checkOutDate,
            isTaxed: isTaxed
        )
        newBooking.paymentStatus = (paymentMethod == .organization && isPayLater)
            ? PaymentStatus.pending.rawValue
            : PaymentStatus.paid.rawValue

        let success = motelData.addBooking(newBooking)
        if success {
            scheduleCheckoutReminderNotification(booking: newBooking)
            let generator = UINotificationFeedbackGenerator()
            generator.notificationOccurred(.success)
            withAnimation { showSuccess = true }
        } else {
            alertMessage = "Room \(room.number) is already booked for these dates. Please choose different dates or a different room."
            showAlert = true
        }
    }
}

// MARK: - RoomPickerInline

struct RoomPickerInline: View {
    @EnvironmentObject var motelData: MotelData
    @Binding var selectedRoom: CDRoom?
    let checkInDate: Date
    let checkOutDate: Date

    private let primaryColor = Color(red: 0.18, green: 0.27, blue: 0.90)
    private let greenColor   = Color(red: 0.20, green: 0.78, blue: 0.35)

    private var availableRooms: [CDRoom] {
        motelData.rooms.filter { room in
            !motelData.bookings.contains { b in
                b.room.id == room.id &&
                b.checkInDate < checkOutDate &&
                checkInDate < b.checkOutDate
            }
        }.sorted { $0.number < $1.number }
    }

    var body: some View {
        if availableRooms.isEmpty {
            VStack(spacing: 10) {
                Image(systemName: "bed.double.fill")
                    .font(.system(size: 32))
                    .foregroundColor(.secondary)
                Text("No rooms available for selected dates")
                    .font(.system(size: 14, design: .rounded))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding(24)
        } else {
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(availableRooms, id: \.id) { room in
                    let isSelected = selectedRoom?.id == room.id
                    Button { withAnimation(.spring()) { selectedRoom = room } } label: {
                        VStack(spacing: 4) {
                            Image(systemName: "bed.double")
                                .font(.system(size: 18))
                                .foregroundColor(isSelected ? .white : primaryColor)
                            Text("\(room.number)")
                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                .foregroundColor(isSelected ? .white : .primary)
                            if !room.name.isEmpty {
                                Text(room.name)
                                    .font(.system(size: 9, design: .rounded))
                                    .foregroundColor(isSelected ? .white.opacity(0.85) : .secondary)
                                    .lineLimit(1)
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(isSelected
                            ? LinearGradient(colors: [Color(red: 0.18, green: 0.27, blue: 0.90),
                                                      Color(red: 0.05, green: 0.12, blue: 0.65)],
                                             startPoint: .topLeading, endPoint: .bottomTrailing)
                            : LinearGradient(colors: [Color(UIColor.systemGray6)],
                                             startPoint: .top, endPoint: .bottom))
                        .cornerRadius(12)
                        .shadow(color: isSelected ? primaryColor.opacity(0.35) : .clear, radius: 6, y: 2)
                    }
                }
            }
        }
    }
}

// MARK: - Shared card container for form steps

struct CIStepCard<Content: View>: View {
    let title: String
    let icon: String
    let color: Color
    @ViewBuilder let content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(color)
                Text(title)
                    .font(.system(size: 16, weight: .bold, design: .rounded))
            }
            content()
        }
        .padding(16)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(18)
        .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 3)
    }
}

// MARK: - Reusable text field for CheckInView

struct CITextField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var icon: String = ""
    var keyboard: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label)
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundColor(.secondary)
            HStack(spacing: 10) {
                if !icon.isEmpty {
                    Image(systemName: icon)
                        .font(.system(size: 14))
                        .foregroundColor(Color(red: 0.18, green: 0.27, blue: 0.90))
                        .frame(width: 18)
                }
                TextField(placeholder, text: $text)
                    .font(.system(size: 15, design: .rounded))
                    .keyboardType(keyboard)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(10)
        }
    }
}

// MARK: - Preview
struct CheckInView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            CheckInView()
                .environmentObject(MotelData())
        }
    }
}
