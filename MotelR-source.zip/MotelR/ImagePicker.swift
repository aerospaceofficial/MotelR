//
//  ImagePicker.swift
//  MotelR
//
//  Created by Nishant Jhaveri on 7/13/24.
//

import SwiftUI
import UIKit
import Photos
import AVFoundation

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var imageData: Data
    var sourceType: UIImagePickerController.SourceType
    var onComplete: (() -> Void)?
    @Environment(\.presentationMode) var presentationMode
    @Binding var showAlert: Bool
    @Binding var alertMessage: String

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController,
                                 didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                // Compress image to reduce memory usage
                if let compressedData = uiImage.jpegData(compressionQuality: 0.7) {
                    parent.imageData = compressedData
                    parent.onComplete?()
                }
            }
            parent.presentationMode.wrappedValue.dismiss()
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        // Check camera permission if source type is camera
        if sourceType == .camera {
            let authStatus = AVCaptureDevice.authorizationStatus(for: .video)
            switch authStatus {
            case .notDetermined:
                AVCaptureDevice.requestAccess(for: .video) { granted in
                    if !granted {
                        DispatchQueue.main.async {
                            alertMessage = "Camera access is required for this feature. Please enable it in Settings."
                            showAlert = true
                            presentationMode.wrappedValue.dismiss()
                        }
                    }
                }
            case .restricted, .denied:
                DispatchQueue.main.async {
                    alertMessage = "Camera access is required for this feature. Please enable it in Settings."
                    showAlert = true
                    presentationMode.wrappedValue.dismiss()
                }
            case .authorized:
                break
            @unknown default:
                break
            }
        }

        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        
        // Verify camera availability
        if sourceType == .camera {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                picker.sourceType = .camera
            } else {
                DispatchQueue.main.async {
                    alertMessage = "Camera is not available on this device."
                    showAlert = true
                    presentationMode.wrappedValue.dismiss()
                }
            }
        } else {
            picker.sourceType = sourceType
        }

        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
}

struct PhotoSourcePicker: View {
    @Binding var showImagePicker: Bool
    @Binding var showingImageSource: Bool
    @Binding var photoSource: UIImagePickerController.SourceType
    @Binding var showAlert: Bool
    @Binding var alertMessage: String
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            List {
                Section {
                    Button(action: {
                        PhotoManager.shared.checkCameraPermission { granted in
                            if granted {
                                photoSource = .camera
                                showImagePicker = true
                                dismiss()
                            } else {
                                alertMessage = "Camera access is required. Would you like to enable it in Settings?"
                                showAlert = true
                            }
                        }
                    }) {
                        HStack {
                            Image(systemName: "camera.fill")
                                .foregroundColor(.blue)
                                .frame(width: 30)
                            Text("Take Photo")
                        }
                        .padding(.vertical, 8)
                    }
                    
                    Button(action: {
                        PhotoManager.shared.checkPhotoLibraryPermission { granted in
                            if granted {
                                photoSource = .photoLibrary
                                showImagePicker = true
                                dismiss()
                            } else {
                                alertMessage = "Photo library access is required. Would you like to enable it in Settings?"
                                showAlert = true
                            }
                        }
                    }) {
                        HStack {
                            Image(systemName: "photo.on.rectangle")
                                .foregroundColor(.blue)
                                .frame(width: 30)
                            Text("Choose from Library")
                        }
                        .padding(.vertical, 8)
                    }
                }
            }
            .navigationTitle("Choose Photo Source")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
}

class PhotoManager {
    static let shared = PhotoManager()
    
    private init() {}
    
    func checkCameraPermission(completion: @escaping (Bool) -> Void) {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            completion(true)
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                DispatchQueue.main.async {
                    completion(granted)
                }
            }
        case .denied, .restricted:
            completion(false)
        @unknown default:
            completion(false)
        }
    }
    
    func checkPhotoLibraryPermission(completion: @escaping (Bool) -> Void) {
        switch PHPhotoLibrary.authorizationStatus() {
        case .authorized, .limited:
            completion(true)
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization { status in
                DispatchQueue.main.async {
                    completion(status == .authorized || status == .limited)
                }
            }
        case .denied, .restricted:
            completion(false)
        @unknown default:
            completion(false)
        }
    }
    
    func openSettings() {
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString),
              UIApplication.shared.canOpenURL(settingsUrl) else {
            return
        }
        UIApplication.shared.open(settingsUrl)
    }
}
