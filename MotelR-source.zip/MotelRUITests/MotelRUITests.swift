import XCTest

// MotelR Full End-to-End UI Test
//
// Booking wizard sections:
//   1 Personal Info  : "Enter customer name", "(123) 456-7890", "Enter license number",
//                      "Enter street address", "City", "ZIP Code"
//   2 Room Details   : "Select Room" button, "Enter number of members"
//   3 Payment        : Cash/Card/Check/Org buttons, "Enter amount"
//   4 Dates          : DatePickers (pre-filled with today/tomorrow)
//   5 Signature      : SignaturePad view + "Complete Booking" button
//
// Manage Rooms fields: "Room Number", "Room Name", "Number of Members", "Add Room" button
// CRITICAL: dismiss keyboard (swipeDown or tap nav bar) before tapping Next.

class MotelRUITests: XCTestCase {

    var app: XCUIApplication!

    override func setUpWithError() throws {
        continueAfterFailure = false
        app = XCUIApplication()
        app.launch()
    }

    func testCompleteFlow() throws {

        // 1 ── Launch screen ────────────────────────────────────────────────────
        sleep(7)
        snap("01_launch_screen")

        // 2 ── Get Started / PIN setup (fresh install) ─────────────────────────
        let getStarted = app.buttons.matching(NSPredicate(format: "label CONTAINS 'Get Started'")).firstMatch
        if getStarted.waitForExistence(timeout: 2) {
            getStarted.tap(); sleep(1)
            snap("02_pin_setup")
            enterPIN("100500"); sleep(1)
            snap("03_pin_confirm")
            enterPIN("100500"); sleep(2)
            snap("04_pin_set")
        }

        // 3 ── PIN lock ─────────────────────────────────────────────────────────
        if app.staticTexts["Enter your PIN to continue"].waitForExistence(timeout: 3) {
            snap("05_pin_lock")
            enterPIN("100500"); sleep(2)
        }

        // 4 ── Main View ────────────────────────────────────────────────────────
        XCTAssert(app.staticTexts["Welcome to Motel R"].waitForExistence(timeout: 5), "Main view not found")
        snap("06_main_view")

        // 5 ── Manage Rooms ─────────────────────────────────────────────────────
        tapButtonContaining("Manage")
        sleep(1); snap("07_manage_rooms")

        // Fields: Room Number | Room Name | Number of Members
        let rnField = app.textFields["Room Number"]
        rnField.waitForExistence(timeout: 3)
        rnField.tap(); rnField.typeText("101")

        let nameField = app.textFields["Room Name"]
        nameField.tap(); nameField.typeText("Double Bed")

        let memField = app.textFields["Number of Members"]
        memField.tap(); memField.typeText("2")

        dismissKeyboard()
        snap("09_room_fields_filled")

        // "Add Room" is a Button with label "Add Room"
        let addRoomBtn = app.buttons["Add Room"]
        addRoomBtn.waitForExistence(timeout: 2)
        addRoomBtn.tap()
        sleep(1); snap("10_room_added")
        dismissAlert()

        tapBack(); sleep(1)
        snap("11_back_to_main")

        // 6 ── New Booking Form ─────────────────────────────────────────────────
        tapButtonContaining("Booking")
        sleep(1); snap("12_booking_form")

        // ── Section 1: Personal Info ───────────────────────────────────────────
        fillByPlaceholder("Enter customer name",     text: "John Smith")
        dismissKeyboard(); sleep(0)
        fillByPlaceholder("(123) 456-7890",          text: "5551234567")
        dismissKeyboard(); sleep(0)
        fillByPlaceholder("Enter license number",    text: "TX123456")
        dismissKeyboard(); sleep(0)
        fillByPlaceholder("Enter street address",    text: "123 Main St")
        dismissKeyboard(); sleep(0)
        fillByPlaceholder("City",                    text: "Austin")
        dismissKeyboard(); sleep(0)
        fillByPlaceholder("ZIP Code",                text: "78701")
        sleep(1)
        snap("13_personal_info_filled")

        // tapNext() will dismiss keyboard before tapping
        tapNext()
        sleep(1); snap("14_room_details_section")

        // ── Section 2: Room Details ────────────────────────────────────────────
        // "Select Room" is a button (the RoomPicker trigger)
        let selectRoomBtn = app.buttons.matching(
            NSPredicate(format: "label CONTAINS 'Select Room' OR label CONTAINS '101'")).firstMatch
        if selectRoomBtn.waitForExistence(timeout: 2) {
            selectRoomBtn.tap(); sleep(1)
            snap("14b_room_picker_open")
            // Pick room 101 from the sheet
            let room101Btn = app.buttons.matching(NSPredicate(format: "label CONTAINS '101'")).firstMatch
            if room101Btn.waitForExistence(timeout: 3) { room101Btn.tap() }
            else { app.cells.firstMatch.tap() }
            sleep(1)
        }

        fillByPlaceholder("Enter number of members", text: "2")
        sleep(1)
        snap("15_room_filled")
        // tapNext() will dismiss keyboard internally
        tapNext(); sleep(1)
        snap("16_payment_section")

        // ── Section 3: Payment ─────────────────────────────────────────────────
        // Cash button — default but tap to confirm
        let cashBtn = app.buttons.matching(NSPredicate(format: "label CONTAINS 'Cash'")).firstMatch
        if cashBtn.waitForExistence(timeout: 2) { cashBtn.tap() }

        fillByPlaceholder("Enter amount", text: "150")
        sleep(1)
        snap("17_payment_filled")
        // tapNext() will dismiss keyboard internally before tapping
        tapNext(); sleep(1)
        snap("18_dates_section")

        // ── Section 4: Dates ───────────────────────────────────────────────────
        // Pre-filled with today/tomorrow — just proceed
        snap("19_dates_ok")
        tapNext(); sleep(1)
        snap("20_signature_section")

        // ── Section 5: Signature ───────────────────────────────────────────────
        // Draw on the signature pad (find it by scrolling if needed)
        drawSignature()
        sleep(1); snap("21_signature_drawn")

        // "Complete Booking" button (only active after hasSignature = true)
        let completeBtn = app.buttons.matching(NSPredicate(format: "label CONTAINS 'Complete'")).firstMatch
        if completeBtn.waitForExistence(timeout: 3) && completeBtn.isEnabled {
            completeBtn.tap(); sleep(2)
        }
        snap("22_booking_submitted")
        dismissAlert()

        // 7 ── View the saved booking in "Current Bookings" list ───────────────
        app.swipeUp(); sleep(1)
        snap("23_current_bookings")

        // Tap first booking card (NavigationLink)
        let firstCard = app.cells.firstMatch
        if firstCard.waitForExistence(timeout: 3) { firstCard.tap() }
        else {
            // Fallback: look for a button containing "Smith"
            app.buttons.matching(NSPredicate(format: "label CONTAINS 'Smith'")).firstMatch.tap()
        }
        sleep(1); snap("24_booking_detail")

        // 8 ── Check-out ────────────────────────────────────────────────────────
        let checkOutBtn = app.buttons.matching(
            NSPredicate(format: "label CONTAINS 'Check Out' OR label CONTAINS 'Checkout'")).firstMatch
        if checkOutBtn.waitForExistence(timeout: 3) {
            checkOutBtn.tap(); sleep(1)
            snap("25_checkout_dialog")
            dismissAlert(); sleep(1)
        }
        snap("26_checked_out")

        // 9 ── PDF Receipt ──────────────────────────────────────────────────────
        let receiptBtn = app.buttons.matching(
            NSPredicate(format: "label CONTAINS 'PDF' OR label CONTAINS 'Receipt'")).firstMatch
        if receiptBtn.waitForExistence(timeout: 3) {
            receiptBtn.tap(); sleep(2)
            snap("27_pdf_receipt")
            // Dismiss share sheet / receipt view
            let closeBtn = app.buttons.matching(
                NSPredicate(format: "label CONTAINS 'Close' OR label CONTAINS 'Done' OR label CONTAINS 'Cancel'")).firstMatch
            if closeBtn.waitForExistence(timeout: 2) { closeBtn.tap() }
        }
        snap("28_after_receipt")

        // Back to main
        tapBack(); sleep(1); tapBack(); sleep(1); tapBack(); sleep(1)
        snap("29_main_view")

        // 10 ── History ─────────────────────────────────────────────────────────
        let historyBtn = app.buttons["History"]
        if historyBtn.waitForExistence(timeout: 3) { historyBtn.tap() }
        sleep(1); snap("30_history")
        tapBack(); sleep(1)

        // 11 ── Generate Reports ────────────────────────────────────────────────
        let reportsBtn = app.buttons.matching(
            NSPredicate(format: "label CONTAINS 'Generate Reports'")).firstMatch
        if reportsBtn.waitForExistence(timeout: 3) { reportsBtn.tap() }
        sleep(1); snap("31_reports")
        tapBack(); sleep(1)

        // 12 ── Settings ────────────────────────────────────────────────────────
        let gearBtn = app.buttons.matching(NSPredicate(format: "label == 'gear'")).firstMatch
        if gearBtn.waitForExistence(timeout: 3) { gearBtn.tap() }
        sleep(1); snap("32_settings")

        // Manual Backup
        let backupRow = app.cells.staticTexts.matching(
            NSPredicate(format: "label CONTAINS 'Manual Backup' OR label CONTAINS 'Backup Data'")).firstMatch
        if backupRow.waitForExistence(timeout: 3) { backupRow.tap(); sleep(1) }
        snap("33_backup_triggered")
        dismissAlert()

        // Export Backup
        let exportRow = app.cells.staticTexts["Export Backup"]
        if exportRow.waitForExistence(timeout: 2) {
            exportRow.tap(); sleep(2)
            snap("34_export_sheet")
            let cancelBtn = app.buttons["Cancel"].firstMatch
            if cancelBtn.waitForExistence(timeout: 2) { cancelBtn.tap() }
        }

        // Auto-backup toggle
        let autoToggle = app.switches["Auto Backup"]
        if autoToggle.waitForExistence(timeout: 2) {
            autoToggle.tap(); sleep(1)
            snap("35_auto_backup_on")
            autoToggle.tap()
        }

        snap("36_settings_done")
        let doneBtn = app.buttons["Done"]
        if doneBtn.waitForExistence(timeout: 2) { doneBtn.tap() }
        sleep(1); snap("37_final_main")
    }

    // MARK: - Helpers

    private func enterPIN(_ pin: String) {
        for ch in pin {
            let b = app.buttons[String(ch)]
            if b.waitForExistence(timeout: 2) { b.tap(); usleep(200_000) }
        }
    }

    private func tapNext() {
        // Always dismiss keyboard first before looking for Next
        dismissKeyboard()
        sleep(1)
        let b = app.buttons.matching(NSPredicate(format: "label CONTAINS 'Next'")).firstMatch
        if b.waitForExistence(timeout: 3) {
            if !b.isHittable {
                app.swipeUp()
                usleep(500_000)
            }
            b.tap()
        }
    }

    private func tapBack() {
        if app.navigationBars.buttons.count > 0 {
            let b = app.navigationBars.buttons.element(boundBy: 0)
            if b.exists && b.isHittable { b.tap(); return }
        }
        for lbl in ["Back", "Close", "Done", "Cancel"] {
            let b = app.buttons[lbl]
            if b.exists && b.isHittable { b.tap(); return }
        }
    }

    private func tapButtonContaining(_ fragment: String) {
        let b = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", fragment)).firstMatch
        if b.waitForExistence(timeout: 3) { b.tap() }
    }

    private func fillByPlaceholder(_ placeholder: String, text: String) {
        var f = app.textFields.matching(
            NSPredicate(format: "placeholderValue CONTAINS[c] %@", placeholder)).firstMatch
        if !f.exists {
            f = app.scrollViews.textFields.matching(
                NSPredicate(format: "placeholderValue CONTAINS[c] %@", placeholder)).firstMatch
        }
        if f.waitForExistence(timeout: 2) && f.isHittable {
            f.tap(); f.typeText(text)
        }
    }

    /// Dismiss keyboard — works for both alpha and numpad keyboards.
    private func dismissKeyboard() {
        // First try tapping the navigation bar (works for alpha keyboard)
        let navBar = app.navigationBars.firstMatch
        if navBar.exists && navBar.isHittable {
            navBar.tap()
            usleep(400_000)
            // Check if keyboard is still up — if so, use coordinate tap
            if app.keyboards.firstMatch.exists {
                let topArea = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.08))
                topArea.tap()
                usleep(400_000)
            }
            return
        }
        // Fallback: tap top-center of screen (always above keyboard)
        let topArea = app.coordinate(withNormalizedOffset: CGVector(dx: 0.5, dy: 0.08))
        topArea.tap()
        usleep(400_000)
    }

    private func drawSignature() {
        // Try finding the signature pad via accessibility
        let sigPad = app.otherElements.matching(
            NSPredicate(format: "label CONTAINS[c] 'signature' OR label CONTAINS[c] 'sign'")).firstMatch
        if sigPad.waitForExistence(timeout: 2) {
            let p1 = sigPad.coordinate(withNormalizedOffset: CGVector(dx: 0.15, dy: 0.5))
            let p2 = sigPad.coordinate(withNormalizedOffset: CGVector(dx: 0.85, dy: 0.5))
            p1.press(forDuration: 0.05, thenDragTo: p2)
        } else {
            // Draw in the center-lower portion of the screen where sig pad is rendered
            let win = app.windows.firstMatch
            let p1 = win.coordinate(withNormalizedOffset: CGVector(dx: 0.2, dy: 0.65))
            let p2 = win.coordinate(withNormalizedOffset: CGVector(dx: 0.8, dy: 0.65))
            p1.press(forDuration: 0.05, thenDragTo: p2)
        }
    }

    private func dismissAlert() {
        for lbl in ["OK", "Done", "Dismiss", "Cancel"] {
            let b = app.alerts.buttons[lbl]
            if b.waitForExistence(timeout: 1) { b.tap(); return }
        }
    }

    private func snap(_ name: String) {
        let a = XCTAttachment(screenshot: app.screenshot())
        a.name = name; a.lifetime = .keepAlways; add(a)
    }
}
